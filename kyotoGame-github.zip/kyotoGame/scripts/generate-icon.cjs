/**
 * Generates build/icon.png (256x256) and build/icon.ico for kyotoGame
 * using pure Node zlib (no native image dependencies).
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xedb88320 & -(c & 1));
  }
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function encodePng(width, height, rgba) {
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (width * 4 + 1)] = 0;
    rgba.copy(raw, y * (width * 4 + 1) + 1, y * width * 4, (y + 1) * width * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  const idat = zlib.deflateSync(raw, { level: 9 });
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', idat),
    pngChunk('IEND', Buffer.alloc(0)),
  ]);
}

function drawKyotoIcon(size) {
  const buf = Buffer.alloc(size * size * 4);
  const cx = size / 2;
  const cy = size / 2;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const nx = (x - cx) / (size * 0.5);
      const ny = (y - cy) / (size * 0.5);
      const idx = (y * size + x) * 4;

      // Rounded square mask
      const rx = Math.max(0, Math.abs(nx) - 0.62);
      const ry = Math.max(0, Math.abs(ny) - 0.62);
      const cornerDist = Math.hypot(rx, ry);
      if (cornerDist > 0.34) {
        buf[idx + 3] = 0;
        continue;
      }

      // Indigo night sky gradient
      let r = Math.round(16 + (1 - ny) * 20);
      let g = Math.round(22 + (1 - ny) * 24);
      let b = Math.round(48 + (1 - ny) * 42);

      // Gold border
      if (cornerDist > 0.27) {
        r = 245; g = 196; b = 72;
      } else {
        // Warm rising moon behind torii
        if (Math.hypot(nx, ny + 0.08) < 0.44) {
          r = 255; g = 214; b = 128;
        }
        // Stylized Kyoto Torii gate silhouette
        const topBar = ny > -0.34 && ny < -0.20 && Math.abs(nx) < 0.54;
        const subBar = ny > -0.10 && ny < 0.0 && Math.abs(nx) < 0.44;
        const pillarL = nx > -0.34 && nx < -0.21 && ny > -0.22 && ny < 0.50;
        const pillarR = nx > 0.21 && nx < 0.34 && ny > -0.22 && ny < 0.50;
        const centerStrut = Math.abs(nx) < 0.06 && ny > -0.22 && ny < 0.0;
        if (topBar || subBar || pillarL || pillarR || centerStrut) {
          r = 218; g = 42; b = 52;
        }
        // Dark cap on top beam
        if (ny > -0.37 && ny <= -0.31 && Math.abs(nx) < 0.58) {
          r = 32; g = 24; b = 34;
        }
      }

      buf[idx] = Math.min(255, Math.max(0, r));
      buf[idx + 1] = Math.min(255, Math.max(0, g));
      buf[idx + 2] = Math.min(255, Math.max(0, b));
      buf[idx + 3] = 255;
    }
  }
  return encodePng(size, size, buf);
}

// Pack 256x256 PNG directly inside a standard Windows Vista+ ICO file
function wrapPngAsIco(pngBuf) {
  const header = Buffer.alloc(6);
  header.writeUInt16LE(0, 0); // reserved
  header.writeUInt16LE(1, 2); // type = icon
  header.writeUInt16LE(1, 4); // count = 1

  const entry = Buffer.alloc(16);
  entry[0] = 0; // 256px
  entry[1] = 0; // 256px
  entry[2] = 0; // palette
  entry[3] = 0; // reserved
  entry.writeUInt16LE(1, 4); // color planes
  entry.writeUInt16LE(32, 6); // bpp
  entry.writeUInt32LE(pngBuf.length, 8);
  entry.writeUInt32LE(22, 12); // offset = 6 + 16

  return Buffer.concat([header, entry, pngBuf]);
}

const outDir = path.resolve(__dirname, '..', 'build');
fs.mkdirSync(outDir, { recursive: true });
const png256 = drawKyotoIcon(256);
fs.writeFileSync(path.join(outDir, 'icon.png'), png256);
fs.writeFileSync(path.join(outDir, 'icon.ico'), wrapPngAsIco(png256));
console.log('Generated build/icon.png and build/icon.ico');
