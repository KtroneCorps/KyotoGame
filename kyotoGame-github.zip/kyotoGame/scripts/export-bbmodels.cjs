/**
 * Exports Blockbench 4.x (.bbmodel) project files for kyotoGame models
 * into models/*.bbmodel.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const MODELS_SPEC = [
  { id: 'thunder', name: 'Marteau de Foudre', color: '#38d9ff', accent: '#ffe066', cubes: [
    { name: 'handle', from: [-1, 0, -1], to: [1, 14, 1], color: 0 },
    { name: 'pommel', from: [-2, -2, -2], to: [2, 0, 2], color: 1 },
    { name: 'head_main', from: [-7, 13, -4], to: [7, 21, 4], color: 2 },
    { name: 'head_bevel', from: [-8, 14, -3], to: [8, 20, 3], color: 2 },
    { name: 'rune_band', from: [-8.2, 16, -1], to: [8.2, 18, 1], color: 3 },
  ]},
  { id: 'pyro', name: 'Espadon de Magma', color: '#ff6b2b', accent: '#ffd43b', cubes: [
    { name: 'handle', from: [-1, 0, -1], to: [1, 8, 1], color: 0 },
    { name: 'guard', from: [-6, 8, -2], to: [6, 10, 2], color: 1 },
    { name: 'blade_core', from: [-2.5, 10, -1], to: [2.5, 27, 1], color: 2 },
    { name: 'blade_edge', from: [-3.5, 10, -0.5], to: [3.5, 25, 0.5], color: 3 },
  ]},
  { id: 'cryo', name: 'Faux de Givre', color: '#74e8ff', accent: '#d8f9ff', cubes: [
    { name: 'staff', from: [-1, 0, -1], to: [1, 22, 1], color: 0 },
    { name: 'blade_1', from: [0, 19, -0.8], to: [10, 23, 0.8], color: 3 },
    { name: 'blade_tip', from: [9, 13, -0.6], to: [13, 21, 0.6], color: 1 },
  ]},
  { id: 'gravity', name: 'Sceptre Singulaire', color: '#b15cff', accent: '#ff87eb', cubes: [
    { name: 'staff', from: [-1, 0, -1], to: [1, 15, 1], color: 0 },
    { name: 'cradle_l', from: [-5, 14, -1], to: [-3, 21, 1], color: 1 },
    { name: 'cradle_r', from: [3, 14, -1], to: [5, 21, 1], color: 1 },
    { name: 'singularity', from: [-3, 17, -3], to: [3, 23, 3], color: 3 },
  ]},
  { id: 'wind', name: 'Éventail Zéphyr', color: '#63f5b8', accent: '#e6fff5', cubes: [
    { name: 'grip', from: [-1, 0, -1], to: [1, 7, 1], color: 1 },
    { name: 'fan_mid', from: [-2, 7, -0.5], to: [2, 20, 0.5], color: 3 },
    { name: 'fan_l', from: [-8, 8, -0.5], to: [-2, 18, 0.5], color: 2 },
    { name: 'fan_r', from: [2, 8, -0.5], to: [8, 18, 0.5], color: 2 },
  ]},
  { id: 'earth', name: 'Masse de Granit', color: '#d99a4e', accent: '#ffe09e', cubes: [
    { name: 'handle', from: [-1.2, 0, -1.2], to: [1.2, 14, 1.2], color: 0 },
    { name: 'boulder', from: [-6, 13, -5], to: [6, 23, 5], color: 2 },
    { name: 'amber_top', from: [-2, 22, -2], to: [2, 27, 2], color: 3 },
  ]},
  { id: 'shadow', name: 'Doubles Dagues Fantômes', color: '#7c4dff', accent: '#c792ff', cubes: [
    { name: 'grip_l', from: [-4, 0, -1], to: [-2, 6, 1], color: 0 },
    { name: 'blade_l', from: [-4, 6, -0.5], to: [-2, 19, 0.5], color: 3 },
    { name: 'grip_r', from: [2, 0, -1], to: [4, 6, 1], color: 0 },
    { name: 'blade_r', from: [2, 6, -0.5], to: [4, 19, 0.5], color: 3 },
  ]},
  { id: 'light', name: 'Espadon Solaire', color: '#ffd94a', accent: '#ffffff', cubes: [
    { name: 'hilt', from: [-1, 0, -1], to: [1, 8, 1], color: 1 },
    { name: 'wing_guard', from: [-7, 8, -1.5], to: [7, 10, 1.5], color: 1 },
    { name: 'solar_blade', from: [-2.2, 10, -0.8], to: [2.2, 28, 0.8], color: 3 },
  ]},
  { id: 'poison', name: 'Sceptre Alchimique', color: '#5df249', accent: '#c8ff75', cubes: [
    { name: 'staff', from: [-1, 0, -1], to: [1, 14, 1], color: 0 },
    { name: 'cage', from: [-4, 14, -4], to: [4, 22, 4], color: 2 },
    { name: 'acid_core', from: [-3, 15, -3], to: [3, 20, 3], color: 3 },
  ]},
  { id: 'chrono', name: 'Sablier Arcanique', color: '#34e8d6', accent: '#ffd166', cubes: [
    { name: 'staff', from: [-1, 0, -1], to: [1, 12, 1], color: 0 },
    { name: 'clock_bezel', from: [-6, 12, -1.5], to: [6, 24, 1.5], color: 1 },
    { name: 'clock_dial', from: [-5, 13, -1.7], to: [5, 23, 1.7], color: 3 },
  ]},
  { id: 'cyber', name: 'Katana Plasma Néon', color: '#ff3b9a', accent: '#29f0ff', cubes: [
    { name: 'hilt', from: [-1, 0, -1], to: [1, 7, 1], color: 0 },
    { name: 'guard', from: [-3.5, 7, -2], to: [3.5, 8.5, 2], color: 1 },
    { name: 'plasma_blade', from: [-1, 8.5, -0.5], to: [1.5, 28, 0.5], color: 3 },
  ]},
  { id: 'titan', name: 'Gantelet du Colosse', color: '#ffaa2b', accent: '#fff0b3', cubes: [
    { name: 'cuff', from: [-4.5, 0, -4.5], to: [4.5, 5, 4.5], color: 0 },
    { name: 'fist', from: [-6, 5, -5.5], to: [6, 16, 5.5], color: 1 },
    { name: 'rune_crest', from: [-2, 8, -6], to: [2, 13, 6], color: 3 },
  ]},
  { id: 'aqua', name: 'Trident des Abysses', color: '#1da1ff', accent: '#88f3ff', cubes: [
    { name: 'shaft', from: [-1, 0, -1], to: [1, 17, 1], color: 0 },
    { name: 'crossbar', from: [-6, 17, -1], to: [6, 19, 1], color: 1 },
    { name: 'prong_mid', from: [-1, 19, -1], to: [1, 29, 1], color: 3 },
    { name: 'prong_l', from: [-6, 19, -1], to: [-4.5, 27, 1], color: 3 },
    { name: 'prong_r', from: [4.5, 19, -1], to: [6, 27, 1], color: 3 },
  ]},
  { id: 'nature', name: 'Bâton Druidique', color: '#38d97c', accent: '#ff8fab', cubes: [
    { name: 'branch', from: [-1, 0, -1], to: [1, 17, 1], color: 0 },
    { name: 'blossom_core', from: [-3, 18, -3], to: [3, 24, 3], color: 3 },
  ]},
  { id: 'magma', name: 'Hache Volcanique', color: '#ff4221', accent: '#ffae2b', cubes: [
    { name: 'shaft', from: [-1, 0, -1], to: [1, 22, 1], color: 0 },
    { name: 'axe_l', from: [-9, 14, -1], to: [-1, 23, 1], color: 3 },
    { name: 'axe_r', from: [1, 14, -1], to: [9, 23, 1], color: 3 },
  ]},
  { id: 'blood', name: 'Faux Cramoisie', color: '#e62249', accent: '#ff809b', cubes: [
    { name: 'shaft', from: [-1, 0, -1], to: [1, 22, 1], color: 0 },
    { name: 'scythe_blade', from: [0, 18, -0.8], to: [11, 22, 0.8], color: 3 },
    { name: 'scythe_hook', from: [9, 11, -0.6], to: [12, 19, 0.6], color: 1 },
  ]},
  { id: 'sonic', name: 'Lames Supersoniques', color: '#00f2fe', accent: '#ffd43b', cubes: [
    { name: 'grip', from: [-1, 0, -1], to: [1, 7, 1], color: 0 },
    { name: 'blade_l', from: [-3, 7, -0.5], to: [-1.5, 24, 0.5], color: 3 },
    { name: 'blade_r', from: [1.5, 7, -0.5], to: [3, 24, 0.5], color: 3 },
  ]},
  { id: 'crystal', name: 'Lance de Diamant', color: '#5cf2ff', accent: '#e0aaff', cubes: [
    { name: 'shaft', from: [-1, 0, -1], to: [1, 16, 1], color: 0 },
    { name: 'diamond_head', from: [-3, 16, -3], to: [3, 29, 3], color: 3 },
  ]},
  { id: 'dragon', name: 'Hallebarde Draconique', color: '#ff9214', accent: '#ffe047', cubes: [
    { name: 'shaft', from: [-1, 0, -1], to: [1, 18, 1], color: 0 },
    { name: 'dragon_wings', from: [-7, 16, -1], to: [7, 20, 1], color: 1 },
    { name: 'dragon_blade', from: [-2, 19, -1], to: [2, 30, 1], color: 3 },
  ]},
  { id: 'void', name: 'Lame du Néant', color: '#9b30ff', accent: '#e7c6ff', cubes: [
    { name: 'hilt', from: [-1, 0, -1], to: [1, 8, 1], color: 0 },
    { name: 'shard_1', from: [-2.5, 10, -0.8], to: [2.5, 14, 0.8], color: 3 },
    { name: 'shard_2', from: [-2.2, 15, -0.8], to: [2.2, 19, 0.8], color: 3 },
    { name: 'shard_3', from: [-1.8, 20, -0.8], to: [1.8, 25, 0.8], color: 1 },
  ]},
  { id: 'star', name: 'Bâton Astral', color: '#ffe047', accent: '#9bf6ff', cubes: [
    { name: 'staff', from: [-1, 0, -1], to: [1, 18, 1], color: 0 },
    { name: 'star_core', from: [-3, 18, -3], to: [3, 24, 3], color: 3 },
  ]},
  { id: 'prism', name: 'Épée Arc-en-Ciel', color: '#ff66d9', accent: '#4df3ff', cubes: [
    { name: 'hilt', from: [-1, 0, -1], to: [1, 8, 1], color: 0 },
    { name: 'guard', from: [-6, 8, -1.5], to: [6, 10, 1.5], color: 1 },
    { name: 'prism_blade', from: [-2.2, 10, -0.7], to: [2.2, 28, 0.7], color: 3 },
  ]},
  { id: 'mecha', name: 'Canon-Gantelet Méca', color: '#ff5252', accent: '#40c4ff', cubes: [
    { name: 'arm_frame', from: [-5, 0, -5], to: [5, 14, 5], color: 2 },
    { name: 'barrel_l', from: [-4, 14, -2], to: [-1, 22, 1], color: 0 },
    { name: 'barrel_r', from: [1, 14, -2], to: [4, 22, 1], color: 0 },
  ]},
  { id: 'phoenix', name: 'Lame du Phénix', color: '#ff7b1c', accent: '#ffe866', cubes: [
    { name: 'hilt', from: [-1, 0, -1], to: [1, 8, 1], color: 0 },
    { name: 'wings', from: [-8, 8, -1], to: [8, 12, 1], color: 1 },
    { name: 'blade', from: [-2, 10, -0.7], to: [2, 28, 0.7], color: 3 },
  ]},
  { id: 'abyss', name: 'Ancre des Abysses', color: '#00d2a8', accent: '#125a70', cubes: [
    { name: 'shaft', from: [-2, 0, -2], to: [2, 22, 2], color: 0 },
    { name: 'stock', from: [-7, 16, -2], to: [7, 19, 2], color: 2 },
    { name: 'flukes', from: [-9, 0, -2], to: [9, 4, 2], color: 3 },
  ]},
  { id: 'sand', name: 'Bâton d’Anubis', color: '#f5c242', accent: '#2b6cb0', cubes: [
    { name: 'staff', from: [-1, 0, -1], to: [1, 17, 1], color: 0 },
    { name: 'ankh_bar', from: [-6, 16, -1.2], to: [6, 18.5, 1.2], color: 1 },
    { name: 'ankh_loop', from: [-3, 18.5, -1.2], to: [3, 26, 1.2], color: 3 },
  ]},
  { id: 'magnet', name: 'Marteau Magnétique', color: '#ff4757', accent: '#3792ff', cubes: [
    { name: 'handle', from: [-1, 0, -1], to: [1, 14, 1], color: 0 },
    { name: 'pole_red', from: [-7, 14, -3.5], to: [0, 21, 3.5], color: 3 },
    { name: 'pole_blue', from: [0, 14, -3.5], to: [7, 21, 3.5], color: 1 },
  ]},
  { id: 'samurai', name: 'Katana Sakura', color: '#ff6b9d', accent: '#ffffff', cubes: [
    { name: 'hilt', from: [-1, 0, -1], to: [1, 8, 1], color: 0 },
    { name: 'tsuba', from: [-3, 8, -3], to: [3, 9, 3], color: 1 },
    { name: 'katana_blade', from: [-0.8, 9, -0.4], to: [1.2, 29, 0.4], color: 3 },
  ]},
  // Battle Royale 3D Vehicles, Glider & Firearms
  { id: 'battle_plane', name: 'Avion Battle Royale', color: '#274c77', accent: '#ffd43b', cubes: [
    { name: 'fuselage', from: [-6, 0, -22], to: [6, 11, 22], color: 2 },
    { name: 'wings', from: [-34, 8, -8], to: [34, 10, 4], color: 1 },
    { name: 'tail_fin', from: [-1, 11, 16], to: [1, 23, 24], color: 3 },
    { name: 'engine_l', from: [-18, 5, -14], to: [-14, 9, -4], color: 0 },
    { name: 'engine_r', from: [14, 5, -14], to: [18, 9, -4], color: 0 },
  ]},
  { id: 'glider', name: 'Planeur Battle Royale', color: '#38d9ff', accent: '#ffd43b', cubes: [
    { name: 'canopy_mid', from: [-10, 12, -6], to: [10, 13.5, 6], color: 3 },
    { name: 'canopy_l', from: [-22, 10, -5], to: [-10, 11.5, 5], color: 2 },
    { name: 'canopy_r', from: [10, 10, -5], to: [22, 11.5, 5], color: 2 },
    { name: 'handlebar', from: [-6, 0, -0.5], to: [6, 1, 0.5], color: 0 },
  ]},
  { id: 'pistol', name: 'Pistolet Tactique', color: '#3f4a5e', accent: '#38d9ff', cubes: [
    { name: 'slide', from: [-1.5, 4, -8], to: [1.5, 8, 4], color: 2 },
    { name: 'grip', from: [-1.3, -4, 0], to: [1.3, 4, 3.5], color: 0 },
    { name: 'barrel', from: [-0.8, 5, -12], to: [0.8, 7, -8], color: 1 },
  ]},
  { id: 'rifle', name: 'Fusil Assaut', color: '#232a36', accent: '#b15cff', cubes: [
    { name: 'receiver', from: [-1.6, 3, -10], to: [1.6, 8, 6], color: 2 },
    { name: 'barrel', from: [-0.8, 4.5, -24], to: [0.8, 6.5, -10], color: 0 },
    { name: 'stock', from: [-1.4, 2, 6], to: [1.4, 7, 15], color: 0 },
    { name: 'mag', from: [-1, -5, -5], to: [1, 3, -1.5], color: 3 },
    { name: 'optic', from: [-1.3, 8, -3], to: [1.3, 11, 2], color: 1 },
  ]},
  { id: 'shotgun', name: 'Fusil a Pompe', color: '#6e4226', accent: '#ff7b29', cubes: [
    { name: 'receiver', from: [-1.8, 3, -8], to: [1.8, 8, 5], color: 2 },
    { name: 'barrel', from: [-1, 5, -26], to: [1, 7.5, -8], color: 0 },
    { name: 'pump', from: [-2, 2.5, -19], to: [2, 5.5, -11], color: 3 },
    { name: 'stock', from: [-1.5, 1, 5], to: [1.5, 7, 15], color: 1 },
  ]},
  { id: 'sniper', name: 'Sniper Lourd', color: '#232a36', accent: '#ffd43b', cubes: [
    { name: 'receiver', from: [-1.6, 3, -12], to: [1.6, 8, 6], color: 2 },
    { name: 'barrel', from: [-0.9, 4.5, -34], to: [0.9, 6.5, -12], color: 0 },
    { name: 'scope', from: [-1.5, 9, -12], to: [1.5, 12, 2], color: 3 },
    { name: 'stock', from: [-1.4, 2, 6], to: [1.4, 7, 17], color: 1 },
  ]},
  { id: 'smg', name: 'Mitraillette SMG', color: '#232a36', accent: '#38d9ff', cubes: [
    { name: 'body', from: [-1.6, 3, -11], to: [1.6, 8, 5], color: 2 },
    { name: 'barrel', from: [-0.8, 4.5, -17], to: [0.8, 6.5, -11], color: 0 },
    { name: 'ext_mag', from: [-0.9, -6, -6], to: [0.9, 3, -3.5], color: 3 },
  ]},
];

const outDir = path.resolve(__dirname, '..', 'models');
fs.mkdirSync(outDir, { recursive: true });

for (const spec of MODELS_SPEC) {
  const elements = spec.cubes.map((c) => ({
    name: c.name,
    box_uv: false,
    rescale: false,
    locked: false,
    from: c.from,
    to: c.to,
    autouv: 1,
    color: c.color,
    origin: [0, 0, 0],
    faces: {
      north: { uv: [0, 0, 16, 16], texture: 0 },
      east: { uv: [0, 0, 16, 16], texture: 0 },
      south: { uv: [0, 0, 16, 16], texture: 0 },
      west: { uv: [0, 0, 16, 16], texture: 0 },
      up: { uv: [0, 0, 16, 16], texture: 0 },
      down: { uv: [0, 0, 16, 16], texture: 0 },
    },
    type: 'cube',
    uuid: crypto.randomUUID(),
  }));

  const bbmodel = {
    meta: { format_version: '4.10', model_format: 'free', box_uv: false },
    name: spec.name,
    model_identifier: `kyoto_${spec.id}`,
    visible_box: [1, 1, 0],
    variable_placeholders: '',
    resolution: { width: 16, height: 16 },
    elements,
    outliner: elements.map((e) => e.uuid),
    textures: [],
  };

  fs.writeFileSync(path.join(outDir, `${spec.id}.bbmodel`), JSON.stringify(bbmodel, null, 2));
}

console.log(`Exported ${MODELS_SPEC.length} Blockbench .bbmodel files into models/`);
