const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

/**
 * Resolves the cloudflared binary path cleanly both in dev and inside packaged Electron (.exe asar.unpacked).
 */
function resolveCloudflaredBin() {
  try {
    const cf = require('cloudflared');
    let binPath = cf.bin;
    if (binPath && binPath.includes('app.asar') && !binPath.includes('app.asar.unpacked')) {
      const unpacked = binPath.replace('app.asar', 'app.asar.unpacked');
      if (fs.existsSync(unpacked)) return unpacked;
    }
    if (binPath && fs.existsSync(binPath)) return binPath;
  } catch {
    // Fallback to PATH
  }
  const localWin = path.resolve(__dirname, '..', 'node_modules', 'cloudflared', 'bin', 'cloudflared.exe');
  if (fs.existsSync(localWin)) return localWin;
  return 'cloudflared';
}

/**
 * Starts a free Cloudflare Quick Tunnel exposing a local HTTP+WS port under a public
 * https://xxxx.trycloudflare.com URL — ZERO IP sharing, ZERO router port forwarding
 */
class TunnelManager {
  constructor() {
    this.proc = null;
    this.publicUrl = null;
  }

  start(localPort, timeoutMs = 25000) {
    return new Promise((resolve, reject) => {
      if (this.proc && this.publicUrl) {
        resolve(this.publicUrl);
        return;
      }
      this.stop();

      const bin = resolveCloudflaredBin();
      const args = ['tunnel', '--url', `http://127.0.0.1:${localPort}`, '--no-autoupdate'];

      let settled = false;
      const timer = setTimeout(() => {
        if (!settled) {
          settled = true;
          this.stop();
          reject(new Error('Délai dépassé lors de la création du tunnel public (vérifie ta connexion internet).'));
        }
      }, timeoutMs);

      const proc = spawn(bin, args, {
        windowsHide: true,
        stdio: ['ignore', 'pipe', 'pipe'],
      });
      this.proc = proc;

      const handleLine = (chunk) => {
        const text = chunk.toString();
        const match = text.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/i);
        if (match && !settled) {
          settled = true;
          clearTimeout(timer);
          this.publicUrl = match[0];
          resolve(this.publicUrl);
        }
      };

      proc.stdout.on('data', handleLine);
      proc.stderr.on('data', handleLine);

      proc.on('error', (err) => {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          reject(new Error(`Impossible de lancer cloudflared (${err.message}).`));
        }
      });

      proc.on('exit', (code) => {
        this.proc = null;
        this.publicUrl = null;
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          reject(new Error(`Le tunnel s'est fermé prématurément (code ${code}).`));
        }
      });
    });
  }

  stop() {
    if (this.proc) {
      try {
        this.proc.kill();
      } catch {
        // ignore
      }
      this.proc = null;
    }
    this.publicUrl = null;
  }
}

module.exports = { TunnelManager, resolveCloudflaredBin };
