const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.glb': 'model/gltf-binary',
};

function createGameServer({ port = process.env.PORT || 3000, distDir } = {}) {
  const staticRoot = distDir || path.resolve(__dirname, '..', 'dist');
  const rooms = new Map(); // roomCode -> Map<playerId, clientEntry>
  const roomWorlds = new Map(); // roomCode -> custom world JSON
  const roomRankedQueues = new Map(); // roomCode -> Set<playerId>
  const roomRankedMatches = new Map(); // roomCode -> { active, scores, timer }
  const roomBRState = new Map(); // roomCode -> { seed, takenLoots: Set }
  let nextPlayerId = 1;

  function getOrCreateRoom(roomCode) {
    const code = (roomCode || 'PUBLIC').toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 16) || 'PUBLIC';
    if (!rooms.has(code)) rooms.set(code, new Map());
    return { code, members: rooms.get(code) };
  }

  function safeSend(ws, obj) {
    if (ws && ws.readyState === 1) {
      ws.send(JSON.stringify(obj));
    }
  }

  function broadcastRoom(roomCode, obj, excludeId = null) {
    const members = rooms.get(roomCode);
    if (!members) return;
    const payload = JSON.stringify(obj);
    for (const [id, entry] of members.entries()) {
      if (id !== excludeId && entry.ws.readyState === 1) {
        entry.ws.send(payload);
      }
    }
  }

  const server = http.createServer((req, res) => {
    const urlObj = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = decodeURIComponent(urlObj.pathname);

    // Health / Server Info API
    if (pathname === '/api/status') {
      let totalPlayers = 0;
      const roomSummary = [];
      for (const [code, members] of rooms.entries()) {
        totalPlayers += members.size;
        roomSummary.push({ code, players: members.size });
      }
      res.writeHead(200, {
        'Content-Type': 'application/json; charset=utf-8',
        'Access-Control-Allow-Origin': '*',
      });
      res.end(JSON.stringify({ ok: true, game: 'kyotoGame', totalPlayers, rooms: roomSummary }));
      return;
    }

    // Serve built static game files
    let filePath = path.join(staticRoot, pathname === '/' ? 'index.html' : pathname);
    if (!filePath.startsWith(staticRoot)) {
      res.writeHead(403);
      res.end('Forbidden');
      return;
    }

    fs.stat(filePath, (err, stats) => {
      if (err || !stats.isFile()) {
        // Fallback to index.html for clean URLs
        filePath = path.join(staticRoot, 'index.html');
      }
      fs.readFile(filePath, (readErr, data) => {
        if (readErr) {
          res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
          res.end('Build introuvable. Lancez npm run build.');
          return;
        }
        const ext = path.extname(filePath).toLowerCase();
        res.writeHead(200, {
          'Content-Type': MIME_TYPES[ext] || 'application/octet-stream',
          'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600',
        });
        res.end(data);
      });
    });
  });

  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws) => {
    const id = `p-${nextPlayerId++}`;
    let currentRoom = null;
    let entry = null;

    ws.on('message', (raw) => {
      let msg;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        return;
      }

      if (msg.type === 'join') {
        // Remove from previous room if any
        if (currentRoom && rooms.has(currentRoom)) {
          rooms.get(currentRoom).delete(id);
          broadcastRoom(currentRoom, { type: 'player_leave', id, name: entry?.state?.name || 'Joueur' });
        }

        const { code, members } = getOrCreateRoom(msg.room);
        currentRoom = code;

        const cleanName = String(msg.name || `Joueur${nextPlayerId}`).trim().slice(0, 18) || 'Joueur';
        entry = {
          ws,
          state: {
            id,
            name: cleanName,
            zone: msg.zone || 'dojo',
            powerId: msg.powerId || 'thunder',
            appearance: msg.appearance || {},
            x: 0,
            y: 0,
            z: 13.5,
            vx: 0,
            vy: 0,
            vz: 0,
            yaw: 0,
            pitch: 0,
            hp: 100,
            maxHp: 100,
            hits: 0,
            kos: 0,
            titan: false,
            frozen: false,
            knockedDown: false,
            isDead: false,
            isGliding: false,
            gunId: null,
            shield: 0,
            elo: Number(msg.elo) || 100,
            scale: 1,
          },
        };
        members.set(id, entry);

        const existingPlayers = [];
        for (const [otherId, other] of members.entries()) {
          if (otherId !== id) existingPlayers.push(other.state);
        }

        safeSend(ws, {
          type: 'welcome',
          id,
          room: code,
          players: existingPlayers,
          customWorld: roomWorlds.get(code) || null,
        });

        broadcastRoom(code, { type: 'player_join', player: entry.state }, id);
        return;
      }

      if (!entry || !currentRoom) return;

      if (msg.type === 'state') {
        const s = entry.state;
        s.x = Number(msg.x) || 0;
        s.y = Number(msg.y) || 0;
        s.z = Number(msg.z) || 0;
        s.vx = Number(msg.vx) || 0;
        s.vy = Number(msg.vy) || 0;
        s.vz = Number(msg.vz) || 0;
        s.yaw = Number(msg.yaw) || 0;
        s.pitch = Number(msg.pitch) || 0;
        const validZones = new Set(['dojo', 'arena', 'combo', 'custom', 'ranked', 'br']);
        s.zone = validZones.has(msg.zone) ? msg.zone : 'dojo';
        if (msg.powerId !== undefined) s.powerId = msg.powerId ? String(msg.powerId) : null;
        if (typeof msg.hp === 'number') s.hp = msg.hp;
        if (typeof msg.shield === 'number') s.shield = msg.shield;
        if (typeof msg.hits === 'number') s.hits = msg.hits;
        if (typeof msg.kos === 'number') s.kos = msg.kos;
        if (typeof msg.elo === 'number') s.elo = msg.elo;
        s.titan = Boolean(msg.titan);
        s.frozen = Boolean(msg.frozen);
        s.knockedDown = Boolean(msg.knockedDown);
        s.isDead = Boolean(msg.isDead);
        s.isGliding = Boolean(msg.isGliding);
        s.gunId = msg.gunId ? String(msg.gunId) : null;
        s.scale = Number(msg.scale) || 1;
        return;
      }

      if (msg.type === 'action') {
        broadcastRoom(
          currentRoom,
          {
            type: 'action',
            id,
            action: msg.action,
            powerId: msg.powerId || entry.state.powerId,
            pos: msg.pos,
            yaw: msg.yaw,
            pitch: msg.pitch,
          },
          id
        );
        return;
      }

      if (msg.type === 'hit') {
        const members = rooms.get(currentRoom);
        if (!members) return;
        const target = members.get(msg.targetId);
        if (target && target.ws.readyState === 1) {
          entry.state.hits += 1;
          safeSend(target.ws, {
            type: 'damaged',
            attackerId: id,
            attackerName: entry.state.name,
            attackerPower: entry.state.powerId,
            dmg: Math.min(60, Math.max(1, Number(msg.dmg) || 10)),
            kb: Array.isArray(msg.kb) ? msg.kb.slice(0, 3) : [0, 6, 0],
            status: msg.status || {},
          });
        }
        return;
      }

      if (msg.type === 'ko') {
        const members = rooms.get(currentRoom);
        const killer = msg.killerId && members ? members.get(msg.killerId) : null;
        if (killer) killer.state.kos += 1;
        broadcastRoom(currentRoom, {
          type: 'ko_event',
          victimId: id,
          victimName: entry.state.name,
          killerId: killer ? killer.state.id : null,
          killerName: killer ? killer.state.name : null,
          killerPower: killer ? killer.state.powerId : null,
        });

        // Track Ranked Match KOs (first to 3 KOs wins the Ranked Match)
        const match = roomRankedMatches.get(currentRoom);
        if (match && match.active && entry.state.zone === 'ranked') {
          if (killer && match.scores.has(killer.state.id)) {
            const nextScore = (match.scores.get(killer.state.id) || 0) + 1;
            match.scores.set(killer.state.id, nextScore);
            broadcastRoom(currentRoom, {
              type: 'ranked_score',
              scores: Object.fromEntries(match.scores),
            });
            if (nextScore >= 3) {
              match.active = false;
              clearTimeout(match.timer);
              broadcastRoom(currentRoom, {
                type: 'ranked_end',
                winnerId: killer.state.id,
                winnerName: killer.state.name,
                eloGain: 35,
                eloLoss: 15,
              });
              roomRankedMatches.delete(currentRoom);
            }
          }
        }
        return;
      }

      if (msg.type === 'ranked_queue_join') {
        if (!roomRankedQueues.has(currentRoom)) roomRankedQueues.set(currentRoom, new Set());
        const q = roomRankedQueues.get(currentRoom);
        q.add(id);
        const members = rooms.get(currentRoom);
        const players = [...q].map((pid) => ({
          id: pid,
          name: members?.get(pid)?.state?.name || 'Joueur',
          elo: members?.get(pid)?.state?.elo ?? 100,
        }));
        const names = players.map((p) => p.name);
        broadcastRoom(currentRoom, { type: 'ranked_queue', count: q.size, minPlayers: 2, names, players });

        // Start Ranked Match as soon as >= 2 players are in queue
        if (q.size >= 2 && !roomRankedMatches.get(currentRoom)?.active) {
          const participants = [...q];
          q.clear();
          const scores = new Map(participants.map((pid) => [pid, 0]));
          broadcastRoom(currentRoom, { type: 'ranked_start', participants, players, targetKOs: 3, duration: 90 });

          const timer = setTimeout(() => {
            const m = roomRankedMatches.get(currentRoom);
            if (!m || !m.active) return;
            m.active = false;
            let bestId = null;
            let bestScore = -1;
            for (const [pid, sc] of m.scores.entries()) {
              if (sc > bestScore) { bestScore = sc; bestId = pid; }
            }
            const winnerName = members?.get(bestId)?.state?.name || 'Égalité';
            broadcastRoom(currentRoom, {
              type: 'ranked_end',
              winnerId: bestScore > 0 ? bestId : null,
              winnerName,
              eloGain: 35,
              eloLoss: 15,
            });
            roomRankedMatches.delete(currentRoom);
          }, 90000);

          roomRankedMatches.set(currentRoom, { active: true, scores, timer });
        }
        return;
      }

      if (msg.type === 'ranked_queue_leave') {
        const q = roomRankedQueues.get(currentRoom);
        if (q) {
          q.delete(id);
          const members = rooms.get(currentRoom);
          const names = [...q].map((pid) => members?.get(pid)?.state?.name || 'Joueur');
          broadcastRoom(currentRoom, { type: 'ranked_queue', count: q.size, minPlayers: 2, names });
        }
        return;
      }

      if (msg.type === 'br_join') {
        let br = roomBRState.get(currentRoom);
        if (!br || msg.reset) {
          br = { seed: Math.floor(10000 + Math.random() * 899999), takenLoots: new Set() };
          roomBRState.set(currentRoom, br);
        }
        broadcastRoom(currentRoom, {
          type: 'br_sync',
          seed: br.seed,
          takenLoots: [...br.takenLoots],
          reset: Boolean(msg.reset),
        });
        return;
      }

      if (msg.type === 'br_loot' && msg.lootId) {
        const br = roomBRState.get(currentRoom);
        if (br) br.takenLoots.add(msg.lootId);
        broadcastRoom(currentRoom, { type: 'br_loot_taken', lootId: msg.lootId, by: id }, id);
        return;
      }

      if (msg.type === 'gunshot') {
        broadcastRoom(currentRoom, {
          type: 'gunshot',
          id,
          weaponId: msg.weaponId,
          start: msg.start,
          end: msg.end,
          color: msg.color,
        }, id);
        return;
      }

      if (msg.type === 'appearance') {
        entry.state.appearance = msg.appearance || {};
        return;
      }

      if (msg.type === 'world_sync' && msg.world) {
        roomWorlds.set(currentRoom, msg.world);
        broadcastRoom(currentRoom, { type: 'world_sync', senderName: entry.state.name, world: msg.world }, id);
        return;
      }

      if (msg.type === 'chat') {
        const text = String(msg.text || '').trim().slice(0, 140);
        if (!text) return;
        broadcastRoom(currentRoom, {
          type: 'chat',
          id,
          name: entry.state.name,
          text,
        });
      }
    });

    ws.on('close', () => {
      if (currentRoom && rooms.has(currentRoom)) {
        const q = roomRankedQueues.get(currentRoom);
        if (q) q.delete(id);
        const members = rooms.get(currentRoom);
        members.delete(id);
        broadcastRoom(currentRoom, {
          type: 'player_leave',
          id,
          name: entry?.state?.name || 'Joueur',
        });
        if (members.size === 0) {
          rooms.delete(currentRoom);
        }
      }
    });
  });

  // 20Hz Room State Snapshot Broadcaster
  const snapshotInterval = setInterval(() => {
    for (const [roomCode, members] of rooms.entries()) {
      if (members.size === 0) continue;
      const players = [];
      for (const entry of members.values()) {
        players.push(entry.state);
      }
      const payload = JSON.stringify({ type: 'snapshot', players });
      for (const entry of members.values()) {
        if (entry.ws.readyState === 1) {
          entry.ws.send(payload);
        }
      }
    }
  }, 50);

  return {
    server,
    wss,
    start() {
      return new Promise((resolve, reject) => {
        server.once('error', reject);
        server.listen(port, '0.0.0.0', () => {
          const addr = server.address();
          resolve({ port: addr.port });
        });
      });
    },
    stop() {
      clearInterval(snapshotInterval);
      wss.close();
      return new Promise((resolve) => server.close(() => resolve()));
    },
  };
}

if (require.main === module) {
  const srv = createGameServer({ port: Number(process.env.PORT) || 3000 });
  srv.start().then(({ port }) => {
    console.log(`[kyotoGame] Serveur multijoueur actif sur http://localhost:${port}`);
    console.log(`[kyotoGame] WebSocket: ws://localhost:${port}/ws`);
  });
}

module.exports = { createGameServer };
