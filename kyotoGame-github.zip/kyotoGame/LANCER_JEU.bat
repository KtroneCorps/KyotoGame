@echo off
cd /d "%~dp0"
if exist "release\kyotoGame.exe" (
  start "" "release\kyotoGame.exe"
) else if exist "release\win-unpacked\kyotoGame.exe" (
  start "" "release\win-unpacked\kyotoGame.exe"
) else (
  echo Executable introuvable. Lancez "npm run build:exe" d'abord.
  pause
)
