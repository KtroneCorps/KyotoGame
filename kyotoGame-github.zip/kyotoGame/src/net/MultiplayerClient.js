/**
 * WebSocket multiplayer client for kyotoGame.
 * Supports ws:// and wss:// (localhost, Render, VPS, or Cloudflare tunnels).
 */
export class MultiplayerClient {
  constructor(callbacks) {
    this.cb = callbacks;
    this.ws = null;
    this.connected = false;
    this.playerId = null;
    this.room = 'PUBLIC';
    this.serverUrl = '';
    this._stateTimer = 0;
  }

  static normalizeWsUrl(rawUrl) {
    let url = String(rawUrl || '').trim();
    if (!url) url = window.location.origin;

    // Strip any ?room=... query string before appending /ws
    try {
      if (!/^https?:\/\/|^wss?:\/\//i.test(url)) {
        url = (url.includes('localhost') || url.includes('127.0.0.1') ? 'http://' : 'https://') + url;
      }
      const u = new URL(url);
      const wsProto = u.protocol === 'https:' || u.protocol === 'wss:' ? 'wss:' : 'ws:';
      return `${wsProto}//${u.host}/ws`;
    } catch {
      return `ws://127.0.0.1:3000/ws`;
    }
  }

  connect({ serverUrl, name, room, powerId, appearance }) {
    this.disconnect();
    this.serverUrl = serverUrl;
    this.room = (room || 'PUBLIC').toUpperCase().trim() || 'PUBLIC';
    const wsUrl = MultiplayerClient.normalizeWsUrl(serverUrl);

    return new Promise((resolve, reject) => {
      let settled = false;
      const ws = new WebSocket(wsUrl);
      this.ws = ws;

      const timeout = setTimeout(() => {
        if (!settled) {
          settled = true;
          try { ws.close(); } catch { /* ignore */ }
          reject(new Error('Impossible de joindre le serveur (timeout).'));
        }
      }, 10000);

      ws.onopen = () => {
        ws.send(JSON.stringify({
          type: 'join',
          name,
          room: this.room,
          powerId,
          appearance,
          zone: 'dojo',
        }));
      };

      ws.onmessage = (event) => {
        let msg;
        try {
          msg = JSON.parse(event.data);
        } catch {
          return;
        }

        if (msg.type === 'welcome') {
          this.connected = true;
          this.playerId = msg.id;
          this.room = msg.room;
          if (!settled) {
            settled = true;
            clearTimeout(timeout);
            resolve({ id: msg.id, room: msg.room, players: msg.players || [] });
          }
          this.cb.onWelcome?.(msg);
          return;
        }

        if (msg.type === 'player_join') this.cb.onPlayerJoin?.(msg.player);
        else if (msg.type === 'player_leave') this.cb.onPlayerLeave?.(msg.id, msg.name);
        else if (msg.type === 'snapshot') this.cb.onSnapshot?.(msg.players);
        else if (msg.type === 'action') this.cb.onRemoteAction?.(msg);
        else if (msg.type === 'damaged') this.cb.onDamaged?.(msg);
        else if (msg.type === 'ko_event') this.cb.onKOEvent?.(msg);
        else if (msg.type === 'chat') this.cb.onChat?.(msg);
        else if (msg.type === 'world_sync') this.cb.onWorldSync?.(msg.world, msg.senderName);
        else if (msg.type === 'ranked_queue') this.cb.onRankedQueue?.(msg);
        else if (msg.type === 'ranked_start') this.cb.onRankedStart?.(msg);
        else if (msg.type === 'ranked_score') this.cb.onRankedScore?.(msg);
        else if (msg.type === 'ranked_end') this.cb.onRankedEnd?.(msg);
        else if (msg.type === 'br_sync') this.cb.onBRSync?.(msg);
        else if (msg.type === 'br_loot_taken') this.cb.onBRLootTaken?.(msg.lootId);
        else if (msg.type === 'gunshot') this.cb.onRemoteGunshot?.(msg);
      };

      ws.onerror = () => {
        if (!settled) {
          settled = true;
          clearTimeout(timeout);
          reject(new Error('Erreur de connexion au serveur multijoueur.'));
        }
      };

      ws.onclose = () => {
        const wasConnected = this.connected;
        this.connected = false;
        this.playerId = null;
        if (wasConnected) {
          this.cb.onDisconnect?.();
        }
      };
    });
  }

  disconnect() {
    if (this.ws) {
      this.ws.onclose = null;
      try { this.ws.close(); } catch { /* ignore */ }
      this.ws = null;
    }
    this.connected = false;
    this.playerId = null;
  }

  _send(obj) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(obj));
    }
  }

  sendState(dt, player, zone) {
    if (!this.connected) return;
    this._stateTimer += dt;
    if (this._stateTimer < 0.05) return; // 20Hz sync
    this._stateTimer = 0;

    this._send({
      type: 'state',
      x: Number(player.position.x.toFixed(2)),
      y: Number(player.position.y.toFixed(2)),
      z: Number(player.position.z.toFixed(2)),
      vx: Number(player.velocity.x.toFixed(2)),
      vy: Number(player.velocity.y.toFixed(2)),
      vz: Number(player.velocity.z.toFixed(2)),
      yaw: Number(player.yaw.toFixed(3)),
      pitch: Number(player.pitch.toFixed(3)),
      zone,
      powerId: player.hasPower ? player.powerId : null,
      hp: Math.round(player.hp),
      shield: Math.round(player.shield || 0),
      hits: player.hits,
      kos: player.kos,
      titan: player.titanTimer > 0,
      frozen: player.freezeTimer > 0,
      knockedDown: player.knockdownTimer > 0,
      isDead: player.isDead,
      isGliding: player.isGliding,
      gunId: player.equippedGunId,
      scale: Number(player.currentScale.toFixed(2)),
    });
  }

  sendAction(action, player) {
    if (!this.connected) return;
    this._send({
      type: 'action',
      action,
      powerId: player.powerId,
      pos: [player.position.x, player.position.y, player.position.z],
      yaw: player.yaw,
      pitch: player.pitch,
    });
  }

  sendHit(targetId, dmg, kbVec, status = {}) {
    if (!this.connected) return;
    this._send({
      type: 'hit',
      targetId,
      dmg,
      kb: kbVec ? [kbVec.x, kbVec.y, kbVec.z] : [0, 6, 0],
      status,
    });
  }

  sendKO(killerId) {
    if (!this.connected) return;
    this._send({ type: 'ko', killerId: killerId || null });
  }

  sendChat(text) {
    if (!this.connected) return;
    this._send({ type: 'chat', text });
  }

  sendAppearance(appearance) {
    if (!this.connected) return;
    this._send({ type: 'appearance', appearance });
  }

  sendWorldSync(worldData) {
    if (!this.connected || !worldData) return;
    this._send({ type: 'world_sync', world: worldData });
  }

  joinRankedQueue() { this._send({ type: 'ranked_queue_join' }); }
  leaveRankedQueue() { this._send({ type: 'ranked_queue_leave' }); }
  joinBR(reset = false) { this._send({ type: 'br_join', reset }); }
  sendBRLoot(lootId) { this._send({ type: 'br_loot', lootId }); }
  sendGunshot(weaponId, startVec, endVec, color) {
    if (!this.connected) return;
    this._send({
      type: 'gunshot',
      weaponId,
      start: [startVec.x, startVec.y, startVec.z],
      end: [endVec.x, endVec.y, endVec.z],
      color,
    });
  }
}
