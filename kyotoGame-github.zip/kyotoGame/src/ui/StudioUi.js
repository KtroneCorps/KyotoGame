import { POWERS } from '../powers/PowersData.js';
import {
  STUDIO_ITEMS,
  STUDIO_ITEM_MAP,
  SKY_PRESETS,
  GROUND_STYLES,
  CustomWorld,
} from '../world/CustomWorld.js';

const COLOR_SWATCHES = [
  '#4c7ef3', '#5cb85c', '#ffd43b', '#ff6b2b',
  '#e63946', '#9b5de5', '#29f0ff', '#ff75b5',
  '#f0f5fa', '#7b8799', '#5c361e', '#1e2536',
];

export class StudioUi {
  constructor(callbacks) {
    this.cb = callbacks;
    this.isActive = false;
    this.isEditorMode = true;
    this.toolMode = 'place'; // 'place' | 'select'
    this.gridSnap = true;
    this.isWorldModalOpen = false;

    this.activeType = 'block';
    this.draftColor = '#4c7ef3';
    this.draftScale = [3, 3, 3];
    this.draftRotY = 0;
    this.draftTitle = 'BIENVENUE';
    this.draftText = 'Écris ton message ici !';
    this.draftPowerId = 'thunder';

    this.toolbar = document.getElementById('studio-toolbar');
    this.palette = document.getElementById('studio-palette');
    this.inspector = document.getElementById('studio-inspector');
    this.worldModal = document.getElementById('studio-world-modal');

    this.btnTogglePlay = document.getElementById('st-btn-mode');
    this.btnToolMode = document.getElementById('st-btn-tool');
    this.btnSnap = document.getElementById('st-btn-snap');
    this.inspHeader = document.getElementById('st-insp-header');
    this.inspColor = document.getElementById('st-color-picker');
    this.inspSx = document.getElementById('st-sx');
    this.inspSy = document.getElementById('st-sy');
    this.inspSz = document.getElementById('st-sz');
    this.inspRot = document.getElementById('st-rot');
    this.inspTextGroup = document.getElementById('st-text-group');
    this.inspTitle = document.getElementById('st-title');
    this.inspText = document.getElementById('st-text');
    this.inspPowerGroup = document.getElementById('st-power-group');
    this.inspPower = document.getElementById('st-power');
    this.inspSelectedActions = document.getElementById('st-selected-actions');

    this._buildPalette();
    this._buildInspectorControls();
    this._buildWorldModalControls();
  }

  _buildPalette() {
    this.palette.innerHTML = '';
    STUDIO_ITEMS.forEach((item, idx) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'st-item-btn';
      btn.dataset.type = item.type;
      btn.innerHTML = `<span class="st-item-icon">${item.icon}</span><span class="st-item-name">${item.name}</span>`;
      if (idx < 9) {
        const k = document.createElement('span');
        k.className = 'st-item-key';
        k.textContent = String(idx + 1);
        btn.appendChild(k);
      }
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.selectBuildType(item.type);
      });
      this.palette.appendChild(btn);
    });
    this._highlightPalette();
  }

  _buildInspectorControls() {
    // Swatches
    const swWrap = document.getElementById('st-swatches');
    swWrap.innerHTML = '';
    COLOR_SWATCHES.forEach((hex) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'swatch-btn';
      b.style.background = hex;
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        this.inspColor.value = hex;
        this._emitInspectorPatch({ color: hex });
      });
      swWrap.appendChild(b);
    });

    // Power dropdown
    this.inspPower.innerHTML = POWERS.map((p) => `<option value="${p.id}">${p.name} — ${p.title}</option>`).join('');

    // Prevent game keybinds while typing inside inputs
    this.inspector.querySelectorAll('input, textarea, select').forEach((el) => {
      el.addEventListener('keydown', (e) => e.stopPropagation());
    });

    this.inspColor.addEventListener('input', () => this._emitInspectorPatch({ color: this.inspColor.value }));
    const onScale = () => {
      const s = [
        parseFloat(this.inspSx.value) || 1,
        parseFloat(this.inspSy.value) || 1,
        parseFloat(this.inspSz.value) || 1,
      ];
      document.getElementById('st-val-s').textContent = `${s[0].toFixed(1)} × ${s[1].toFixed(1)} × ${s[2].toFixed(1)}`;
      this._emitInspectorPatch({ scale: s });
    };
    this.inspSx.addEventListener('input', onScale);
    this.inspSy.addEventListener('input', onScale);
    this.inspSz.addEventListener('input', onScale);

    this.inspRot.addEventListener('input', () => {
      const deg = parseFloat(this.inspRot.value) || 0;
      document.getElementById('st-val-rot').textContent = `${Math.round(deg)}°`;
      this._emitInspectorPatch({ rotY: (deg * Math.PI) / 180 });
    });

    this.inspTitle.addEventListener('input', () => this._emitInspectorPatch({ title: this.inspTitle.value }));
    this.inspText.addEventListener('input', () => this._emitInspectorPatch({ text: this.inspText.value }));
    this.inspPower.addEventListener('change', () => this._emitInspectorPatch({ powerId: this.inspPower.value }));

    // Position nudge buttons
    document.querySelectorAll('[data-nudge]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const [axis, delta] = btn.dataset.nudge.split(':');
        this.cb.onNudgeSelected(axis, parseFloat(delta));
      });
    });

    document.getElementById('st-btn-dup').addEventListener('click', (e) => {
      e.stopPropagation();
      this.cb.onDuplicateSelected();
    });
    document.getElementById('st-btn-del').addEventListener('click', (e) => {
      e.stopPropagation();
      this.cb.onDeleteSelected();
    });

    // Top toolbar buttons
    this.btnTogglePlay.addEventListener('click', (e) => {
      e.stopPropagation();
      this.cb.onTogglePlayMode();
    });
    this.btnToolMode.addEventListener('click', (e) => {
      e.stopPropagation();
      this.setToolMode(this.toolMode === 'place' ? 'select' : 'place');
    });
    this.btnSnap.addEventListener('click', (e) => {
      e.stopPropagation();
      this.gridSnap = !this.gridSnap;
      this.btnSnap.textContent = this.gridSnap ? '🧲 Grille: ON' : '🧲 Grille: OFF';
      this.btnSnap.classList.toggle('active', this.gridSnap);
    });
    document.getElementById('st-btn-world').addEventListener('click', (e) => {
      e.stopPropagation();
      this.setWorldModalOpen(true);
    });
    document.getElementById('st-btn-save').addEventListener('click', (e) => {
      e.stopPropagation();
      this.cb.onSaveWorld();
    });
  }

  _buildWorldModalControls() {
    const skySel = document.getElementById('st-w-sky');
    skySel.innerHTML = Object.entries(SKY_PRESETS)
      .map(([k, v]) => `<option value="${k}">${v.name}</option>`)
      .join('');

    const groundSel = document.getElementById('st-w-ground');
    groundSel.innerHTML = Object.entries(GROUND_STYLES)
      .map(([k, v]) => `<option value="${k}">${v.name}</option>`)
      .join('');

    this.worldModal.querySelectorAll('input, textarea, select').forEach((el) => {
      el.addEventListener('keydown', (e) => e.stopPropagation());
    });

    document.getElementById('st-w-close').addEventListener('click', () => {
      this.setWorldModalOpen(false);
    });

    document.getElementById('st-w-apply').addEventListener('click', () => {
      this.cb.onApplyWorldSettings({
        name: document.getElementById('st-w-name').value.trim() || 'Mon Monde',
        welcomeText: document.getElementById('st-w-welcome').value.trim(),
        skyPreset: skySel.value,
        groundStyle: groundSel.value,
        groundSize: parseInt(document.getElementById('st-w-size').value, 10) || 80,
        combatMode: document.getElementById('st-w-combat').value,
        gravity: parseInt(document.getElementById('st-w-grav').value, 10) || 30,
      });
      this.setWorldModalOpen(false);
    });

    document.querySelectorAll('[data-template]').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.cb.onLoadTemplate(btn.dataset.template);
        this.setWorldModalOpen(false);
      });
    });

    document.getElementById('st-w-export').addEventListener('click', () => {
      const json = this.cb.onExportWorldJson();
      const box = document.getElementById('st-w-json');
      box.value = json;
      box.select();
      if (window.kyotoDesktop?.copyText) window.kyotoDesktop.copyText(json);
      else if (navigator.clipboard) navigator.clipboard.writeText(json);
    });

    document.getElementById('st-w-import').addEventListener('click', () => {
      const raw = document.getElementById('st-w-json').value.trim();
      if (!raw) return;
      this.cb.onImportWorldJson(raw);
      this.setWorldModalOpen(false);
    });
  }

  _emitInspectorPatch(patch) {
    if (patch.color !== undefined) this.draftColor = patch.color;
    if (patch.scale !== undefined) this.draftScale = patch.scale;
    if (patch.rotY !== undefined) this.draftRotY = patch.rotY;
    if (patch.title !== undefined) this.draftTitle = patch.title;
    if (patch.text !== undefined) this.draftText = patch.text;
    if (patch.powerId !== undefined) this.draftPowerId = patch.powerId;
    this.cb.onInspectorChange(patch);
  }

  selectBuildType(type) {
    const def = STUDIO_ITEM_MAP[type];
    if (!def) return;
    this.activeType = type;
    this.draftColor = def.defaultColor;
    this.draftScale = [...def.defaultScale];
    if (def.defaultTitle !== undefined) this.draftTitle = def.defaultTitle;
    if (def.defaultText !== undefined) this.draftText = def.defaultText;
    if (def.defaultPowerId !== undefined) this.draftPowerId = def.defaultPowerId;
    this.setToolMode('place');
    this._highlightPalette();
    this.cb.onSelectBuildType(type);
    this.syncInspector(null);
  }

  setToolMode(mode) {
    this.toolMode = mode;
    this.btnToolMode.textContent = mode === 'place' ? '🧱 Outil: Placer (X)' : '🖱️ Outil: Sélection (X)';
    this.btnToolMode.classList.toggle('active', mode === 'select');
    this.cb.onToolModeChange(mode);
  }

  _highlightPalette() {
    this.palette.querySelectorAll('.st-item-btn').forEach((b) => {
      b.classList.toggle('active', b.dataset.type === this.activeType);
    });
  }

  setStudioActive(active, isEditorMode) {
    this.isActive = active;
    this.isEditorMode = isEditorMode;
    this.toolbar.classList.toggle('hidden', !active);
    this.palette.classList.toggle('hidden', !active || !isEditorMode);
    this.inspector.classList.toggle('hidden', !active || !isEditorMode);
    if (!active) this.setWorldModalOpen(false);

    this.btnTogglePlay.textContent = isEditorMode ? '🎮 Tester / Jouer (TAB)' : '🛠️ Retour Éditeur (TAB)';
    this.btnTogglePlay.className = isEditorMode ? 'st-btn play' : 'st-btn edit';
  }

  syncInspector(selectedSpec) {
    const type = selectedSpec ? selectedSpec.type : this.activeType;
    const def = STUDIO_ITEM_MAP[type] || STUDIO_ITEMS[0];
    const color = selectedSpec ? selectedSpec.color : this.draftColor;
    const scale = selectedSpec ? selectedSpec.scale : this.draftScale;
    const rotY = selectedSpec ? selectedSpec.rotY || 0 : this.draftRotY;
    const title = selectedSpec ? selectedSpec.title || '' : this.draftTitle;
    const text = selectedSpec ? selectedSpec.text || '' : this.draftText;
    const powerId = selectedSpec ? selectedSpec.powerId || 'thunder' : this.draftPowerId;

    this.inspHeader.textContent = selectedSpec
      ? `Sélection : ${def.icon} ${def.name}`
      : `À poser : ${def.icon} ${def.name}`;

    this.inspColor.value = color || '#4c7ef3';
    this.inspSx.value = String(scale[0]);
    this.inspSy.value = String(scale[1]);
    this.inspSz.value = String(scale[2]);
    document.getElementById('st-val-s').textContent = `${Number(scale[0]).toFixed(1)} × ${Number(scale[1]).toFixed(1)} × ${Number(scale[2]).toFixed(1)}`;

    const deg = ((rotY * 180) / Math.PI + 360) % 360;
    this.inspRot.value = String(Math.round(deg));
    document.getElementById('st-val-rot').textContent = `${Math.round(deg)}°`;

    const hasText = type === 'sign' || type === 'text3d';
    this.inspTextGroup.classList.toggle('hidden', !hasText);
    if (hasText) {
      this.inspTitle.value = title;
      this.inspText.value = text;
    }

    this.inspPowerGroup.classList.toggle('hidden', type !== 'pedestal');
    if (type === 'pedestal') {
      this.inspPower.value = powerId;
    }

    this.inspSelectedActions.classList.toggle('hidden', !selectedSpec);
  }

  setWorldModalOpen(open, worldData = null) {
    this.isWorldModalOpen = open;
    this.worldModal.classList.toggle('open', open);
    if (open) {
      if (document.pointerLockElement) document.exitPointerLock();
      const d = worldData || this.cb.getWorldData();
      if (d) {
        document.getElementById('st-w-name').value = d.name || '';
        document.getElementById('st-w-welcome').value = d.welcomeText || '';
        document.getElementById('st-w-sky').value = d.skyPreset || 'day';
        document.getElementById('st-w-ground').value = d.groundStyle || 'grass';
        document.getElementById('st-w-size').value = String(d.groundSize || 80);
        document.getElementById('st-w-combat').value = d.combatMode || 'combo';
        document.getElementById('st-w-grav').value = String(d.gravity || 30);
      }
      this._renderSavedWorlds();
    }
    this.cb.onWorldModalToggle?.(open);
  }

  _renderSavedWorlds() {
    const wrap = document.getElementById('st-saved-list');
    const list = CustomWorld.listSavedWorlds();
    if (!list.length) {
      wrap.innerHTML = '<div class="st-empty">Aucun monde sauvegardé pour l’instant. Clique sur « 💾 Sauver » !</div>';
      return;
    }
    wrap.innerHTML = '';
    list.forEach((w) => {
      const row = document.createElement('div');
      row.className = 'st-saved-row';
      row.innerHTML = `
        <div>
          <div class="st-saved-name">${w.name}</div>
          <div class="st-saved-meta">${(w.objects || []).length} objets • ${w.combatMode === 'combo' ? 'Mode Combo' : 'Classique'}</div>
        </div>
        <div class="st-saved-btns">
          <button class="btn-secondary mp-copy-small" data-load>Charger</button>
          <button class="btn-danger mp-copy-small" data-del>✕</button>
        </div>
      `;
      row.querySelector('[data-load]').addEventListener('click', () => {
        this.cb.onLoadSavedWorld(w);
        this.setWorldModalOpen(false);
      });
      row.querySelector('[data-del]').addEventListener('click', () => {
        CustomWorld.deleteSavedWorld(w.id);
        this._renderSavedWorlds();
      });
      wrap.appendChild(row);
    });
  }
}
