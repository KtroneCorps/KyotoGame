import { CHARACTER_OPTIONS } from '../models/LowPolyModels.js';
import { getRankForElo, WEAPONS } from '../weapons/WeaponsData.js';

const HOOK_POWERS = new Set(['abyss', 'nature', 'magnet', 'void', 'gravity']);
const SHIELD_POWERS = new Set(['cryo', 'earth', 'crystal', 'titan', 'light', 'sand']);
const LEAP_POWERS = new Set(['thunder', 'wind', 'shadow', 'sonic', 'samurai', 'phoenix', 'dragon', 'chrono']);

export class HudManager {
  constructor(callbacks) {
    this.cb = callbacks;

    this.zonePill = document.getElementById('zone-pill');
    this.zoneStatus = document.getElementById('zone-status');
    this.lockHint = document.getElementById('lock-hint');
    this.hpText = document.getElementById('hp-text');
    this.hpFill = document.getElementById('hp-fill');
    this.shieldRow = document.getElementById('shield-row');
    this.shieldFill = document.getElementById('shield-fill');
    this.shieldText = document.getElementById('shield-text');
    this.hudRankPill = document.getElementById('hud-rank-pill');
    this.statusBadges = document.getElementById('status-badges');
    this.leaderboardList = document.getElementById('leaderboard-list');
    this.killFeed = document.getElementById('kill-feed');
    this.hitsCounter = document.getElementById('hits-counter');
    this.koCounter = document.getElementById('ko-counter');

    this.equippedPowerTag = document.getElementById('equipped-power-tag');
    this.equippedPowerName = document.getElementById('equipped-power-name');
    this.equippedPowerDot = document.getElementById('equipped-power-dot');
    this.camModePill = document.getElementById('cam-mode-pill');

    this.slotAb1 = document.getElementById('slot-ab1');
    this.iconAb1 = document.getElementById('icon-ab1');
    this.nameAb1 = document.getElementById('name-ab1');
    this.cdMask1 = document.getElementById('cd-mask-1');
    this.cdText1 = document.getElementById('cd-text-1');

    this.slotAb2 = document.getElementById('slot-ab2');
    this.iconAb2 = document.getElementById('icon-ab2');
    this.nameAb2 = document.getElementById('name-ab2');
    this.cdMask2 = document.getElementById('cd-mask-2');
    this.cdText2 = document.getElementById('cd-text-2');

    this.slotAb3 = document.getElementById('slot-ab3');
    this.iconAb3 = document.getElementById('icon-ab3');
    this.nameAb3 = document.getElementById('name-ab3');
    this.cdMask3 = document.getElementById('cd-mask-3');
    this.cdText3 = document.getElementById('cd-text-3');

    this.cdMaskDash = document.getElementById('cd-mask-dash');
    this.cdTextDash = document.getElementById('cd-text-dash');

    // Crosshair & Sniper Scope
    this.crosshair = document.getElementById('crosshair');
    this.sniperScope = document.getElementById('sniper-scope');

    // Ranked Queue Overlay
    this.rankedQueueOverlay = document.getElementById('ranked-queue-overlay');
    this.rqRankBadge = document.getElementById('rq-rank-badge');
    this.rqTitle = document.getElementById('rq-title');
    this.rqCount = document.getElementById('rq-count');
    this.rqNames = document.getElementById('rq-names');

    // Battle Royale UI
    this.brMinimapCard = document.getElementById('br-minimap-card');
    this.brMinimapCanvas = document.getElementById('br-minimap-canvas');
    this.brStormStatus = document.getElementById('br-storm-status');
    this.brFullMapOverlay = document.getElementById('br-fullmap-overlay');
    this.brFullMapCanvas = document.getElementById('br-fullmap-canvas');
    this.brFlightPrompt = document.getElementById('br-flight-prompt');
    this.brLootPrompt = document.getElementById('br-loot-prompt');
    this.brLootName = document.getElementById('br-loot-name');
    this.brHotbar = document.getElementById('br-hotbar');
    this.brAmmoPill = document.getElementById('br-ammo-pill');
    this.brSlotEls = [0, 1, 2].map((i) => document.querySelector(`.br-slot[data-br-slot="${i}"]`));

    this.pedPrompt = document.getElementById('pedestal-prompt');
    this.pedBadge = document.getElementById('ped-badge');
    this.pedName = document.getElementById('ped-name');
    this.pedDesc = document.getElementById('ped-desc');
    this.pedLmb = document.getElementById('ped-lmb');
    this.pedAb1 = document.getElementById('ped-ab1');
    this.pedAb2 = document.getElementById('ped-ab2');
    this.pedCta = document.getElementById('ped-cta');

    this.hitmarker = document.getElementById('hitmarker');
    this.damageVignette = document.getElementById('damage-vignette');
    this.warpOverlay = document.getElementById('warp-overlay');
    this.freezeOverlay = document.getElementById('freeze-overlay');
    this.titanOverlay = document.getElementById('titan-overlay');
    this.hpCard = document.querySelector('.hp-card');
    this.respawnOverlay = document.getElementById('respawn-overlay');
    this.respawnKiller = document.getElementById('respawn-killer');
    this.respawnCountdown = document.getElementById('respawn-countdown');
    this.respawnBarFill = document.getElementById('respawn-bar-fill');
    this.knockdownHud = document.getElementById('knockdown-hud');
    this.kdTitle = document.getElementById('kd-title');
    this.kdSub = document.getElementById('kd-sub');
    this.kdBarFill = document.getElementById('kd-bar-fill');
    this.comboBadge = document.getElementById('combo-badge');

    // Modals & Multiplayer UI
    this.settingsModal = document.getElementById('settings-modal');
    this.mpModal = document.getElementById('multiplayer-modal');
    this.customizerModal = document.getElementById('customizer-modal');
    this.mpPseudo = document.getElementById('mp-pseudo');
    this.mpRoom = document.getElementById('mp-room');
    this.mpServerUrl = document.getElementById('mp-server-url');
    this.mpStatusLine = document.getElementById('mp-status-line');
    this.mpInviteBox = document.getElementById('mp-invite-box');
    this.mpInviteUrl = document.getElementById('mp-invite-url');
    this.mpEnvBadge = document.getElementById('mp-env-badge');
    this.btnMpHost = document.getElementById('btn-mp-host');
    this.btnMpDisconnect = document.getElementById('btn-mp-disconnect');
    this.btnMpClose = document.getElementById('btn-mp-close');

    this.onlineBanner = document.getElementById('online-banner');
    this.onlineBannerText = document.getElementById('online-banner-text');
    this.btnHudCopy = document.getElementById('btn-hud-copy');

    this.chatPanel = document.getElementById('chat-panel');
    this.chatMessages = document.getElementById('chat-messages');
    this.chatInput = document.getElementById('chat-input');
    this.isChatTyping = false;

    this.isSettingsOpen = false;
    this.isMpOpen = true;
    this.isCustomizerOpen = false;
    this.currentInviteUrl = '';
    this._hitTimer = null;
    this._dmgTimer = null;

    this._initMultiplayerDefaults();
    this._initCustomizerUI();
    this._bindControls();
  }

  get isModalOpen() {
    return this.isSettingsOpen || this.isMpOpen || this.isCustomizerOpen;
  }

  _initCustomizerUI() {
    const buildSwatches = (containerId, list, field) => {
      const wrap = document.getElementById(containerId);
      if (!wrap) return;
      wrap.innerHTML = '';
      list.forEach((item) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'swatch-btn';
        btn.title = item.name;
        btn.dataset.hex = String(item.hex);
        btn.style.background = '#' + item.hex.toString(16).padStart(6, '0');
        btn.addEventListener('click', () => {
          this.cb.onAppearanceChange(field, item.hex);
        });
        wrap.appendChild(btn);
      });
    };

    buildSwatches('swatches-skin', CHARACTER_OPTIONS.skins, 'skinHex');
    buildSwatches('swatches-shirt', CHARACTER_OPTIONS.shirts, 'shirtHex');
    buildSwatches('swatches-pants', CHARACTER_OPTIONS.pants, 'pantsHex');
    buildSwatches('swatches-hair', CHARACTER_OPTIONS.hairs, 'hairHex');

    const fillSelect = (id, items, field) => {
      const sel = document.getElementById(id);
      if (!sel) return;
      sel.innerHTML = items.map((label, idx) => `<option value="${idx}">${label}</option>`).join('');
      sel.addEventListener('change', () => {
        this.cb.onAppearanceChange(field, parseInt(sel.value, 10));
      });
    };
    fillSelect('cust-hat', CHARACTER_OPTIONS.hats, 'hatStyle');
    fillSelect('cust-face', CHARACTER_OPTIONS.faces, 'faceStyle');
    fillSelect('cust-back', CHARACTER_OPTIONS.backs, 'backStyle');

    document.getElementById('btn-cust-random')?.addEventListener('click', () => {
      this.cb.onRandomizeAppearance();
    });
    document.getElementById('btn-cust-done')?.addEventListener('click', () => {
      this.setCustomizerOpen(false);
      this.cb.onResume();
    });
  }

  syncCustomizerUI(app) {
    const mark = (id, val) => {
      document.querySelectorAll(`#${id} .swatch-btn`).forEach((b) => {
        b.classList.toggle('active', Number(b.dataset.hex) === val);
      });
    };
    mark('swatches-skin', app.skinHex);
    mark('swatches-shirt', app.shirtHex);
    mark('swatches-pants', app.pantsHex);
    mark('swatches-hair', app.hairHex);

    const setSel = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.value = String(val ?? 0);
    };
    setSel('cust-hat', app.hatStyle);
    setSel('cust-face', app.faceStyle);
    setSel('cust-back', app.backStyle);
  }

  setCustomizerOpen(open) {
    this.isCustomizerOpen = open;
    if (open) {
      this.isSettingsOpen = false;
      this.isMpOpen = false;
      this.settingsModal.classList.remove('open');
      this.mpModal.classList.remove('open');
      if (document.pointerLockElement) document.exitPointerLock();
    }
    this.customizerModal.classList.toggle('open', open);
    this.cb.onCustomizerToggle?.(open);
  }

  _initMultiplayerDefaults() {
    const isDesktop = Boolean(window.kyotoDesktop?.isDesktop);
    this.mpEnvBadge.textContent = isDesktop ? 'APPLICATION .EXE' : 'NAVIGATEUR WEB';

    const quitBtn = document.getElementById('btn-quit-app');
    if (isDesktop && quitBtn) {
      quitBtn.classList.remove('hidden');
      quitBtn.addEventListener('click', () => window.kyotoDesktop.quitApp());
    }

    const savedName = localStorage.getItem('kyoto_pseudo') || `Joueur${Math.floor(100 + Math.random() * 899)}`;
    this.mpPseudo.value = savedName;

    // Pre-fill room code when opened from an invite link (?room=XXXX)
    const params = new URLSearchParams(window.location.search);
    const urlRoom = params.get('room');
    if (urlRoom) {
      this.mpRoom.value = urlRoom.toUpperCase();
    }
    if (!isDesktop && window.location.protocol.startsWith('http') && !window.location.host.includes(':5173')) {
      this.mpServerUrl.value = window.location.origin;
      if (urlRoom) {
        this.setMpStatus(`Lien d'invitation détecté ! Entre ton pseudo et clique sur Rejoindre.`, 'success');
      }
    }

    if (!isDesktop) {
      this.btnMpHost.textContent = 'Héberger (via kyotoGame.exe)';
    }
  }

  _bindControls() {
    document.getElementById('btn-multi').addEventListener('click', (e) => {
      e.stopPropagation();
      this.setMpOpen(true);
    });
    document.getElementById('btn-br')?.addEventListener('click', (e) => {
      e.stopPropagation();
      this.cb.onOpenBR?.();
    });
    document.getElementById('btn-ranked')?.addEventListener('click', (e) => {
      e.stopPropagation();
      this.cb.onOpenRanked?.();
    });
    document.getElementById('btn-leave-ranked')?.addEventListener('click', (e) => {
      e.stopPropagation();
      this.cb.onLeaveRankedQueue?.();
    });
    document.getElementById('btn-studio')?.addEventListener('click', (e) => {
      e.stopPropagation();
      this.cb.onOpenStudio?.();
    });
    document.getElementById('btn-customizer').addEventListener('click', (e) => {
      e.stopPropagation();
      this.setCustomizerOpen(true);
    });
    document.getElementById('btn-camera').addEventListener('click', (e) => {
      e.stopPropagation();
      this.cb.onToggleCamera();
    });
    document.getElementById('btn-dojo').addEventListener('click', (e) => {
      e.stopPropagation();
      this.cb.onGoToDojo();
    });
    document.getElementById('btn-settings').addEventListener('click', (e) => {
      e.stopPropagation();
      this.setSettingsOpen(true);
    });
    document.getElementById('btn-open-multi').addEventListener('click', () => {
      this.setSettingsOpen(false);
      this.setMpOpen(true);
    });
    document.getElementById('btn-resume').addEventListener('click', () => {
      this.setSettingsOpen(false);
      this.cb.onResume();
    });
    document.getElementById('btn-goto-dojo').addEventListener('click', () => {
      this.setSettingsOpen(false);
      this.cb.onGoToDojo();
      this.cb.onResume();
    });
    document.getElementById('btn-reset').addEventListener('click', () => {
      this.cb.onResetStats();
      this.pushFeed('Score réinitialisé !', '#ffd43b');
    });

    // Multiplayer modal actions
    document.getElementById('btn-mp-solo').addEventListener('click', () => {
      this._savePseudo();
      this.cb.onPlaySolo(this.getPseudo());
      this.setMpOpen(false);
      this.cb.onResume();
    });

    this.btnMpHost.addEventListener('click', () => {
      this._savePseudo();
      this.cb.onHostOnline(this.getPseudo(), this.getRoomCode());
    });

    document.getElementById('btn-mp-join').addEventListener('click', () => {
      this._savePseudo();
      const rawUrl = this.mpServerUrl.value.trim();
      // Auto-parse ?room= if friend pasted full invite URL
      let room = this.getRoomCode();
      try {
        const u = new URL(rawUrl.startsWith('http') ? rawUrl : `https://${rawUrl}`);
        const r = u.searchParams.get('room');
        if (r) {
          room = r.toUpperCase();
          this.mpRoom.value = room;
        }
      } catch { /* ignore */ }
      this.cb.onJoinServer(rawUrl, this.getPseudo(), room);
    });

    document.getElementById('btn-mp-copy').addEventListener('click', () => this._copyInvite());
    this.btnHudCopy.addEventListener('click', (e) => {
      e.stopPropagation();
      this._copyInvite();
    });

    this.btnMpDisconnect.addEventListener('click', () => {
      this.cb.onDisconnect();
    });

    this.btnMpClose.addEventListener('click', () => {
      this.setMpOpen(false);
      this.cb.onResume();
    });

    // Chat input events
    this.chatInput.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.code === 'Enter') {
        const txt = this.chatInput.value.trim();
        if (txt) this.cb.onSendChat(txt);
        this.closeChatInput();
      } else if (e.code === 'Escape') {
        this.closeChatInput();
      }
    });

    // Settings sliders
    const optSens = document.getElementById('opt-sens');
    const valSens = document.getElementById('val-sens');
    optSens.addEventListener('input', () => {
      const v = parseFloat(optSens.value);
      valSens.textContent = v.toFixed(1);
      this.cb.onSettingChange('sensitivity', v);
    });

    const optFov = document.getElementById('opt-fov');
    const valFov = document.getElementById('val-fov');
    optFov.addEventListener('input', () => {
      const v = parseInt(optFov.value, 10);
      valFov.textContent = String(v);
      this.cb.onSettingChange('fov', v);
    });

    const optSfx = document.getElementById('opt-sfx');
    const valSfx = document.getElementById('val-sfx');
    optSfx.addEventListener('input', () => {
      const v = parseInt(optSfx.value, 10);
      valSfx.textContent = `${v}%`;
      this.cb.onSettingChange('sfxVolume', v / 100);
    });

    const optAmbVol = document.getElementById('opt-amb-vol');
    const valAmb = document.getElementById('val-amb');
    optAmbVol.addEventListener('input', () => {
      const v = parseInt(optAmbVol.value, 10);
      valAmb.textContent = `${v}%`;
      this.cb.onSettingChange('ambienceVolume', v / 100);
    });

    document.getElementById('opt-shadows').addEventListener('change', (e) => {
      this.cb.onSettingChange('shadows', e.target.checked);
    });
    document.getElementById('opt-bots').addEventListener('change', (e) => {
      this.cb.onSettingChange('botsEnabled', e.target.checked);
    });
    document.getElementById('opt-ambience').addEventListener('change', (e) => {
      this.cb.onSettingChange('ambienceEnabled', e.target.checked);
    });
    document.getElementById('opt-cam').addEventListener('change', (e) => {
      this.cb.onSettingChange('cameraMode', e.target.value);
    });
  }

  _savePseudo() {
    const p = this.getPseudo();
    localStorage.setItem('kyoto_pseudo', p);
  }

  getPseudo() {
    return (this.mpPseudo.value || 'Joueur').trim().slice(0, 18) || 'Joueur';
  }

  getRoomCode() {
    return (this.mpRoom.value || 'PUBLIC').toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 16) || 'PUBLIC';
  }

  async _copyInvite() {
    if (!this.currentInviteUrl) return;
    if (window.kyotoDesktop?.copyText) {
      await window.kyotoDesktop.copyText(this.currentInviteUrl);
    } else if (navigator.clipboard) {
      await navigator.clipboard.writeText(this.currentInviteUrl);
    }
    this.pushFeed('📋 Lien d’invitation copié ! Envoie-le à tes amis.', '#3be384');
    this.setMpStatus('Lien copié ! Tes amis peuvent le coller dans leur .exe ou l’ouvrir dans leur navigateur.', 'success');
  }

  setMpStatus(text, type = '') {
    this.mpStatusLine.textContent = text;
    this.mpStatusLine.className = `mp-status-line ${type}`.trim();
  }

  setHostingInvite(inviteUrl) {
    this.currentInviteUrl = inviteUrl || '';
    if (inviteUrl) {
      this.mpInviteUrl.value = inviteUrl;
      this.mpInviteBox.classList.remove('hidden');
      this.btnHudCopy.classList.remove('hidden');
    } else {
      this.mpInviteBox.classList.add('hidden');
      this.btnHudCopy.classList.add('hidden');
    }
  }

  setOnlineState({ connected, room, playerCount, hasStarted }) {
    this.onlineBanner.classList.toggle('hidden', !connected);
    this.chatPanel.classList.toggle('hidden', !connected);
    this.btnMpDisconnect.classList.toggle('hidden', !connected);
    this.btnMpClose.classList.toggle('hidden', !hasStarted);
    if (connected) {
      this.onlineBannerText.textContent = `EN LIGNE • Salon ${room} • ${playerCount} joueur${playerCount > 1 ? 's' : ''}`;
    }
  }

  openChatInput() {
    if (this.chatPanel.classList.contains('hidden')) return;
    this.isChatTyping = true;
    this.chatInput.classList.remove('hidden');
    this.chatInput.value = '';
    if (document.pointerLockElement) document.exitPointerLock();
    setTimeout(() => this.chatInput.focus(), 20);
  }

  closeChatInput() {
    this.isChatTyping = false;
    this.chatInput.classList.add('hidden');
    this.chatInput.blur();
  }

  addChatMessage(name, text) {
    const el = document.createElement('div');
    el.className = 'chat-msg';
    const b = document.createElement('b');
    b.textContent = `${name}: `;
    el.appendChild(b);
    el.appendChild(document.createTextNode(text));
    this.chatMessages.appendChild(el);
    while (this.chatMessages.children.length > 6) {
      this.chatMessages.firstChild.remove();
    }
  }

  setSettingsOpen(open) {
    this.isSettingsOpen = open;
    if (open) {
      this.isMpOpen = false;
      this.isCustomizerOpen = false;
      this.customizerModal?.classList.remove('open');
    }
    this.settingsModal.classList.toggle('open', open);
    this.mpModal.classList.toggle('open', this.isMpOpen);
    if (open && document.pointerLockElement) document.exitPointerLock();
    this.cb.onCustomizerToggle?.(false);
  }

  setMpOpen(open) {
    this.isMpOpen = open;
    if (open) {
      this.isSettingsOpen = false;
      this.isCustomizerOpen = false;
      this.customizerModal?.classList.remove('open');
    }
    this.mpModal.classList.toggle('open', open);
    this.settingsModal.classList.toggle('open', this.isSettingsOpen);
    if (open && document.pointerLockElement) document.exitPointerLock();
    this.cb.onCustomizerToggle?.(false);
  }

  setPointerLocked(locked) {
    this.lockHint.classList.toggle('hidden', locked || this.isModalOpen || this.isChatTyping);
  }

  setZone(zone, customWorldName = '', customWelcome = '') {
    if (zone === 'dojo') {
      this.zonePill.textContent = 'DOJO';
      this.zonePill.style.background = '#1a3357';
      this.zonePill.style.color = '#ffdd64';
      this.zoneStatus.textContent = 'Grand Dojo — 28 Pouvoirs • Classique • Combo • Battle Royale • Classé • Studio';
    } else if (zone === 'combo') {
      this.zonePill.textContent = 'COMBO';
      this.zonePill.style.background = '#c92a2a';
      this.zonePill.style.color = '#ffe066';
      this.zoneStatus.textContent = 'Mode Combo — Mise au sol 1.6s • Contre [Clic G] à 1.1s • [R] Pouvoir 3 (T: Dojo)';
    } else if (zone === 'ranked') {
      this.zonePill.textContent = 'CLASSÉ';
      this.zonePill.style.background = '#d97706';
      this.zonePill.style.color = '#fffbeb';
      this.zoneStatus.textContent = '🏆 MATCH CLASSÉ — Premier à 3 K.O. gagne +35 Elo ! (T: Quitter)';
    } else if (zone === 'br') {
      this.zonePill.textContent = 'BATTLE ROYALE';
      this.zonePill.style.background = '#0ea5e9';
      this.zonePill.style.color = '#ffffff';
      this.zoneStatus.textContent = '🪂 Battle Royale — [E] Ramasser • [1-3] Armes • [Clic D] Viser • [TAB] Carte';
    } else if (zone === 'custom') {
      this.zonePill.textContent = 'STUDIO';
      this.zonePill.style.background = '#7c3aed';
      this.zonePill.style.color = '#ffe066';
      this.zoneStatus.textContent = `${customWorldName || 'Mon Monde'} — ${customWelcome || 'TAB: Éditeur / Jouer • T: Dojo'}`;
    } else {
      this.zonePill.textContent = 'CLASSIQUE';
      this.zonePill.style.background = '#17669c';
      this.zonePill.style.color = '#e0faff';
      this.zoneStatus.textContent = 'Vallée Émeraude — Ponts traversables • [R] Pouvoir 3 Tactique (T: Dojo)';
    }
  }

  setRankDisplay(elo) {
    const r = getRankForElo(elo);
    const label = `${r.icon} ${r.name} • ${elo} Elo`;
    if (this.hudRankPill) {
      this.hudRankPill.textContent = label;
      this.hudRankPill.style.borderColor = r.color;
      this.hudRankPill.style.color = r.color;
    }
    if (this.rqRankBadge) {
      this.rqRankBadge.textContent = label;
      this.rqRankBadge.style.color = r.color;
    }
  }

  setRankedQueueState(open, data = null) {
    if (!this.rankedQueueOverlay) return;
    this.rankedQueueOverlay.classList.toggle('hidden', !open);
    if (open && data) {
      this.rqCount.textContent = `${data.count || 1} / ${data.minPlayers || 2} joueurs en file d'attente...`;
      const names = (data.players || []).map((p) => `${p.name} (${p.elo ?? 100})`).join(' • ');
      this.rqNames.textContent = names || 'En attente d’un second joueur...';
    }
  }

  setBRHudActive(active) {
    this.brMinimapCard?.classList.toggle('hidden', !active);
    this.brHotbar?.classList.toggle('hidden', !active);
    if (!active) {
      this.setBRFlightPrompt(null);
      this.setBRLootPrompt(null);
      this.setBRFullMapOpen(false);
      this.updateCrosshair(null, 0, false);
    }
  }

  setBRFlightPrompt(htmlOrNull) {
    if (!this.brFlightPrompt) return;
    this.brFlightPrompt.classList.toggle('hidden', !htmlOrNull);
    if (htmlOrNull) this.brFlightPrompt.innerHTML = htmlOrNull;
  }

  setBRLootPrompt(itemOrNull) {
    if (!this.brLootPrompt) return;
    this.brLootPrompt.classList.toggle('hidden', !itemOrNull);
    if (itemOrNull && this.brLootName) {
      this.brLootName.textContent = itemOrNull.name;
      this.brLootName.style.color = itemOrNull.color || '#ffe066';
    }
  }

  setBRFullMapOpen(open) {
    this.brFullMapOverlay?.classList.toggle('hidden', !open);
  }

  updateBRStormStatus(radius, isOutside) {
    if (!this.brStormStatus) return;
    this.brStormStatus.textContent = isOutside ? '⚠️ HORS ZONE !' : `Zone: ${Math.round(radius)}m`;
    this.brStormStatus.style.color = isOutside ? '#ff6b6b' : '#cfe3ff';
  }

  updateBRHotbar(slots, activeSlot, isReloading = false, hasPower = false) {
    if (!this.brHotbar) return;
    this.brSlotEls.forEach((el, i) => {
      if (!el) return;
      const s = slots[i];
      const w = s ? WEAPONS[s.weaponId] : null;
      const nameEl = el.querySelector('.br-slot-name');
      if (nameEl) {
        nameEl.textContent = w ? `${w.icon} ${w.short}` : 'Vide';
        nameEl.style.color = w ? w.rarityColor : '#8ca6cc';
      }
      el.classList.toggle('active', activeSlot === i);
    });

    if (this.brAmmoPill) {
      const cur = activeSlot >= 0 ? slots[activeSlot] : null;
      const w = cur ? WEAPONS[cur.weaponId] : null;
      if (w) {
        this.brAmmoPill.textContent = isReloading ? '🔄 Recharge...' : `${cur.ammo} / ${w.magSize}`;
      } else {
        this.brAmmoPill.textContent = hasPower ? '⚡ Pouvoir' : '✊ Poings';
      }
    }
  }

  updateCrosshair(weapon, spreadPx = 0, isScoped = false) {
    if (!this.crosshair) return;
    this.sniperScope?.classList.toggle('hidden', !isScoped);
    if (isScoped) {
      this.crosshair.className = 'crosshair-scoped';
      return;
    }
    if (!weapon) {
      this.crosshair.className = 'crosshair-default';
      return;
    }
    this.crosshair.className = `crosshair-${weapon.crosshair || 'rifle'}`;
    const gap = Math.max(4, Math.min(34, 8 + spreadPx));
    this.crosshair.style.setProperty('--ch-gap', `${gap.toFixed(1)}px`);
  }

  setCombatHudHidden(hidden) {
    document.querySelector('.hud-bottom-left')?.classList.toggle('hidden', hidden);
    document.querySelector('.hud-bottom-center')?.classList.toggle('hidden', hidden);
    document.querySelector('.hud-bottom-right')?.classList.toggle('hidden', hidden);
    document.querySelector('.hud-top-right')?.classList.toggle('hidden', hidden);
  }

  setCameraModeLabel(isThirdPerson) {
    this.camModePill.textContent = isThirdPerson ? '3P' : '1P';
    const sel = document.getElementById('opt-cam');
    if (sel) sel.value = isThirdPerson ? 'third' : 'first';
  }

  setEquippedPower(power) {
    if (!power) {
      this.equippedPowerName.textContent = 'Mains Nues';
      this.equippedPowerDot.style.background = '#94a3b8';
      this.equippedPowerDot.style.color = '#94a3b8';
      return;
    }
    this.equippedPowerName.textContent = power.name;
    this.equippedPowerDot.style.background = power.color;
    this.equippedPowerDot.style.color = power.color;
    this.iconAb1.textContent = power.ab1.icon;
    this.nameAb1.textContent = power.ab1.short;
    this.iconAb2.textContent = power.ab2.icon;
    this.nameAb2.textContent = power.ab2.short;
    if (this.iconAb3 && this.nameAb3) {
      if (HOOK_POWERS.has(power.id)) {
        this.iconAb3.textContent = '⛓️';
        this.nameAb3.textContent = 'Grappin';
      } else if (SHIELD_POWERS.has(power.id)) {
        this.iconAb3.textContent = '🛡️';
        this.nameAb3.textContent = 'Bouclier';
      } else if (LEAP_POWERS.has(power.id)) {
        this.iconAb3.textContent = '🦅';
        this.nameAb3.textContent = 'Impact';
      } else {
        this.iconAb3.textContent = '🔮';
        this.nameAb3.textContent = 'Tourelle';
      }
    }
  }

  showPedestalPrompt(power, isAlreadyEquipped) {
    if (!power) {
      this.pedPrompt.classList.add('hidden');
      return;
    }
    this.pedPrompt.classList.remove('hidden');
    this.pedPrompt.style.borderColor = power.color;
    this.pedBadge.textContent = power.title.toUpperCase();
    this.pedBadge.style.background = power.color;
    this.pedName.textContent = power.name;
    this.pedDesc.textContent = power.desc;
    this.pedLmb.textContent = power.lmb.name;
    this.pedAb1.textContent = `${power.ab1.name} — ${power.ab1.desc}`;
    this.pedAb2.textContent = `${power.ab2.name} — ${power.ab2.desc}`;
    this.pedCta.textContent = isAlreadyEquipped
      ? '✓ Pouvoir déjà équipé — Traverse le Portail !'
      : 'Appuyez sur [E] ou [Clic Gauche] pour équiper';
  }

  flashHitmarker() {
    this.hitmarker.classList.add('active');
    clearTimeout(this._hitTimer);
    this._hitTimer = setTimeout(() => this.hitmarker.classList.remove('active'), 120);
  }

  flashDamage() {
    this.damageVignette.style.opacity = '1';
    if (this.hpCard) {
      this.hpCard.classList.remove('hurt-shake');
      void this.hpCard.offsetWidth;
      this.hpCard.classList.add('hurt-shake');
    }
    clearTimeout(this._dmgTimer);
    this._dmgTimer = setTimeout(() => {
      this.damageVignette.style.opacity = '0';
      if (this.hpCard) this.hpCard.classList.remove('hurt-shake');
    }, 240);
  }

  updateRespawnOverlay(isDead, remaining = 0, total = 3.0, killerText = '') {
    if (!this.respawnOverlay) return;
    this.respawnOverlay.classList.toggle('hidden', !isDead);
    if (isDead) {
      if (killerText) this.respawnKiller.textContent = killerText;
      this.respawnCountdown.textContent = Math.max(0.1, remaining).toFixed(1);
      const pct = Math.max(0, Math.min(100, (remaining / total) * 100));
      this.respawnBarFill.style.width = `${pct}%`;
    }
  }

  triggerWarpFlash() {
    this.warpOverlay.style.opacity = '1';
    setTimeout(() => {
      this.warpOverlay.style.opacity = '0';
    }, 340);
  }

  pushFeed(text, color = '#ffd43b') {
    const item = document.createElement('div');
    item.className = 'feed-item';
    item.style.borderLeftColor = color;
    item.textContent = text;
    this.killFeed.prepend(item);
    while (this.killFeed.children.length > 4) {
      this.killFeed.lastChild.remove();
    }
    setTimeout(() => item.remove(), 4200);
  }

  updatePlayerHud(player) {
    const hp = Math.ceil(player.hp);
    const ratio = Math.max(0, Math.min(1, player.hp / player.maxHp));
    this.hpText.textContent = `${hp} / ${player.maxHp}`;
    this.hpFill.style.width = `${ratio * 100}%`;
    this.hpFill.classList.toggle('mid', ratio <= 0.55 && ratio > 0.25);
    this.hpFill.classList.toggle('low', ratio <= 0.25);

    this.hitsCounter.textContent = String(player.hits);
    this.koCounter.textContent = String(player.kos);

    // Shield bar (visible whenever shield > 0)
    if (this.shieldRow && this.shieldFill && this.shieldText) {
      const sh = Math.ceil(player.shield || 0);
      this.shieldRow.classList.toggle('hidden', sh <= 0);
      if (sh > 0) {
        const sRatio = Math.max(0, Math.min(1, sh / (player.maxShield || 50)));
        this.shieldFill.style.width = `${sRatio * 100}%`;
        this.shieldText.textContent = `🛡️ ${sh}`;
      }
    }

    // Hide power ability slots when empty-handed in Battle Royale
    const showPowers = Boolean(player.hasPower);
    this.slotAb1?.classList.toggle('hidden', !showPowers);
    this.slotAb2?.classList.toggle('hidden', !showPowers);
    this.slotAb3?.classList.toggle('hidden', !showPowers);

    this._updateCd(this.cdMask1, this.cdText1, player.ab1Cd, player.power.ab1.cooldown);
    this._updateCd(this.cdMask2, this.cdText2, player.ab2Cd, player.power.ab2.cooldown);
    if (this.cdMask3 && this.cdText3) {
      this._updateCd(this.cdMask3, this.cdText3, player.ab3Cd || 0, 8.0);
    }
    this._updateCd(this.cdMaskDash, this.cdTextDash, player.dashCd, 2.2);

    this.freezeOverlay.style.opacity = player.freezeTimer > 0 ? '1' : '0';
    this.titanOverlay.style.opacity = player.titanTimer > 0 ? '1' : '0';

    const badges = [];
    if (player.titanTimer > 0) badges.push(`🗿 TITAN ${player.titanTimer.toFixed(1)}s`);
    if (player.burnTimer > 0) badges.push('🔥 BRÛLURE');
    if (player.poisonTimer > 0) badges.push('☠️ POISON');
    if (player.freezeTimer > 0) badges.push('🧊 GELÉ');
    if (player.chronoSlowTimer > 0) badges.push('⏳ RALENTI');
    if (player.knockdownTimer > 0) badges.push('💫 À TERRE');
    this.statusBadges.innerHTML = badges.map((b) => `<span class="status-pill">${b}</span>`).join('');

    // Mode Combo Knockdown & 1.1s Counter-Punch Prompt
    if (this.knockdownHud) {
      const isDown = !player.isDead && player.knockdownTimer > 0;
      this.knockdownHud.classList.toggle('hidden', !isDown);
      if (isDown) {
        const ready = player.canCounterPunch();
        this.knockdownHud.classList.toggle('counter-ready', ready);
        if (ready) {
          this.kdTitle.textContent = '⚡ CONTRE DISPONIBLE !';
          this.kdSub.textContent = `Appuie sur [Clic Gauche] pour couper le combo ! (${player.knockdownTimer.toFixed(1)}s)`;
          this.kdBarFill.style.width = '100%';
        } else {
          const wait = Math.max(0, 1.1 - player.knockdownElapsed);
          this.kdTitle.textContent = `💫 À TERRE (${player.knockdownTimer.toFixed(1)}s)`;
          this.kdSub.textContent = `Coup de poing contre prêt dans ${wait.toFixed(1)}s...`;
          this.kdBarFill.style.width = `${Math.min(100, (player.knockdownElapsed / 1.1) * 100)}%`;
        }
      }
    }

    // Live Combo Streak Badge
    if (this.comboBadge) {
      const showCombo = player.comboCount >= 2;
      this.comboBadge.classList.toggle('hidden', !showCombo);
      if (showCombo) {
        this.comboBadge.textContent = `🔥 COMBO x${player.comboCount}`;
      }
    }
  }

  _updateCd(maskEl, textEl, remaining, total) {
    if (remaining <= 0.05) {
      maskEl.style.height = '0%';
      textEl.textContent = '';
    } else {
      const pct = Math.min(100, (remaining / total) * 100);
      maskEl.style.height = `${pct}%`;
      textEl.textContent = remaining.toFixed(1);
    }
  }

  updateLeaderboard(fighters) {
    const sorted = [...fighters].sort((a, b) => b.hits - a.hits || b.kos - a.kos).slice(0, 7);
    this.leaderboardList.innerHTML = sorted
      .map(
        (f) => `
      <div class="lb-row ${f.isPlayer ? 'is-player' : ''}">
        <div class="lb-left">
          <span class="lb-dot" style="background:${f.power.color}"></span>
          <span class="lb-name">${f.isRemotePlayer ? '★ ' : ''}${f.name}</span>
        </div>
        <span class="lb-score">${f.hits} hits</span>
      </div>`
      )
      .join('');
  }
}
