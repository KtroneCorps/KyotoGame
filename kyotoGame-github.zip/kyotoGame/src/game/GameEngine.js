import * as THREE from 'three';
import { SoundEngine } from '../audio/SoundEngine.js';
import { DojoWorld } from '../world/DojoWorld.js';
import { ArenaWorld, getArenaTerrainHeight, getArenaWalkableHeight } from '../world/ArenaWorld.js';
import { BattleRoyaleWorld } from '../world/BattleRoyaleWorld.js';
import { CustomWorld, createTemplateWorld, STUDIO_ITEMS } from '../world/CustomWorld.js';
import { Fighter } from '../entities/Fighter.js';
import { BotManager } from '../entities/BotAI.js';
import { createFirstPersonRig, CHARACTER_OPTIONS } from '../models/LowPolyModels.js';
import { VfxManager } from '../vfx/VfxManager.js';
import { PowerExecutor } from '../powers/PowerExecutor.js';
import { HudManager } from '../ui/HudManager.js';
import { StudioUi } from '../ui/StudioUi.js';
import { MultiplayerClient } from '../net/MultiplayerClient.js';
import { POWER_MAP } from '../powers/PowersData.js';
import { WEAPONS, getRankForElo } from '../weapons/WeaponsData.js';

const PLAYER_PALETTES = [
  { shirtHex: 0x2b7de9, pantsHex: 0x2a3b4f, hairHex: 0x5c361a, hatStyle: 0 },
  { shirtHex: 0xe63946, pantsHex: 0x242d3d, hairHex: 0x2b1d12, hatStyle: 1 },
  { shirtHex: 0x2a9d8f, pantsHex: 0x223836, hairHex: 0xd9a05b, hatStyle: 2 },
  { shirtHex: 0x8338ec, pantsHex: 0x201936, hairHex: 0xf4f4f9, hatStyle: 3 },
  { shirtHex: 0xf77f00, pantsHex: 0x2d2a32, hairHex: 0x3b2214, hatStyle: 0 },
];

export class GameEngine {
  constructor(container) {
    this.container = container;
    this.zone = 'dojo';
    this.time = 0;
    this.keys = new Set();
    this.isPointerLocked = false;
    this.warpCooldown = 0;
    this.hasStarted = false;
    this.botsEnabled = false; // Bots disabled by default (optional toggle in Paramètres!)

    // Settings
    this.sensitivity = 1.0;
    this.baseFov = 78;
    this.isThirdPerson = false;
    this.thirdPersonDistance = 6.2;

    // Ranked & Battle Royale State
    this.playerElo = Number(localStorage.getItem('kyoto_elo') || 100);
    this.inRankedQueue = false;
    this.savedDojoPowerId = 'thunder';
    this.brPhase = 'ground'; // 'plane' | 'freefall' | 'gliding' | 'ground'
    this.brSlots = [null, null, null]; // { weaponId, ammo }
    this.brActiveSlot = -1;
    this.brFullMapOpen = false;
    this.brNearestLoot = null;
    this.isMouseDown = false;
    this.isAds = false;
    this.gunCooldown = 0;
    this.reloadTimer = 0;
    this.gunRecoil = 0;
    this.stormTick = 0;
    this._minimapTimer = 0;

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    container.appendChild(this.renderer.domElement);

    // Scene & Camera
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(this.baseFov, window.innerWidth / window.innerHeight, 0.1, 320);
    this.scene.add(this.camera);

    // Audio & VFX
    this.sound = new SoundEngine();
    this.vfx = new VfxManager(this.scene);
    this.powerExecutor = new PowerExecutor(this.scene, this.vfx, this.sound, (x, z) => {
      if (this.zone === 'dojo') return 0;
      if (this.zone === 'custom') return this.customWorld.getSurfaceHeightAt(x, z, 200);
      if (this.zone === 'br') return this.brWorld.getWalkableHeight(x, z, 200);
      return getArenaWalkableHeight(x, z, 200);
    });

    // Worlds
    this.dojo = new DojoWorld();
    this.arena = new ArenaWorld();
    this.customWorld = new CustomWorld();
    this.brWorld = new BattleRoyaleWorld();
    this.brWorld.group.visible = false;
    this.scene.add(this.dojo.group);
    this.scene.add(this.arena.group);
    this.scene.add(this.customWorld.group);
    this.scene.add(this.brWorld.group);

    // Studio Editor State
    this.studioEditorMode = true;
    this.raycaster = new THREE.Raycaster();
    this.lastGhostPos = new THREE.Vector3();
    this.lavaTick = 0;

    // Load most recently saved custom world if any
    const savedWorlds = CustomWorld.listSavedWorlds();
    if (savedWorlds.length > 0) {
      this.customWorld.loadData(savedWorlds[0]);
    }

    // Load saved character appearance from localStorage
    let savedApp = null;
    try {
      savedApp = JSON.parse(localStorage.getItem('kyoto_appearance') || 'null');
    } catch { /* ignore */ }

    this.playerAppearance = {
      skinHex: 0xf2c96b,
      shirtHex: 0x2b7de9,
      pantsHex: 0x243447,
      hairHex: 0x5c361a,
      hatStyle: 0,
      faceStyle: 0,
      backStyle: 1,
      ...(savedApp || {}),
    };

    this.player = new Fighter({
      id: 'player',
      name: 'Toi',
      isPlayer: true,
      powerId: 'thunder',
      appearance: this.playerAppearance,
    });
    this.scene.add(this.player.mesh);

    this.fpRig = createFirstPersonRig(this.playerAppearance);
    this.fpRig.setPowerModel(this.player.powerId);
    this.camera.add(this.fpRig.root);

    // Bots inside Arena (hidden by default unless enabled in Paramètres)
    this.botManager = new BotManager(this.arena.group);
    for (const b of this.botManager.bots) b.mesh.visible = this.botsEnabled;

    // Remote Multiplayer Fighters
    this.remotePlayers = new Map(); // id -> Fighter
    this.mp = new MultiplayerClient({
      onWelcome: (msg) => this._onMpWelcome(msg),
      onPlayerJoin: (p) => this._addRemotePlayer(p),
      onPlayerLeave: (id, name) => this._removeRemotePlayer(id, name),
      onSnapshot: (players) => this._onMpSnapshot(players),
      onRemoteAction: (msg) => this._onMpRemoteAction(msg),
      onDamaged: (msg) => this._onMpDamaged(msg),
      onKOEvent: (msg) => this._onMpKOEvent(msg),
      onChat: (msg) => this.hud.addChatMessage(msg.name, msg.text),
      onWorldSync: (world, senderName) => {
        if (!world) return;
        this.customWorld.loadData(world);
        if (this.zone === 'custom') {
          this._applyCustomWorldSky();
          this.hud.setZone('custom', this.customWorld.data.name, this.customWorld.data.welcomeText);
        }
        if (senderName) this.hud.pushFeed(`🌍 ${senderName} a mis à jour le monde « ${world.name} » !`, '#b15cff');
      },
      onRankedQueue: (msg) => this._onRankedQueue(msg),
      onRankedStart: (msg) => this._onRankedStart(msg),
      onRankedScore: (msg) => this._onRankedScore(msg),
      onRankedEnd: (msg) => this._onRankedEnd(msg),
      onBRSync: (msg) => this._onBRSync(msg),
      onBRLootTaken: (lootId) => this._onBRLootTaken(lootId),
      onRemoteGunshot: (msg) => this._onRemoteGunshot(msg),
      onDisconnect: () => this._onMpDisconnected(),
    });

    // HUD & Settings
    this.hud = new HudManager({
      onToggleCamera: () => this.toggleCameraMode(),
      onGoToDojo: () => {
        if (this.zone !== 'dojo') this.switchZone('dojo');
      },
      onResume: () => this.requestPointerLock(),
      onResetStats: () => {
        this.player.hits = 0;
        this.player.kos = 0;
        for (const b of this.botManager.bots) {
          b.hits = 0;
          b.kos = 0;
        }
      },
      onSettingChange: (key, val) => this._applySetting(key, val),
      onPlaySolo: (pseudo) => {
        this.player.name = pseudo;
        this.hasStarted = true;
        this._syncOnlineHud();
      },
      onHostOnline: (pseudo, room) => this._hostOnline(pseudo, room),
      onJoinServer: (url, pseudo, room) => this._joinOnline(url, pseudo, room),
      onDisconnect: () => this._disconnectOnline(),
      onSendChat: (text) => this.mp.sendChat(text),
      onAppearanceChange: (field, val) => this._updatePlayerAppearance({ [field]: val }),
      onRandomizeAppearance: () => this._randomizePlayerAppearance(),
      onCustomizerToggle: () => this._updateCameraVisibility(),
      onOpenStudio: () => this.switchZone('custom'),
      onOpenBR: () => this.enterBattleRoyale(),
      onOpenRanked: () => this.enterRankedQueue(),
      onLeaveRankedQueue: () => this.leaveRankedQueue(),
    });

    this.studioUi = new StudioUi({
      onTogglePlayMode: () => this.toggleStudioPlayMode(),
      onSelectBuildType: () => {
        this.customWorld.selectObject(null);
      },
      onToolModeChange: (mode) => {
        if (mode === 'select') this.customWorld.hideGhost();
      },
      onInspectorChange: (patch) => {
        if (this.customWorld.selectedId) {
          this.customWorld.updateObject(this.customWorld.selectedId, patch);
          this._syncCustomWorld();
        }
      },
      onNudgeSelected: (axis, delta) => {
        const spec = this.customWorld.getSelectedSpec();
        if (!spec) return;
        const pos = [...spec.pos];
        const idx = axis === 'x' ? 0 : axis === 'y' ? 1 : 2;
        pos[idx] = Number((pos[idx] + delta).toFixed(2));
        this.customWorld.updateObject(spec.id, { pos });
        this._syncCustomWorld();
      },
      onDuplicateSelected: () => {
        const spec = this.customWorld.getSelectedSpec();
        if (!spec) return;
        const copy = { ...spec, id: undefined, pos: [spec.pos[0] + 2, spec.pos[1], spec.pos[2] + 2] };
        const added = this.customWorld.addObject(copy);
        this.studioUi.syncInspector(added);
        this.sound.playEquip();
        this._syncCustomWorld();
      },
      onDeleteSelected: () => {
        if (this.customWorld.selectedId) {
          this.customWorld.removeObject(this.customWorld.selectedId);
          this.studioUi.syncInspector(null);
          this.sound.playHit(false);
          this._syncCustomWorld();
        }
      },
      onSaveWorld: () => {
        CustomWorld.saveWorldToStorage(this.customWorld.data);
        this._syncCustomWorld();
        this.sound.playEquip();
        this.hud.pushFeed(`💾 Monde « ${this.customWorld.data.name} » sauvegardé !`, '#3be384');
      },
      onApplyWorldSettings: (patch) => {
        this.customWorld.updateWorldSettings(patch);
        this._applyCustomWorldSky();
        this.hud.setZone('custom', this.customWorld.data.name, this.customWorld.data.welcomeText);
        CustomWorld.saveWorldToStorage(this.customWorld.data);
        this._syncCustomWorld();
        this.hud.pushFeed(`🌍 Paramètres du monde « ${this.customWorld.data.name} » appliqués !`, '#b15cff');
      },
      onLoadTemplate: (tplId) => {
        this.customWorld.loadData(createTemplateWorld(tplId));
        this._applyCustomWorldSky();
        this.studioUi.syncInspector(null);
        this.hud.setZone('custom', this.customWorld.data.name, this.customWorld.data.welcomeText);
        this._syncCustomWorld();
        this.hud.pushFeed(`✨ Modèle « ${this.customWorld.data.name} » chargé !`, '#ffd43b');
      },
      onLoadSavedWorld: (worldData) => {
        this.customWorld.loadData(worldData);
        this._applyCustomWorldSky();
        this.studioUi.syncInspector(null);
        this.hud.setZone('custom', this.customWorld.data.name, this.customWorld.data.welcomeText);
        this._syncCustomWorld();
        this.hud.pushFeed(`📂 Monde « ${this.customWorld.data.name} » chargé !`, '#74e8ff');
      },
      onExportWorldJson: () => {
        this.hud.pushFeed('📋 Code JSON du monde copié !', '#ffd43b');
        return JSON.stringify(this.customWorld.data);
      },
      onImportWorldJson: (raw) => {
        try {
          const parsed = JSON.parse(raw);
          if (!parsed || !Array.isArray(parsed.objects)) throw new Error('Format invalide');
          this.customWorld.loadData(parsed);
          this._applyCustomWorldSky();
          this.studioUi.syncInspector(null);
          this.hud.setZone('custom', this.customWorld.data.name, this.customWorld.data.welcomeText);
          CustomWorld.saveWorldToStorage(this.customWorld.data);
          this._syncCustomWorld();
          this.hud.pushFeed(`📥 Monde « ${this.customWorld.data.name} » importé !`, '#3be384');
        } catch {
          this.hud.pushFeed('❌ JSON de monde invalide.', '#ff6b6b');
        }
      },
      getWorldData: () => this.customWorld.data,
      onWorldModalToggle: () => {},
    });

    this.nearestPedestal = null;
    this.nearMirror = false;
    this.camKnockRoll = 0;
    this.camKnockPitch = 0;
    this.playerRespawnTotal = 3.0;
    this.lastKillerText = '';
    this._lbTimer = 0;
    this._prevTime = performance.now();

    this._bindEvents();
    this.switchZone('dojo', true);
    this._updateCameraVisibility();
    this.hud.setEquippedPower(this.player.power);
    this.hud.setRankDisplay(this.playerElo);
    this.hud.setCameraModeLabel(this.isThirdPerson);
    this.hud.syncCustomizerUI(this.playerAppearance);

    this._loop = this._loop.bind(this);
    requestAnimationFrame(this._loop);
  }

  // --- MULTIPLAYER FLOWS ---
  async _hostOnline(pseudo, room) {
    this.player.name = pseudo;

    if (!window.kyotoDesktop?.hostOnline) {
      this.hud.setMpStatus(
        "Pour héberger un tunnel public sans IP en 1 clic, ouvre l'application kyotoGame.exe !",
        'error'
      );
      return;
    }

    this.hud.setMpStatus('Création de ton serveur public sécurisé (sans IP)... Patiente quelques secondes...', '');
    try {
      const info = await window.kyotoDesktop.hostOnline(room);
      this.hud.setHostingInvite(info.inviteUrl);
      await this.mp.connect({
        serverUrl: info.localUrl,
        name: pseudo,
        room: info.room,
        powerId: this.player.powerId,
        appearance: this.playerAppearance,
      });
      this.hasStarted = true;
      this._syncOnlineHud();
      await window.kyotoDesktop.copyText(info.inviteUrl);
      this.hud.setMpStatus(
        `Serveur en ligne ! Lien d'invitation copié dans le presse-papiers. Clique sur "Retourner en jeu" !`,
        'success'
      );
      this.hud.pushFeed(`🌐 Serveur public actif ! Lien copié automatiquement.`, '#3be384');
    } catch (err) {
      this.hud.setMpStatus(`Erreur d'hébergement : ${err.message}`, 'error');
    }
  }

  async _joinOnline(rawUrl, pseudo, room) {
    this.player.name = pseudo;
    if (!rawUrl) {
      this.hud.setMpStatus('Colle d’abord le lien du serveur de ton ami !', 'error');
      return;
    }

    this.hud.setMpStatus(`Connexion au serveur (${room})...`, '');
    try {
      await this.mp.connect({
        serverUrl: rawUrl,
        name: pseudo,
        room,
        powerId: this.player.powerId,
        appearance: this.playerAppearance,
      });
      this.hasStarted = true;
      this.hud.setHostingInvite('');
      this._syncOnlineHud();
      this.hud.setMpOpen(false);
      this.hud.pushFeed(`🌐 Connecté au salon ${this.mp.room} !`, '#3be384');
      this.requestPointerLock();
    } catch (err) {
      this.hud.setMpStatus(`Connexion impossible : ${err.message}`, 'error');
    }
  }

  async _disconnectOnline() {
    this.mp.disconnect();
    if (window.kyotoDesktop?.stopHost) {
      await window.kyotoDesktop.stopHost();
    }
    this._clearRemotePlayers();
    this.hud.setHostingInvite('');
    this._syncOnlineHud();
    this.hud.setMpStatus('Déconnecté du serveur multijoueur.', '');
    this.hud.pushFeed('Déconnecté du serveur multijoueur.', '#ff99a8');
  }

  _onMpWelcome(msg) {
    this._clearRemotePlayers();
    for (const p of msg.players || []) {
      this._addRemotePlayer(p, true);
    }
    if (msg.customWorld) {
      this.customWorld.loadData(msg.customWorld);
    }
    this._syncOnlineHud();
  }

  _addRemotePlayer(p, silent = false) {
    if (!p || p.id === this.mp.playerId || this.remotePlayers.has(p.id)) return;
    const remote = new Fighter({
      id: p.id,
      name: p.name || 'Joueur',
      isPlayer: false,
      isRemotePlayer: true,
      powerId: p.powerId || 'thunder',
      appearance: p.appearance && p.appearance.shirtHex
        ? p.appearance
        : { skinHex: 0xf2c96b, ...PLAYER_PALETTES[this.remotePlayers.size % PLAYER_PALETTES.length], faceStyle: 0 },
    });
    remote.position.set(p.x || 0, p.y || 0, p.z || 13.5);
    remote.applyRemoteState(p);
    remote.mesh.visible = remote.remoteZone === this.zone;
    this.scene.add(remote.mesh);
    this.remotePlayers.set(p.id, remote);

    if (!silent) {
      this.hud.pushFeed(`★ ${remote.name} a rejoint le salon !`, '#74e8ff');
    }
    this._syncOnlineHud();
  }

  _removeRemotePlayer(id, name) {
    const remote = this.remotePlayers.get(id);
    if (remote) {
      this.scene.remove(remote.mesh);
      this.remotePlayers.delete(id);
    }
    if (name) this.hud.pushFeed(`${name} a quitté le salon.`, '#9ec5f8');
    this._syncOnlineHud();
  }

  _clearRemotePlayers() {
    for (const remote of this.remotePlayers.values()) {
      this.scene.remove(remote.mesh);
    }
    this.remotePlayers.clear();
  }

  _onMpSnapshot(players) {
    for (const s of players) {
      if (s.id === this.mp.playerId) continue;
      if (!this.remotePlayers.has(s.id)) {
        this._addRemotePlayer(s, true);
      }
      const remote = this.remotePlayers.get(s.id);
      if (remote) {
        remote.applyRemoteState(s);
        if (s.appearance && JSON.stringify(s.appearance) !== remote._lastAppJson) {
          remote._lastAppJson = JSON.stringify(s.appearance);
          remote.applyAppearance(s.appearance);
        }
      }
    }
  }

  _onMpRemoteAction(msg) {
    const remote = this.remotePlayers.get(msg.id);
    if (!remote || remote.remoteZone !== this.zone) return;
    if (msg.powerId && msg.powerId !== remote.powerId) remote.setPower(msg.powerId);
    if (Array.isArray(msg.pos)) remote.position.set(msg.pos[0], msg.pos[1], msg.pos[2]);
    if (typeof msg.yaw === 'number') remote.yaw = msg.yaw;
    if (typeof msg.pitch === 'number') remote.pitch = msg.pitch;

    const visualCtx = { ...this._getCombatContext(), visualOnly: true };
    const fighters = this._getActiveFighters();

    // Reset remote cooldowns so visual replay always executes cleanly
    remote.lmbCd = 0;
    remote.ab1Cd = 0;
    remote.ab2Cd = 0;
    remote.ab3Cd = 0;

    if (msg.action === 'lmb') this.powerExecutor.castPrimary(remote, fighters, visualCtx);
    else if (msg.action === 'ab1') this.powerExecutor.castAbility1(remote, fighters, visualCtx);
    else if (msg.action === 'ab2') this.powerExecutor.castAbility2(remote, fighters, visualCtx);
    else if (msg.action === 'ab3') this.powerExecutor.castAbility3(remote, fighters, visualCtx);
    else if (msg.action === 'counter') {
      this.powerExecutor.castCounterPunch(remote, fighters, visualCtx);
      this.hud.pushFeed(`⚡ ${remote.name} a coupé le combo !`, '#ffd43b');
    } else if (msg.action === 'dash') {
      this.vfx.spawnBurst(remote.position.clone().add(new THREE.Vector3(0, 0.8, 0)), remote.power.hex, 10, 6, 0.2);
    }
  }

  _onMpDamaged(msg) {
    if (this.zone === 'dojo') return;
    const kb = new THREE.Vector3(msg.kb?.[0] || 0, msg.kb?.[1] || 6, msg.kb?.[2] || 0);
    const attacker = this.remotePlayers.get(msg.attackerId) || {
      id: msg.attackerId,
      name: msg.attackerName || 'Joueur',
      power: POWER_MAP[msg.attackerPower] || POWER_MAP.thunder,
      kos: 0,
      hits: 0,
      comboCount: 0,
      comboResetTimer: 0,
    };

    const st = msg.status || {};
    if (st.burn) this.player.burnTimer = Math.max(this.player.burnTimer, st.burn);
    if (st.poison) this.player.poisonTimer = Math.max(this.player.poisonTimer, st.poison);
    if (st.slow) this.player.slowTimer = Math.max(this.player.slowTimer, st.slow);
    if (st.freeze) this.player.freezeTimer = Math.max(this.player.freezeTimer, st.freeze);

    this.sound.playHit(msg.dmg >= 20);
    const ctx = this._getCombatContext();
    this.player.takeDamage(msg.dmg, kb, attacker, {
      ...ctx,
      comboMode: Boolean(st.knockdown || this.zone === 'combo'),
    });
  }

  _onMpKOEvent(msg) {
    if (msg.victimId === this.mp.playerId) return; // Already handled locally
    if (msg.killerId === this.mp.playerId) {
      this.player.kos += 1;
      this.sound.playKO();
    }
    const pColor = POWER_MAP[msg.killerPower]?.color || '#ffd43b';
    if (msg.killerName) {
      this.hud.pushFeed(`💥 ${msg.killerName} a mis K.O. ${msg.victimName} !`, pColor);
    } else {
      this.hud.pushFeed(`💨 ${msg.victimName} est tombé dans le vide !`, '#9ec5f8');
    }
  }

  _onMpDisconnected() {
    this._clearRemotePlayers();
    this._syncOnlineHud();
    this.hud.pushFeed('⚠️ Connexion au serveur perdue.', '#ff6b6b');
  }

  _syncOnlineHud() {
    this.hud.setOnlineState({
      connected: this.mp.connected,
      room: this.mp.room,
      playerCount: 1 + this.remotePlayers.size,
      hasStarted: this.hasStarted,
    });
  }

  // --- SETTINGS & CAMERA ---
  _applySetting(key, val) {
    if (key === 'sensitivity') this.sensitivity = val;
    if (key === 'fov') {
      this.baseFov = val;
      this.camera.fov = val;
      this.camera.updateProjectionMatrix();
    }
    if (key === 'sfxVolume') this.sound.setSfxVolume(val);
    if (key === 'ambienceVolume') this.sound.setAmbienceVolume(val);
    if (key === 'ambienceEnabled') this.sound.setAmbienceEnabled(val);
    if (key === 'shadows') {
      this.renderer.shadowMap.enabled = val;
      this.arena.setShadowsEnabled(val);
      this.customWorld.setShadowsEnabled(val);
      this.brWorld.setShadowsEnabled(val);
    }
    if (key === 'botsEnabled') {
      this.botsEnabled = val;
      for (const b of this.botManager.bots) b.mesh.visible = val;
    }
    if (key === 'cameraMode') {
      this.isThirdPerson = val === 'third';
      this._updateCameraVisibility();
      this.hud.setCameraModeLabel(this.isThirdPerson);
    }
  }

  requestPointerLock() {
    this.sound.init();
    if (!this.hud.isModalOpen && !this.hud.isChatTyping && this.renderer.domElement.requestPointerLock) {
      this.renderer.domElement.requestPointerLock();
    }
  }

  toggleCameraMode() {
    this.isThirdPerson = !this.isThirdPerson;
    this._updateCameraVisibility();
    this.hud.setCameraModeLabel(this.isThirdPerson);
    this.hud.pushFeed(this.isThirdPerson ? 'Vue 3ème Personne activée' : 'Vue 1ère Personne activée', '#74e8ff');
  }

  _updatePlayerAppearance(patch) {
    this.playerAppearance = { ...this.playerAppearance, ...patch };
    localStorage.setItem('kyoto_appearance', JSON.stringify(this.playerAppearance));
    this.player.applyAppearance(this.playerAppearance);
    this.fpRig.applyAppearance(this.playerAppearance);
    this.hud.syncCustomizerUI(this.playerAppearance);
    this.mp.sendAppearance(this.playerAppearance);
  }

  _randomizePlayerAppearance() {
    const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
    this._updatePlayerAppearance({
      skinHex: pick(CHARACTER_OPTIONS.skins).hex,
      shirtHex: pick(CHARACTER_OPTIONS.shirts).hex,
      pantsHex: pick(CHARACTER_OPTIONS.pants).hex,
      hairHex: pick(CHARACTER_OPTIONS.hairs).hex,
      hatStyle: Math.floor(Math.random() * CHARACTER_OPTIONS.hats.length),
      faceStyle: Math.floor(Math.random() * CHARACTER_OPTIONS.faces.length),
      backStyle: Math.floor(Math.random() * CHARACTER_OPTIONS.backs.length),
    });
    this.sound.playEquip();
  }

  _applyCustomWorldSky() {
    const sky = this.customWorld.getSkyConfig();
    this.scene.background = new THREE.Color(sky.bg);
    this.scene.fog = new THREE.FogExp2(sky.fog, 0.0042);
  }

  _syncCustomWorld() {
    if (this.mp.connected) {
      this.mp.sendWorldSync(this.customWorld.data);
    }
  }

  toggleStudioPlayMode() {
    if (this.zone !== 'custom') return;
    this.studioEditorMode = !this.studioEditorMode;
    this.customWorld.setEditorVisuals(this.studioEditorMode);
    this.studioUi.setStudioActive(true, this.studioEditorMode);
    this.hud.setCombatHudHidden(this.studioEditorMode);
    this._updateCameraVisibility();
    if (!this.studioEditorMode) {
      this.player.respawn(this.customWorld.getSpawnPoint());
      this.hud.pushFeed(`🎮 Mode Jouer activé dans « ${this.customWorld.data.name} » !`, '#3be384');
      this.requestPointerLock();
    } else {
      this.player.velocity.set(0, 0, 0);
      this.player.position.y = Math.max(this.player.position.y, 4.5);
      this.hud.pushFeed('🛠️ Mode Éditeur activé — Vol libre & Construction !', '#b15cff');
    }
  }

  _updateCameraVisibility() {
    const isEditor = this.zone === 'custom' && this.studioEditorMode;
    const inPlane = this.zone === 'br' && this.brPhase === 'plane';
    const w = this._getActiveWeapon();
    const isScoped = Boolean(w && w.scope && this.isAds && !this.isThirdPerson && !this.player.isDead);
    const showBody = !isEditor && !inPlane && !isScoped && (this.isThirdPerson || this.hud?.isCustomizerOpen || this.player.isDead);
    this.player.mesh.visible = showBody;
    this.fpRig.root.visible = !isEditor && !inPlane && !isScoped && !showBody;

    const hasGun = Boolean(this.player.equippedGunId);
    if (this.fpRig.gunMount) this.fpRig.gunMount.visible = hasGun && !isScoped;
    if (this.fpRig.leftArm) this.fpRig.leftArm.visible = !hasGun;
    if (this.fpRig.rightArm) this.fpRig.rightArm.visible = !hasGun;
    if (this.fpRig.fpGlider) this.fpRig.fpGlider.visible = !showBody && !isEditor && !inPlane && this.player.isGliding;
  }

  // --- RANKED MODE (Min. 2 players in queue) ---
  enterRankedQueue() {
    if (!this.mp.connected) {
      this.hud.pushFeed('🏆 Le Mode Classé nécessite le Multijoueur (min. 2 joueurs en file) !', '#ffd43b');
      this.hud.setMpOpen(true);
      this.hud.setMpStatus('Connecte-toi ou héberge un serveur avec un ami pour lancer une partie Classée (min. 2 joueurs).', '');
      return;
    }
    this.inRankedQueue = true;
    this.mp.joinRankedQueue();
    this.hud.setRankDisplay(this.playerElo);
    this.hud.setRankedQueueState(true, { count: 1, minPlayers: 2, players: [{ name: this.player.name, elo: this.playerElo }] });
    this.hud.pushFeed('🏆 Recherche d’un match Classé (min. 2 joueurs en file)...', '#ffd43b');
  }

  leaveRankedQueue() {
    if (this.inRankedQueue) {
      this.inRankedQueue = false;
      this.mp.leaveRankedQueue();
    }
    this.hud.setRankedQueueState(false);
  }

  _onRankedQueue(msg) {
    if (!this.inRankedQueue) return;
    this.hud.setRankedQueueState(true, msg);
  }

  _onRankedStart(msg) {
    if (Array.isArray(msg.participants) && !msg.participants.includes(this.mp.playerId)) return;
    this.inRankedQueue = false;
    this.hud.setRankedQueueState(false);
    this.switchZone('ranked');
    const names = (msg.players || []).map((p) => p.name).join(' vs ');
    this.hud.pushFeed(`🏆 MATCH CLASSÉ LANCÉ ! ${names} — Premier à ${msg.targetKOs || 3} K.O. !`, '#ffd43b');
  }

  _onRankedScore(msg) {
    if (this.zone !== 'ranked') return;
    const summary = Object.entries(msg.scores || {})
      .map(([id, sc]) => {
        const name = id === this.mp.playerId ? this.player.name : (this.remotePlayers.get(id)?.name || 'Joueur');
        return `${name}: ${sc}`;
      })
      .join(' | ');
    this.hud.pushFeed(`🏆 Score Classé — ${summary}`, '#ffe066');
  }

  _onRankedEnd(msg) {
    const won = msg.winnerId === this.mp.playerId;
    const delta = won ? (msg.eloGain || 35) : -(msg.eloLoss || 15);
    this.playerElo = Math.max(0, this.playerElo + delta);
    localStorage.setItem('kyoto_elo', String(this.playerElo));
    this.hud.setRankDisplay(this.playerElo);
    const rank = getRankForElo(this.playerElo);
    if (won) {
      this.sound.playEquip();
      this.hud.pushFeed(`🏆 VICTOIRE CLASSÉE ! +${msg.eloGain || 35} Elo → ${rank.icon} ${rank.name} (${this.playerElo})`, '#3be384');
    } else {
      this.hud.pushFeed(`🏆 Fin du match (${msg.winnerName} gagne) • -${msg.eloLoss || 15} Elo → ${rank.icon} ${rank.name}`, '#ff99a8');
    }
    setTimeout(() => {
      if (this.zone === 'ranked') this.switchZone('dojo');
    }, 3200);
  }

  // --- OPEN-WORLD BATTLE ROYALE ---
  enterBattleRoyale() {
    this.switchZone('br');
    if (this.mp.connected) {
      this.mp.joinBR(false);
    } else {
      this.brWorld.generate(Date.now() % 999999);
    }
  }

  _onBRSync(msg) {
    if (!msg) return;
    if (msg.seed && msg.seed !== this.brWorld.seed) {
      this.brWorld.generate(msg.seed);
    }
    for (const id of msg.takenLoots || []) {
      this.brWorld.markLootTaken(id);
    }
  }

  _onBRLootTaken(lootId) {
    this.brWorld.markLootTaken(lootId);
  }

  _onRemoteGunshot(msg) {
    if (this.zone !== 'br') return;
    const start = new THREE.Vector3(msg.start?.[0] || 0, msg.start?.[1] || 1, msg.start?.[2] || 0);
    const end = new THREE.Vector3(msg.end?.[0] || 0, msg.end?.[1] || 1, msg.end?.[2] || 0);
    this.vfx.spawnTracer(start, end, msg.color || 0xffe066, 0.14);
    this.vfx.spawnMuzzleFlash(start, msg.color || 0xffe066);
    if (start.distanceTo(this.player.position) < 95) {
      this.sound.playGunshot(msg.weaponId || 'rifle');
    }
  }

  _getActiveWeapon() {
    if (this.zone !== 'br' || this.brActiveSlot < 0) return null;
    const slot = this.brSlots[this.brActiveSlot];
    return slot ? WEAPONS[slot.weaponId] || null : null;
  }

  _selectBRSlot(idx) {
    if (this.zone !== 'br') return;
    this.reloadTimer = 0;
    this.isAds = false;
    if (idx < 0 || idx > 2 || !this.brSlots[idx]) {
      this.brActiveSlot = -1;
      this.player.setEquippedGun(null);
      this.fpRig.setGunModel(null);
    } else {
      this.brActiveSlot = idx;
      const wid = this.brSlots[idx].weaponId;
      this.player.setEquippedGun(wid);
      this.fpRig.setGunModel(wid);
      this.sound.playEquip();
    }
    this.hud.updateBRHotbar(this.brSlots, this.brActiveSlot, false, this.player.hasPower);
    this._updateCameraVisibility();
  }

  _pickupBRLoot(item) {
    if (!item || item.taken) return;
    this.brWorld.markLootTaken(item.id);
    this.mp.sendBRLoot(item.id);
    this.sound.playEquip();
    this.vfx.spawnBurst(item.pos.clone().add(new THREE.Vector3(0, 1.0, 0)), new THREE.Color(item.color).getHex(), 12, 7, 0.2);

    if (item.kind === 'gun') {
      const w = WEAPONS[item.itemId];
      if (!w) return;
      let targetIdx = this.brSlots.findIndex((s) => !s);
      if (targetIdx === -1) targetIdx = this.brActiveSlot >= 0 ? this.brActiveSlot : 0;
      this.brSlots[targetIdx] = { weaponId: w.id, ammo: w.magSize };
      this._selectBRSlot(targetIdx);
      this.hud.pushFeed(`🔫 Arme ramassée : ${w.name} (${w.rarity}) !`, w.rarityColor);
    } else if (item.kind === 'power') {
      const p = POWER_MAP[item.itemId];
      if (!p) return;
      this.player.setPower(p.id);
      this.fpRig.setPowerModel(p.id);
      this.hud.setEquippedPower(p);
      this.hud.updateBRHotbar(this.brSlots, this.brActiveSlot, this.reloadTimer > 0, true);
      this.hud.pushFeed(`⚡ Pouvoir trouvé : ${p.name} ! ([E] / [A] / [R] ou [4] mains)`, p.color);
    } else if (item.kind === 'medkit') {
      this.player.heal(45);
      this.hud.pushFeed('❤️ Kit de Soin utilisé (+45 PV) !', '#ff5964');
    } else if (item.kind === 'shield') {
      this.player.shield = Math.min(this.player.maxShield, this.player.shield + 50);
      this.hud.pushFeed('🛡️ Potion Bouclier bue (+50 Bouclier) !', '#29c7ff');
    }
    this.brNearestLoot = null;
    this.hud.setBRLootPrompt(null);
  }

  _startReload() {
    const w = this._getActiveWeapon();
    if (!w || this.reloadTimer > 0) return;
    const slot = this.brSlots[this.brActiveSlot];
    if (!slot || slot.ammo >= w.magSize) return;
    this.reloadTimer = w.reloadTime;
    this.isAds = false;
    this.sound.playReload();
    this.hud.updateBRHotbar(this.brSlots, this.brActiveSlot, true, this.player.hasPower);
  }

  _fireActiveGun() {
    const w = this._getActiveWeapon();
    if (!w || this.gunCooldown > 0 || this.reloadTimer > 0 || this.player.isDead || this.brPhase !== 'ground') return;
    const slot = this.brSlots[this.brActiveSlot];
    if (!slot) return;
    if (slot.ammo <= 0) {
      this._startReload();
      return;
    }

    slot.ammo -= 1;
    this.gunCooldown = w.fireRate;
    this.gunRecoil = Math.min(1, this.gunRecoil + (w.id === 'sniper' ? 0.95 : w.id === 'shotgun' ? 0.75 : 0.28));
    this.sound.playGunshot(w.id);
    this.vfx.addShake(w.id === 'sniper' ? 0.42 : w.id === 'shotgun' ? 0.34 : 0.1);

    const eye = this.player.getEyePosition();
    const baseDir = this.player.getForwardDirection(true);
    const muzzlePos = eye.clone().addScaledVector(baseDir, 1.15).add(new THREE.Vector3(0, -0.14, 0));
    this.vfx.spawnMuzzleFlash(muzzlePos, w.tracerColor);

    const spread = this.isAds ? w.adsSpread : w.spread;
    const fighters = this._getActiveFighters();
    const ctx = this._getCombatContext();

    for (let pel = 0; pel < w.pellets; pel++) {
      const dir = baseDir.clone();
      dir.x += (Math.random() - 0.5) * spread * 2;
      dir.y += (Math.random() - 0.5) * spread * 2;
      dir.z += (Math.random() - 0.5) * spread * 2;
      dir.normalize();

      const maxPt = eye.clone().addScaledVector(dir, w.range);
      const line = new THREE.Line3(eye, maxPt);
      const closest = new THREE.Vector3();

      let hitTarget = null;
      let hitDist = w.range;
      let hitPoint = maxPt;
      let isHeadshot = false;

      for (const f of fighters) {
        if (f === this.player || f.isDead) continue;
        const bodyCenter = f.position.clone().add(new THREE.Vector3(0, 1.25 * f.currentScale, 0));
        line.closestPointToPoint(bodyCenter, true, closest);
        const distToRay = closest.distanceTo(bodyCenter);
        const dFromEye = eye.distanceTo(closest);
        if (distToRay < 1.15 * f.currentScale && dFromEye < hitDist) {
          hitDist = dFromEye;
          hitTarget = f;
          hitPoint = closest.clone();
          isHeadshot = closest.y > f.position.y + 1.62 * f.currentScale;
        }
      }

      // Terrain clip check
      if (!hitTarget) {
        for (let d = 6; d <= w.range; d += 6) {
          const pt = eye.clone().addScaledVector(dir, d);
          const gh = this.brWorld.getWalkableHeight(pt.x, pt.z, 200);
          if (pt.y <= gh) {
            hitPoint = new THREE.Vector3(pt.x, gh, pt.z);
            break;
          }
        }
      }

      this.vfx.spawnTracer(muzzlePos, hitPoint, w.tracerColor, w.id === 'sniper' ? 0.25 : 0.11);
      if (pel === 0) this.mp.sendGunshot(w.id, muzzlePos, hitPoint, w.tracerColor);

      if (hitTarget) {
        const dmg = Math.round(w.dmg * (isHeadshot ? w.headshotMult : 1));
        const kb = dir.clone().setY(0).normalize().multiplyScalar(w.id === 'shotgun' ? 12 : 6);
        kb.y = 3.5;
        hitTarget.takeDamage(dmg, kb, this.player, ctx);
        this.vfx.spawnBurst(hitPoint, isHeadshot ? 0xff4d6d : w.tracerColor, isHeadshot ? 12 : 6, 8, 0.16);
        if (isHeadshot) {
          this.hud.pushFeed(`🎯 HEADSHOT ! (-${dmg})`, '#ff4d6d');
        }
      } else {
        this.vfx.spawnBurst(hitPoint, 0xffe8a3, 4, 5, 0.14);
      }
    }

    this.hud.updateBRHotbar(this.brSlots, this.brActiveSlot, false, this.player.hasPower);
    if (slot.ammo <= 0) this._startReload();
  }

  switchZone(targetZone, instant = false) {
    const prevZone = this.zone;
    this.zone = targetZone;
    this.warpCooldown = 1.6;
    this.vfx.clear();
    this.powerExecutor.clear();
    this.isAds = false;
    this.isMouseDown = false;
    this.reloadTimer = 0;

    if (prevZone === 'br' && targetZone !== 'br') {
      // Restore player's normal Dojo power & clear BR firearms/glider
      this.brSlots = [null, null, null];
      this.brActiveSlot = -1;
      this.brFullMapOpen = false;
      this.player.isGliding = false;
      this.player.setEquippedGun(null);
      this.fpRig.setGunModel(null);
      this.player.setPower(this.savedDojoPowerId || 'thunder');
      this.fpRig.setPowerModel(this.player.powerId);
      this.hud.setEquippedPower(this.player.power);
      this.hud.setBRHudActive(false);
    }

    if (targetZone !== 'ranked' && this.inRankedQueue) {
      this.leaveRankedQueue();
    }

    if (!instant) {
      this.sound.playPortalWarp();
      this.hud.triggerWarpFlash();
    }

    const isDojo = targetZone === 'dojo';
    const isCustom = targetZone === 'custom';
    const isBR = targetZone === 'br';
    this.dojo.group.visible = isDojo;
    this.arena.group.visible = !isDojo && !isCustom && !isBR;
    this.customWorld.group.visible = isCustom;
    this.brWorld.group.visible = isBR;

    // Expand camera far clip in huge Open-World Battle Royale
    this.camera.far = isBR ? 650 : 320;
    this.camera.fov = this.baseFov;
    this.camera.updateProjectionMatrix();

    if (isDojo) {
      this.scene.background = new THREE.Color(0x160e09);
      this.scene.fog = new THREE.Fog(0x1d110a, 38, 98);
      this.player.respawn(new THREE.Vector3(0, 0, 31.5));
      this.player.yaw = 0;
      this.player.pitch = -0.04;
      this.studioUi.setStudioActive(false, false);
      this.hud.setCombatHudHidden(false);
      this.hud.setBRHudActive(false);
      if (!instant) this.hud.pushFeed('Bienvenue au Grand Dojo — 28 Pouvoirs • 5 Portails !', '#ffd43b');
    } else if (isBR) {
      if (this.player.hasPower && this.player.powerId) this.savedDojoPowerId = this.player.powerId;
      this.studioUi.setStudioActive(false, false);
      this.hud.setCombatHudHidden(false);
      this.hud.setBRHudActive(true);
      this.scene.background = new THREE.Color(0x8fd1ff);
      this.scene.fog = new THREE.FogExp2(0x9ad8ff, 0.0014);

      // Start empty-handed inside the 3D Battle Plane
      this.brSlots = [null, null, null];
      this.brActiveSlot = -1;
      this.brFullMapOpen = false;
      this.brNearestLoot = null;
      this.brPhase = 'plane';
      this.player.shield = 0;
      this.player.isGliding = false;
      this.player.setEquippedGun(null);
      this.fpRig.setGunModel(null);
      this.player.setPower(null);
      this.fpRig.setPowerModel(null);
      this.player.respawn(this.brWorld.planeMesh.position.clone());
      this.player.yaw = 0;
      this.player.pitch = -0.35;
      this.hud.setEquippedPower(null);
      this.hud.updateBRHotbar(this.brSlots, -1, false, false);
      this.hud.setBRFlightPrompt('✈️ DANS L’AVION — Appuie sur <b>[ESPACE]</b> pour sauter ! • <b>[TAB]</b> Carte');
      this.hud.pushFeed('🪂 BATTLE ROYALE — Tu démarres sans rien : saute, plane et trouve armes & pouvoirs !', '#38d9ff');
    } else if (isCustom) {
      this._applyCustomWorldSky();
      this.studioEditorMode = true;
      this.customWorld.setEditorVisuals(true);
      this.studioUi.setStudioActive(true, true);
      this.studioUi.syncInspector(null);
      this.hud.setCombatHudHidden(true);
      const sp = this.customWorld.getSpawnPoint();
      this.player.respawn(new THREE.Vector3(sp.x, Math.max(4.5, sp.y + 3), sp.z));
      this.player.yaw = 0;
      this.player.pitch = -0.22;
      this._syncCustomWorld();
      this.hud.pushFeed(`🛠️ kyotoGame Studio — ${this.customWorld.data.name} (TAB pour tester/jouer !)`, '#b15cff');
    } else if (targetZone === 'combo') {
      this.studioUi.setStudioActive(false, false);
      this.hud.setCombatHudHidden(false);
      this.arena.setAtmosphere('combo');
      this.scene.background = new THREE.Color(0xf2c29b);
      this.scene.fog = new THREE.FogExp2(0xf0c29e, 0.0032);
      const sx = (Math.random() - 0.5) * 10;
      const sz = 36;
      const sy = getArenaWalkableHeight(sx, sz, 20) + 1.2;
      this.player.respawn(new THREE.Vector3(sx, sy, sz));
      this.player.yaw = 0;
      this.player.pitch = -0.06;
      this.hud.pushFeed(`🔥 MODE COMBO — Mise au sol 1.6s • Contre [Clic G] à 1.1s !`, '#ff6b3d');
    } else if (targetZone === 'ranked') {
      this.studioUi.setStudioActive(false, false);
      this.hud.setCombatHudHidden(false);
      this.arena.setAtmosphere('arena');
      this.scene.background = new THREE.Color(0xdbeafe);
      this.scene.fog = new THREE.FogExp2(0xdbeafe, 0.0028);
      const sx = (Math.random() - 0.5) * 26;
      const sz = (Math.random() < 0.5 ? 1 : -1) * 24;
      const sy = getArenaWalkableHeight(sx, sz, 20) + 1.2;
      this.player.respawn(new THREE.Vector3(sx, sy, sz));
      this.player.yaw = 0;
      this.player.pitch = -0.05;
    } else {
      this.studioUi.setStudioActive(false, false);
      this.hud.setCombatHudHidden(false);
      this.arena.setAtmosphere('arena');
      this.scene.background = new THREE.Color(0xcde5f7);
      this.scene.fog = new THREE.FogExp2(0xd2e7f7, 0.003);
      const sx = (Math.random() - 0.5) * 8;
      const sz = 36;
      const sy = getArenaWalkableHeight(sx, sz, 20) + 1.2;
      this.player.respawn(new THREE.Vector3(sx, sy, sz));
      this.player.yaw = 0;
      this.player.pitch = -0.06;
      this.hud.pushFeed(`Entrée en Mode Classique avec ${this.player.power.name} !`, this.player.power.color);
    }

    this.sound.setZone(isBR ? 'arena' : targetZone === 'ranked' ? 'arena' : targetZone);
    this.hud.setZone(targetZone, this.customWorld.data.name, this.customWorld.data.welcomeText);
    this.hud.showPedestalPrompt(null);
    this.hud.updateRespawnOverlay(false);
    this._updateCameraVisibility();
  }

  _equipPower(power) {
    if (this.player.powerId === power.id) return;
    this.player.setPower(power.id);
    this.fpRig.setPowerModel(power.id);
    this.sound.playEquip();
    this.hud.setEquippedPower(power);
    this.hud.pushFeed(`Pouvoir équipé : ${power.name} (${power.title})`, power.color);
    this.vfx.spawnRing(this.player.position, power.hex, 3.6, 0.4);
    this.vfx.spawnBurst(this.player.position.clone().add(new THREE.Vector3(0, 1.4, 0)), power.hex, 16, 7, 0.2);
  }

  _bindEvents() {
    window.addEventListener('resize', () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    });

    document.addEventListener('pointerlockchange', () => {
      this.isPointerLocked = document.pointerLockElement === this.renderer.domElement;
      this.hud.setPointerLocked(this.isPointerLocked);
      // In Studio Editor Mode, unlocking pointer lets you freely edit Inspector/Text/Palette WITHOUT forcing Pause
      const isStudioEditor = this.zone === 'custom' && this.studioEditorMode;
      if (!this.isPointerLocked && !this.hud.isModalOpen && !this.hud.isChatTyping && !isStudioEditor && !this.studioUi.isWorldModalOpen) {
        this.hud.setSettingsOpen(true);
      }
    });

    this.renderer.domElement.addEventListener('mousedown', (e) => {
      this.sound.init();
      if (this.hud.isModalOpen || this.hud.isChatTyping || this.studioUi.isWorldModalOpen) return;
      if (!this.isPointerLocked) {
        this.requestPointerLock();
        return;
      }

      // Studio Editor 3D Placement / Selection / Deletion
      if (this.zone === 'custom' && this.studioEditorMode) {
        this._handleStudioClick(e.button);
        return;
      }

      if (e.button === 0) {
        this.isMouseDown = true;
        if (this.zone === 'br' && this.brPhase === 'plane') {
          this._dropFromPlane();
          return;
        }
        if (this.zone === 'dojo' && this.nearMirror) {
          this.hud.setCustomizerOpen(true);
        } else if (this.nearestPedestal) {
          this._equipPower(this.nearestPedestal.power);
        } else if (this._getActiveWeapon()) {
          this._fireActiveGun();
        } else {
          this._castPlayerPrimary();
        }
      } else if (e.button === 2) {
        if (this._getActiveWeapon()) {
          this.isAds = true;
          this._updateCameraVisibility();
        } else {
          this._castPlayerAb1();
        }
      }
    });

    window.addEventListener('mouseup', (e) => {
      if (e.button === 0) this.isMouseDown = false;
      if (e.button === 2) {
        this.isAds = false;
        this._updateCameraVisibility();
      }
    });

    window.addEventListener('contextmenu', (e) => e.preventDefault());

    window.addEventListener('mousemove', (e) => {
      if (!this.isPointerLocked || this.hud.isModalOpen) return;
      const sens = 0.0022 * this.sensitivity;
      this.player.yaw -= e.movementX * sens;
      this.player.pitch = THREE.MathUtils.clamp(this.player.pitch - e.movementY * sens, -1.32, 1.32);
    });

    window.addEventListener(
      'wheel',
      (e) => {
        if (this.hud.isModalOpen || this.studioUi.isWorldModalOpen || (this.zone === 'custom' && this.studioEditorMode)) return;
        if (e.deltaY > 0) {
          if (!this.isThirdPerson) {
            this.isThirdPerson = true;
            this.thirdPersonDistance = 4.6;
          } else {
            this.thirdPersonDistance = Math.min(10.5, this.thirdPersonDistance + 0.9);
          }
        } else if (e.deltaY < 0) {
          if (this.isThirdPerson) {
            this.thirdPersonDistance -= 0.9;
            if (this.thirdPersonDistance < 3.4) {
              this.isThirdPerson = false;
            }
          }
        }
        this._updateCameraVisibility();
        this.hud.setCameraModeLabel(this.isThirdPerson);
      },
      { passive: true }
    );

    window.addEventListener('keydown', (e) => {
      if (this.hud.isChatTyping) return;

      if (e.code === 'F11' && window.kyotoDesktop?.toggleFullscreen) {
        e.preventDefault();
        window.kyotoDesktop.toggleFullscreen();
        return;
      }

      if (e.code === 'Escape') {
        if (this.studioUi.isWorldModalOpen) {
          this.studioUi.setWorldModalOpen(false);
        } else if (this.hud.isCustomizerOpen) {
          this.hud.setCustomizerOpen(false);
          this.requestPointerLock();
        } else if (this.hud.isMpOpen && this.hasStarted) {
          this.hud.setMpOpen(false);
          this.requestPointerLock();
        } else if (this.hud.isSettingsOpen) {
          this.hud.setSettingsOpen(false);
          this.requestPointerLock();
        } else if (this.hasStarted) {
          this.hud.setSettingsOpen(true);
        }
        return;
      }

      if (this.hud.isModalOpen || this.studioUi.isWorldModalOpen) return;

      // Studio & Battle Royale Tab Shortcuts
      if (e.code === 'Tab' && this.zone === 'custom') {
        e.preventDefault();
        this.toggleStudioPlayMode();
        return;
      }
      if (e.code === 'Tab' && this.zone === 'br') {
        e.preventDefault();
        this.brFullMapOpen = !this.brFullMapOpen;
        this.hud.setBRFullMapOpen(this.brFullMapOpen);
        return;
      }
      if (e.code === 'KeyB') {
        this.switchZone('custom');
        return;
      }
      if (this.zone === 'custom' && this.studioEditorMode) {
        if (e.code === 'KeyR') {
          this.studioUi.draftRotY = (this.studioUi.draftRotY + Math.PI / 4) % (Math.PI * 2);
          if (this.customWorld.selectedId) {
            const sp = this.customWorld.getSelectedSpec();
            if (sp) {
              this.customWorld.updateObject(sp.id, { rotY: (sp.rotY + Math.PI / 4) % (Math.PI * 2) });
              this.studioUi.syncInspector(this.customWorld.getSelectedSpec());
              this._syncCustomWorld();
            }
          } else {
            this.studioUi.syncInspector(null);
          }
          return;
        }
        if (e.code === 'KeyX') {
          this.studioUi.setToolMode(this.studioUi.toolMode === 'place' ? 'select' : 'place');
          return;
        }
        if (e.code === 'KeyG') {
          this.studioUi.gridSnap = !this.studioUi.gridSnap;
          this.studioUi.btnSnap.textContent = this.studioUi.gridSnap ? '🧲 Grille: ON' : '🧲 Grille: OFF';
          this.studioUi.btnSnap.classList.toggle('active', this.studioUi.gridSnap);
          return;
        }
        if (e.code === 'Delete' || e.code === 'Backspace') {
          if (this.customWorld.selectedId) {
            this.customWorld.removeObject(this.customWorld.selectedId);
            this.studioUi.syncInspector(null);
            this.sound.playHit(false);
            this._syncCustomWorld();
          }
          return;
        }
        if (e.code.startsWith('Digit')) {
          const num = parseInt(e.code.replace('Digit', ''), 10);
          if (num >= 1 && num <= 9 && STUDIO_ITEMS[num - 1]) {
            this.studioUi.selectBuildType(STUDIO_ITEMS[num - 1].type);
            return;
          }
        }
      }

      if (e.code === 'KeyC') {
        this.hud.setCustomizerOpen(true);
        return;
      }

      if (e.code === 'Enter' && this.mp.connected) {
        e.preventDefault();
        this.hud.openChatInput();
        return;
      }

      if (e.code === 'KeyM' || e.code === 'Semicolon') {
        // KeyM on QWERTY, Semicolon is M on French AZERTY
        if (e.key.toLowerCase() === 'm') {
          this.hud.setMpOpen(true);
          return;
        }
      }

      this.keys.add(e.code);

      if (e.code === 'KeyV' || e.code === 'F5') {
        e.preventDefault();
        this.toggleCameraMode();
      }
      if (e.code === 'KeyT' && this.zone !== 'dojo') {
        this.switchZone('dojo');
      }
      if (e.code === 'KeyE') {
        if (this.zone === 'custom' && this.studioEditorMode) return;
        if (this.zone === 'br' && this.brNearestLoot) {
          this._pickupBRLoot(this.brNearestLoot);
        } else if (this.zone === 'dojo' && this.nearMirror) {
          this.hud.setCustomizerOpen(true);
        } else if (this.nearestPedestal) {
          this._equipPower(this.nearestPedestal.power);
        } else {
          this._castPlayerAb1();
        }
      }
      if ((e.code === 'KeyQ' || e.code === 'KeyF') && !(this.zone === 'custom' && this.studioEditorMode)) {
        this._castPlayerAb2();
      }
      if (e.code === 'KeyR' && !(this.zone === 'custom' && this.studioEditorMode)) {
        if (this._getActiveWeapon()) {
          this._startReload();
        } else {
          this._castPlayerAb3();
        }
      }
      if (this.zone === 'br' && e.code === 'Space') {
        if (this.brPhase === 'plane') {
          this._dropFromPlane();
        } else if (this.brPhase === 'freefall') {
          this.brPhase = 'gliding';
          this.player.isGliding = true;
          this.sound.playGliderOpen();
          this.hud.setBRFlightPrompt('🪂 PLANEUR DÉPLOYÉ — Dirige-toi vers un village ! ([ESPACE] piqué)');
          this._updateCameraVisibility();
        } else if (this.brPhase === 'gliding') {
          const gh = this.brWorld.getWalkableHeight(this.player.position.x, this.player.position.z, this.player.position.y);
          if (this.player.position.y - gh > 14) {
            this.brPhase = 'freefall';
            this.player.isGliding = false;
            this.hud.setBRFlightPrompt('💨 CHUTE LIBRE — Appuie sur <b>[ESPACE]</b> pour ouvrir le Planeur !');
            this._updateCameraVisibility();
          }
        }
      }
      if (this.zone === 'br') {
        if (e.code === 'Digit1') this._selectBRSlot(0);
        else if (e.code === 'Digit2') this._selectBRSlot(1);
        else if (e.code === 'Digit3') this._selectBRSlot(2);
        else if (e.code === 'Digit4') this._selectBRSlot(-1);
      }
      if ((e.code === 'ShiftLeft' || e.code === 'ShiftRight') && !(this.zone === 'custom' && this.studioEditorMode)) {
        this._triggerDash();
      }
    });

    window.addEventListener('keyup', (e) => {
      this.keys.delete(e.code);
    });
  }

  _handleStudioClick(button) {
    this.raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
    const hit = this.customWorld.raycast(this.raycaster);

    // Right click: delete aimed object
    if (button === 2) {
      if (hit && hit.objectId) {
        this.customWorld.removeObject(hit.objectId);
        this.studioUi.syncInspector(null);
        this.sound.playHit(false);
        this._syncCustomWorld();
      }
      return;
    }

    // Left click in Select mode: select aimed object & release mouse to edit inspector
    if (this.studioUi.toolMode === 'select') {
      const spec = hit && hit.objectId ? this.customWorld.selectObject(hit.objectId) : this.customWorld.selectObject(null);
      this.studioUi.syncInspector(spec);
      if (spec) {
        this.sound.playEquip();
        if (document.pointerLockElement) document.exitPointerLock();
      }
      return;
    }

    // Left click in Place mode: place new object at ghost position
    const pos = this.lastGhostPos;
    const added = this.customWorld.addObject({
      type: this.studioUi.activeType,
      pos: [pos.x, pos.y, pos.z],
      rotY: this.studioUi.draftRotY,
      scale: [...this.studioUi.draftScale],
      color: this.studioUi.draftColor,
      title: this.studioUi.draftTitle,
      text: this.studioUi.draftText,
      powerId: this.studioUi.draftPowerId,
    });
    this.studioUi.syncInspector(added);
    this.sound.playEquip();
    this.vfx.spawnBurst(pos.clone().add(new THREE.Vector3(0, 0.8, 0)), new THREE.Color(added.color).getHex(), 8, 6, 0.16);
    this._syncCustomWorld();
  }

  _updateStudioGhost() {
    if (this.zone !== 'custom' || !this.studioEditorMode || this.studioUi.toolMode !== 'place') {
      this.customWorld.hideGhost();
      return;
    }
    this.raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
    const hit = this.customWorld.raycast(this.raycaster);
    let pos;
    if (hit) {
      pos = hit.point.clone();
      // When placing on vertical side of a block, offset slightly along normal
      if (hit.normal.y < 0.5) {
        pos.addScaledVector(hit.normal, this.studioUi.draftScale[0] * 0.45);
      }
    } else {
      // Mid-air placement 10m in front of camera
      pos = this.camera.position.clone().addScaledVector(this.player.getForwardDirection(true), 10);
    }

    if (this.studioUi.gridSnap) {
      pos.x = Math.round(pos.x);
      pos.y = Math.round(pos.y * 2) / 2;
      pos.z = Math.round(pos.z);
    }
    this.lastGhostPos.copy(pos);
    this.customWorld.updateGhost(
      this.studioUi.activeType,
      pos,
      this.studioUi.draftRotY,
      this.studioUi.draftScale,
      this.studioUi.draftColor
    );
  }

  _getCombatContext() {
    const isCombo =
      this.zone === 'combo' ||
      (this.zone === 'custom' && this.customWorld.data.combatMode === 'combo');
    return {
      vfx: this.vfx,
      sound: this.sound,
      camera: this.camera,
      playerPos: this.player.position,
      comboMode: isCombo,
      onHitConfirm: (attacker, victim, dmg) => {
        if (attacker && attacker.isPlayer) {
          this.hud.flashHitmarker();
        }
        if (victim.isPlayer) {
          this.hud.flashDamage();
          this.vfx.addShake(Math.min(0.8, 0.35 + (dmg || 10) * 0.015));
          // Snappy directional camera knockback tilt & upward kick
          this.camKnockRoll = (Math.random() < 0.5 ? -1 : 1) * Math.min(0.24, 0.12 + (dmg || 10) * 0.004);
          this.camKnockPitch = Math.min(0.16, 0.07 + (dmg || 10) * 0.003);
        }
      },
      onRemoteHit: (target, dmg, kb, status) => {
        this.mp.sendHit(target.id, dmg, kb, status);
      },
      onKO: (victim, killer) => {
        if (victim.isDead) return;

        if (victim.isPlayer && this.mp.connected) {
          const killerId = killer && killer.isRemotePlayer ? killer.id : null;
          this.mp.sendKO(killerId);
        }

        if (killer && killer !== victim) {
          if (!killer.isRemotePlayer) killer.kos += 1;
          this.hud.pushFeed(`💥 ${killer.name} a mis K.O. ${victim.name} !`, killer.power?.color || '#ffd43b');
        } else {
          this.hud.pushFeed(`💨 ${victim.name} est tombé dans le vide !`, '#9ec5f8');
        }

        if (victim.isPlayer || (killer && killer.isPlayer)) {
          this.sound.playKO();
        }
        this.vfx.spawnBurst(victim.position.clone().add(new THREE.Vector3(0, 1.4, 0)), victim.power.hex, 26, 14, 0.32);
        this.vfx.spawnRing(victim.position, 0xff5964, 5.5, 0.45);

        if (victim.isPlayer) {
          // Enter 3.0s Player Respawn Delay with death camera & countdown
          this.playerRespawnTotal = 3.0;
          this.lastKillerText =
            killer && killer !== victim
              ? `Éliminé par ${killer.name} (${killer.power?.name || 'Combat'})`
              : 'Tu es tombé hors de l’île !';
          victim.enterKOState(this.playerRespawnTotal);
          this._updateCameraVisibility();
          this.hud.updateRespawnOverlay(true, this.playerRespawnTotal, this.playerRespawnTotal, this.lastKillerText);
        } else if (!victim.isRemotePlayer) {
          // Enter 3.5s Bot Respawn Delay
          victim.enterKOState(3.5);
        }
      },
    };
  }

  _getActiveFighters() {
    const list = [this.player];
    if (this.zone === 'arena' || this.zone === 'combo' || this.zone === 'custom' || this.zone === 'ranked' || this.zone === 'br') {
      if (this.botsEnabled && (this.zone === 'arena' || this.zone === 'combo')) list.push(...this.botManager.bots);
      for (const remote of this.remotePlayers.values()) {
        if (remote.remoteZone === this.zone) list.push(remote);
      }
    }
    return list;
  }

  _dropFromPlane() {
    if (this.zone !== 'br' || this.brPhase !== 'plane') return;
    this.brPhase = 'freefall';
    this.player.position.copy(this.brWorld.planeMesh.position).add(new THREE.Vector3(0, -4.5, 0));
    this.player.velocity.set(0, -8, 0);
    this.player.onGround = false;
    this.sound.playPower('wind', 1);
    this.hud.setBRFlightPrompt('💨 CHUTE LIBRE — Appuie sur <b>[ESPACE]</b> pour ouvrir le Planeur 3D !');
    this._updateCameraVisibility();
  }

  _castPlayerPrimary() {
    if (this.player.isDead) return;
    // Mode Combo: Counter-Punch Combo Breaker after 1.1s on the ground
    if (this.player.knockdownTimer > 0) {
      if (this.player.canCounterPunch()) {
        const broke = this.powerExecutor.castCounterPunch(this.player, this._getActiveFighters(), this._getCombatContext());
        this.mp.sendAction('counter', this.player);
        this.hud.pushFeed(broke ? '⚡ CONTRE ! Tu as coupé le combo !' : '⚡ CONTRE ! Tu te relèves en force !', '#ffd43b');
      }
      return;
    }
    if (this.powerExecutor.castPrimary(this.player, this._getActiveFighters(), this._getCombatContext())) {
      this.mp.sendAction('lmb', this.player);
    }
  }

  _castPlayerAb1() {
    if (this.player.isDead || this.player.knockdownTimer > 0) return;
    if (this.powerExecutor.castAbility1(this.player, this._getActiveFighters(), this._getCombatContext())) {
      this.mp.sendAction('ab1', this.player);
    }
  }

  _castPlayerAb2() {
    if (this.player.isDead || this.player.knockdownTimer > 0) return;
    if (this.powerExecutor.castAbility2(this.player, this._getActiveFighters(), this._getCombatContext())) {
      this.mp.sendAction('ab2', this.player);
    }
  }

  _castPlayerAb3() {
    if (this.player.isDead || this.player.knockdownTimer > 0) return;
    if (this.powerExecutor.castAbility3(this.player, this._getActiveFighters(), this._getCombatContext())) {
      this.mp.sendAction('ab3', this.player);
    }
  }

  _triggerDash() {
    if (this.player.isDead || this.player.knockdownTimer > 0 || this.player.dashCd > 0 || this.player.freezeTimer > 0) return;
    this.player.dashCd = 2.2;
    const dir = this.player.getForwardDirection(false);
    this.player.velocity.x = dir.x * 24;
    this.player.velocity.z = dir.z * 24;
    this.player.velocity.y = Math.max(this.player.velocity.y, 4.5);
    this.sound.playDash();
    this.vfx.spawnBurst(this.player.position.clone().add(new THREE.Vector3(0, 0.8, 0)), this.player.power.hex, 10, 6, 0.2);
    this.mp.sendAction('dash', this.player);
  }

  _updatePlayerMovement(dt) {
    const p = this.player;

    // Studio Editor Free-Flight Movement
    if (this.zone === 'custom' && this.studioEditorMode) {
      const fly = new THREE.Vector3();
      if (!this.hud.isChatTyping) {
        if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) fly.z -= 1;
        if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) fly.z += 1;
        if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) fly.x -= 1;
        if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) fly.x += 1;
      }
      if (fly.lengthSq() > 0) {
        fly.normalize().applyAxisAngle(new THREE.Vector3(0, 1, 0), p.yaw);
      }
      if (!this.hud.isChatTyping) {
        if (this.keys.has('Space')) fly.y += 1;
        if (this.keys.has('ControlLeft') || this.keys.has('ControlRight')) fly.y -= 1;
      }
      const speed = this.keys.has('ShiftLeft') ? 32 : 17;
      p.position.addScaledVector(fly, speed * dt);
      p.position.y = Math.max(-20, Math.min(120, p.position.y));
      p.velocity.set(0, 0, 0);
      this.nearestPedestal = null;
      this.hud.showPedestalPrompt(null);
      return;
    }

    // Handle Player K.O. Respawn Delay Countdown
    if (p.isDead) {
      p.respawnTimer -= dt;
      this.hud.updateRespawnOverlay(true, p.respawnTimer, this.playerRespawnTotal, this.lastKillerText);
      if (p.respawnTimer <= 0) {
        if (this.zone === 'br') {
          this.enterBattleRoyale();
          return;
        }
        let spawnPos;
        if (this.zone === 'custom') {
          spawnPos = this.customWorld.getSpawnPoint();
        } else {
          const sx = (Math.random() - 0.5) * 20;
          const sz = 26 + Math.random() * 14;
          spawnPos = new THREE.Vector3(sx, Math.max(0, getArenaWalkableHeight(sx, sz, 20)) + 1.5, sz);
        }
        p.respawn(spawnPos);
        this.hud.updateRespawnOverlay(false);
        this._updateCameraVisibility();
        this.sound.playEquip();
        this.vfx.spawnRing(spawnPos, p.power.hex, 5.0, 0.5);
        this.vfx.spawnBurst(spawnPos.clone().add(new THREE.Vector3(0, 1.4, 0)), p.power.hex, 18, 9, 0.22);
      }
      return;
    }

    // Battle Royale Plane Ride, Freefall & 3D Glider Physics
    if (this.zone === 'br' && this.brPhase !== 'ground') {
      if (this.brPhase === 'plane') {
        p.position.copy(this.brWorld.planeMesh.position);
        p.velocity.set(0, 0, 0);
        if (this.brWorld.planeProgress >= 0.94) {
          this._dropFromPlane();
        }
        return;
      }

      const airMove = new THREE.Vector3();
      if (!this.hud.isChatTyping) {
        if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) airMove.z -= 1;
        if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) airMove.z += 1;
        if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) airMove.x -= 1;
        if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) airMove.x += 1;
      }
      if (airMove.lengthSq() > 0) {
        airMove.normalize().applyAxisAngle(new THREE.Vector3(0, 1, 0), p.yaw);
      }

      const isGlide = this.brPhase === 'gliding';
      const horizSpeed = isGlide ? 24 : 18;
      const fallSpeed = isGlide ? -5.8 : -22;
      p.velocity.x = THREE.MathUtils.lerp(p.velocity.x, airMove.x * horizSpeed, Math.min(1, dt * 5));
      p.velocity.z = THREE.MathUtils.lerp(p.velocity.z, airMove.z * horizSpeed, Math.min(1, dt * 5));
      p.velocity.y = THREE.MathUtils.lerp(p.velocity.y, fallSpeed, Math.min(1, dt * 5));
      p.position.addScaledVector(p.velocity, dt);
      p.onGround = false;

      const gh = this.brWorld.getWalkableHeight(p.position.x, p.position.z, p.position.y);
      // Auto-deploy 3D Glider when approaching ground cleanly
      if (!isGlide && gh > -10 && p.position.y - gh < 26) {
        this.brPhase = 'gliding';
        p.isGliding = true;
        this.sound.playGliderOpen();
        this.hud.setBRFlightPrompt('🪂 PLANEUR DÉPLOYÉ — Atterrissage imminent !');
        this._updateCameraVisibility();
      }
      if (gh > -10 && p.position.y <= gh + 0.1) {
        p.position.y = gh;
        p.velocity.set(0, 0, 0);
        p.onGround = true;
        p.isGliding = false;
        this.brPhase = 'ground';
        this.sound.playLand(0.6, false);
        this.hud.setBRFlightPrompt(null);
        this.hud.pushFeed('🏝️ Tu as atterri ! Cherche vite des armes [E] et pouvoirs !', '#3be384');
        this._updateCameraVisibility();
      } else if (p.position.y < -15) {
        this._getCombatContext().onKO(p, p.lastAttacker);
      }
      return;
    }

    const move = new THREE.Vector3();

    if (!this.hud.isChatTyping) {
      if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) move.z -= 1;
      if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) move.z += 1;
      if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) move.x -= 1;
      if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) move.x += 1;
    }

    if (p.freezeTimer <= 0 && p.chargeTimer <= 0 && p.knockdownTimer <= 0) {
      if (move.lengthSq() > 0) {
        move.normalize().applyAxisAngle(new THREE.Vector3(0, 1, 0), p.yaw);
        const baseSpeed = this.zone === 'dojo' ? 10.5 : 12.2;
        const speed = baseSpeed * p.getSpeedMultiplier();
        const accel = p.onGround ? 12 : 4.2;
        p.velocity.x = THREE.MathUtils.lerp(p.velocity.x, move.x * speed, Math.min(1, dt * accel));
        p.velocity.z = THREE.MathUtils.lerp(p.velocity.z, move.z * speed, Math.min(1, dt * accel));

        if (p.onGround) {
          p.footstepTimer -= dt;
          if (p.footstepTimer <= 0) {
            p.footstepTimer = p.titanTimer > 0 ? 0.44 : 0.34;
            this.sound.playFootstep(this.zone === 'dojo' ? 'wood' : 'grass', p.titanTimer > 0);
          }
        }
      } else if (p.onGround) {
        const friction = Math.min(1, dt * 10);
        p.velocity.x = THREE.MathUtils.lerp(p.velocity.x, 0, friction);
        p.velocity.z = THREE.MathUtils.lerp(p.velocity.z, 0, friction);
      }

      if (!this.hud.isChatTyping && this.keys.has('Space') && p.onGround) {
        p.velocity.y = p.titanTimer > 0 ? 14.5 : 12.6;
        p.onGround = false;
        this.sound.playJump(p.titanTimer > 0);
      }
    } else if (p.knockdownTimer > 0 && p.onGround) {
      // Friction while sliding on the ground after knockdown
      const friction = Math.min(1, dt * 6);
      p.velocity.x = THREE.MathUtils.lerp(p.velocity.x, 0, friction);
      p.velocity.z = THREE.MathUtils.lerp(p.velocity.z, 0, friction);
    }

    const wasAirborne = !p.onGround;
    const prevVy = p.velocity.y;
    const grav = this.zone === 'custom' ? (Number(this.customWorld.data.gravity) || 30) : 30;
    p.velocity.y -= grav * dt;
    p.position.addScaledVector(p.velocity, dt);

    if (this.zone === 'dojo') {
      this.dojo.resolveCollision(p.position, 0.7);
      if (p.position.y <= 0) {
        p.position.y = 0;
        p.velocity.y = 0;
        if (wasAirborne && prevVy < -6) this.sound.playLand(Math.abs(prevVy) / 16, p.titanTimer > 0);
        p.onGround = true;
      }

      if (this.warpCooldown <= 0 && p.position.distanceTo(this.dojo.portalPosition) < 3.0) {
        this.switchZone('arena');
        return;
      }
      if (this.warpCooldown <= 0 && p.position.distanceTo(this.dojo.studioPortalPosition) < 3.0) {
        this.switchZone('custom');
        return;
      }
      if (this.warpCooldown <= 0 && p.position.distanceTo(this.dojo.comboPortalPosition) < 3.0) {
        this.switchZone('combo');
        return;
      }
      if (this.warpCooldown <= 0 && this.dojo.brPortalPosition && p.position.distanceTo(this.dojo.brPortalPosition) < 3.0) {
        this.enterBattleRoyale();
        return;
      }
      if (this.warpCooldown <= 0 && this.dojo.rankedPortalPosition && p.position.distanceTo(this.dojo.rankedPortalPosition) < 3.0) {
        this.warpCooldown = 2.0;
        this.enterRankedQueue();
        return;
      }

      this.nearMirror = p.position.distanceTo(this.dojo.mirrorPosition) < 4.4;

      let closest = null;
      let bestD = 4.4;
      for (const ped of this.dojo.pedestals) {
        const d = p.position.distanceTo(ped.position);
        if (d < bestD) {
          bestD = d;
          closest = ped;
        }
      }
      this.nearestPedestal = closest;
      this.hud.showPedestalPrompt(closest ? closest.power : null, closest && closest.power.id === p.powerId);
    } else if (this.zone === 'custom') {
      // Custom World Play Mode Physics (solid blocks, platforms, ramps, jump pads, lava, pedestals, portals)
      this.customWorld.resolveSideCollisions(p.position, 0.68 * p.currentScale);
      const groundY = this.customWorld.getSurfaceHeightAt(p.position.x, p.position.z, p.position.y);
      if (p.position.y <= groundY && groundY > -20) {
        p.position.y = groundY;
        p.velocity.y = 0;
        if (wasAirborne && prevVy < -6) this.sound.playLand(Math.abs(prevVy) / 16, p.titanTimer > 0);
        p.onGround = true;
      } else if (p.position.y > groundY + 0.25) {
        p.onGround = false;
      }

      const interact = this.customWorld.getInteractiveObjects();
      for (const pad of interact.jumpPads) {
        if (p.position.distanceTo(pad.position) < pad.radius && Math.abs(p.position.y - pad.position.y) < 1.8) {
          p.velocity.y = 24;
          p.onGround = false;
          this.sound.playPower('wind', 2);
          this.vfx.spawnRing(pad.position, 0x45f2c2, 4.5, 0.38);
        }
      }

      // Lava hazard damage
      this.lavaTick = Math.max(0, this.lavaTick - dt);
      if (this.lavaTick <= 0) {
        for (const lv of interact.lavas) {
          if (
            p.position.x >= lv.box.min.x - 0.5 && p.position.x <= lv.box.max.x + 0.5 &&
            p.position.z >= lv.box.min.z - 0.5 && p.position.z <= lv.box.max.z + 0.5 &&
            Math.abs(p.position.y - lv.box.max.y) < 1.5
          ) {
            this.lavaTick = 0.7;
            p.takeDamage(16, new THREE.Vector3(0, 14, 0), null, this._getCombatContext());
            this.vfx.spawnBurst(p.position.clone().add(new THREE.Vector3(0, 0.8, 0)), 0xff4221, 12, 8, 0.2);
            break;
          }
        }
      }

      // Custom World Power Pedestals
      let closestPed = null;
      let bestPedD = 4.2;
      for (const ped of interact.pedestals) {
        const d = p.position.distanceTo(ped.position);
        if (d < bestPedD) { bestPedD = d; closestPed = ped; }
      }
      this.nearestPedestal = closestPed;
      this.hud.showPedestalPrompt(closestPed ? closestPed.power : null, closestPed && closestPed.power.id === p.powerId);

      // Custom World Return Portals
      for (const pt of interact.portals) {
        if (this.warpCooldown <= 0 && p.position.distanceTo(pt.position) < 3.0) {
          this.switchZone('dojo');
          return;
        }
      }

      if (p.position.y < -22) {
        this._getCombatContext().onKO(p, p.lastAttacker);
      }
    } else if (this.zone === 'br') {
      this.brWorld.resolveObstacles(p.position, 0.72 * p.currentScale);
      const groundY = this.brWorld.getWalkableHeight(p.position.x, p.position.z, p.position.y);
      if (p.position.y <= groundY && groundY > -20) {
        p.position.y = groundY;
        p.velocity.y = 0;
        if (wasAirborne && prevVy < -6) this.sound.playLand(Math.abs(prevVy) / 16, p.titanTimer > 0);
        p.onGround = true;
      } else if (p.position.y > groundY + 0.25) {
        p.onGround = false;
      }

      // Nearby 3D Loot Detection
      this.brNearestLoot = this.brWorld.findNearestLoot(p.position, 3.8);
      this.hud.setBRLootPrompt(this.brNearestLoot);

      // Shrinking Storm Damage
      const outside = this.brWorld.isOutsideStorm(p.position);
      this.hud.updateBRStormStatus(this.brWorld.stormRadius, outside);
      if (outside) {
        this.stormTick -= dt;
        if (this.stormTick <= 0) {
          this.stormTick = 1.0;
          p.takeDamage(5, null, null, { ...this._getCombatContext(), isDoT: true });
        }
      } else {
        this.stormTick = 0.4;
      }

      if (p.position.y < -18) {
        this._getCombatContext().onKO(p, p.lastAttacker);
      }
    } else {
      this.arena.resolveObstacles(p.position, 0.72 * p.currentScale);
      const groundY = getArenaWalkableHeight(p.position.x, p.position.z, p.position.y);
      if (p.position.y <= groundY && groundY > -20) {
        p.position.y = groundY;
        p.velocity.y = 0;
        if (wasAirborne && prevVy < -6) this.sound.playLand(Math.abs(prevVy) / 16, p.titanTimer > 0);
        p.onGround = true;
      } else if (p.position.y > groundY + 0.25) {
        p.onGround = false;
      }

      for (const pad of this.arena.jumpPads) {
        if (p.position.distanceTo(pad.position) < pad.radius && p.position.y < pad.position.y + 1.5) {
          p.velocity.y = 24;
          p.onGround = false;
          this.sound.playPower('wind', 2);
          this.vfx.spawnRing(pad.position, 0x45f2c2, 4.5, 0.38);
        }
      }

      if (this.warpCooldown <= 0 && p.position.distanceTo(this.arena.returnPortalPos) < 3.1) {
        this.switchZone('dojo');
        return;
      }

      if (p.position.y < -18) {
        this._getCombatContext().onKO(p, p.lastAttacker);
      }
    }
  }

  _updateCamera(dt) {
    const p = this.player;
    const shake = this.vfx.getShakeOffset(dt);
    const eye = p.getEyePosition();

    // Live 3D Orbiting Hero Preview when Character Customizer is open
    if (this.hud.isCustomizerOpen) {
      const orbitAngle = p.yaw + Math.PI + Math.sin(this.time * 0.7) * 0.45;
      const dist = 4.4 * p.currentScale;
      const focus = p.position.clone().add(new THREE.Vector3(0, 1.45 * p.currentScale, 0));
      // Offset focus slightly right so the 3D hero frames cleanly on the LEFT of the side drawer
      const rightVec = new THREE.Vector3(Math.cos(orbitAngle), 0, -Math.sin(orbitAngle));
      const camPos = focus
        .clone()
        .add(new THREE.Vector3(-Math.sin(orbitAngle) * dist, 0.35, -Math.cos(orbitAngle) * dist))
        .addScaledVector(rightVec, 1.0);
      this.camera.position.copy(camPos);
      this.camera.lookAt(focus.clone().addScaledVector(rightVec, 0.7));
      return;
    }

    // Battle Royale Plane Exterior Chase Camera
    if (this.zone === 'br' && this.brPhase === 'plane') {
      const planePos = this.brWorld.planeMesh.position;
      const offset = new THREE.Vector3(0, 7.5, 22);
      offset.applyEuler(new THREE.Euler(this.player.pitch * 0.45, this.player.yaw, 0, 'YXZ'));
      this.camera.position.copy(planePos).add(offset);
      this.camera.lookAt(planePos.clone().add(new THREE.Vector3(0, 1.5, 0)));
      return;
    }

    // Smooth ADS FOV zoom & Sniper Scope + Dynamic Tactical Crosshair
    const activeWep = this._getActiveWeapon();
    const targetFov = activeWep && this.isAds && !p.isDead ? activeWep.adsFov : this.baseFov;
    if (Math.abs(this.camera.fov - targetFov) > 0.08) {
      this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, targetFov, Math.min(1, dt * 14));
      this.camera.updateProjectionMatrix();
    }
    const isScoped = Boolean(activeWep && activeWep.scope && this.isAds && !this.isThirdPerson && !p.isDead);
    const speedSpread = Math.hypot(p.velocity.x, p.velocity.z) * 0.45;
    const spreadPx = activeWep ? (this.isAds ? 0 : 4) + speedSpread + this.gunRecoil * 14 : 0;
    this.hud.updateCrosshair(activeWep, spreadPx, isScoped);

    // Smooth decay of camera knockback tilt, pitch kick & gun recoil
    this.camKnockRoll = THREE.MathUtils.lerp(this.camKnockRoll, 0, Math.min(1, dt * 10));
    this.camKnockPitch = THREE.MathUtils.lerp(this.camKnockPitch, 0, Math.min(1, dt * 10));
    this.gunRecoil = Math.max(0, this.gunRecoil - dt * 3.8);

    // Dramatic Death Orbit Camera during Respawn Delay
    if (p.isDead) {
      const a = this.time * 0.9;
      const focus = new THREE.Vector3(p.position.x, Math.max(1.2, p.position.y + 1.0), p.position.z);
      const camPos = focus.clone().add(new THREE.Vector3(Math.cos(a) * 8.5, 4.5, Math.sin(a) * 8.5));
      this.camera.position.copy(camPos);
      this.camera.lookAt(focus);
      return;
    }

    if (!this.isThirdPerson || (this.zone === 'custom' && this.studioEditorMode)) {
      // Smoothly dip camera down toward the ground when knocked down in Mode Combo
      const kdDrop = p.knockdownTimer > 0 ? (p.knockdownTimer < 0.28 ? (p.knockdownTimer / 0.28) * 1.15 : 1.15) : 0;
      const kdRoll = p.knockdownTimer > 0 ? 0.22 * p.knockTiltSide * (kdDrop / 1.15) : 0;
      this.camera.position.set(eye.x + shake.x, eye.y - kdDrop + shake.y, eye.z);
      this.camera.rotation.order = 'YXZ';
      this.camera.rotation.y = p.yaw;
      this.camera.rotation.x = p.pitch + this.camKnockPitch + kdDrop * 0.22;
      this.camera.rotation.z = this.camKnockRoll + kdRoll;

      // Crisp First-Person Arms Framing, Attack Swing & Knockback Recoil
      const horizSpeed = Math.hypot(p.velocity.x, p.velocity.z);
      const bob = p.onGround && horizSpeed > 0.6 ? Math.sin(this.time * 10.5) * 0.036 : Math.sin(this.time * 2.2) * 0.01;
      const sway = p.onGround && horizSpeed > 0.6 ? Math.cos(this.time * 5.25) * 0.024 : 0;

      const hurtK = p.hurtAnim > 0 ? Math.sin((p.hurtAnim / 0.36) * Math.PI) : 0;
      const knockK = p.knockAnim > 0 ? Math.min(1, p.knockAnim / 0.45) : 0;
      const recoil = Math.max(hurtK, knockK);

      this.fpRig.leftArm.position.set(-0.56 + sway - recoil * 0.14, -0.44 + bob + recoil * 0.12, -0.68 + recoil * 0.18);
      this.fpRig.rightArm.position.set(0.56 - sway + recoil * 0.14, -0.44 - bob + recoil * 0.12, -0.68 + recoil * 0.18);
      this.fpRig.leftArm.rotation.set(0.22 + recoil * 0.55, -0.24 - recoil * 0.3, 0.08 + recoil * 0.35);
      this.fpRig.rightArm.rotation.set(0.22 + recoil * 0.55, 0.24 + recoil * 0.3, -0.08 - recoil * 0.35);

      if (p.attackAnim > 0) {
        const prog = 1 - p.attackAnim / 0.28;
        const swing = Math.sin(prog * Math.PI);
        if (p.attackSide > 0) {
          this.fpRig.rightArm.position.z -= swing * 0.34;
          this.fpRig.rightArm.position.x -= swing * 0.22;
          this.fpRig.rightArm.position.y += swing * 0.1;
          this.fpRig.rightArm.rotation.x -= swing * 0.58;
          this.fpRig.rightArm.rotation.y += swing * 0.45;
        } else {
          this.fpRig.leftArm.position.z -= swing * 0.32;
          this.fpRig.leftArm.position.x += swing * 0.18;
          this.fpRig.leftArm.position.y += swing * 0.09;
          this.fpRig.leftArm.rotation.x -= swing * 0.5;
          this.fpRig.leftArm.rotation.y -= swing * 0.35;
        }
      }

      if (this.fpRig.powerMesh && this.fpRig.powerMesh.userData.animate) {
        this.fpRig.powerMesh.userData.animate(this.time);
      }

      // Smooth 1P 3D Firearm Hip <-> ADS Centering & Recoil Kick
      if (this.fpRig.gunMount && this.player.equippedGunId) {
        const tx = this.isAds ? 0.0 : 0.34;
        const ty = this.isAds ? -0.19 : -0.27 + bob * 0.6;
        const tz = (this.isAds ? -0.44 : -0.58) + this.gunRecoil * 0.14;
        this.fpRig.gunMount.position.x = THREE.MathUtils.lerp(this.fpRig.gunMount.position.x, tx, Math.min(1, dt * 18));
        this.fpRig.gunMount.position.y = THREE.MathUtils.lerp(this.fpRig.gunMount.position.y, ty, Math.min(1, dt * 18));
        this.fpRig.gunMount.position.z = THREE.MathUtils.lerp(this.fpRig.gunMount.position.z, tz, Math.min(1, dt * 22));
        this.fpRig.gunMount.rotation.x = this.gunRecoil * 0.24;
      }
    } else {
      const dist = this.thirdPersonDistance * (0.75 + p.currentScale * 0.25);
      const offset = new THREE.Vector3(0, 0, dist);
      offset.applyEuler(new THREE.Euler(this.player.pitch, this.player.yaw, 0, 'YXZ'));

      const targetFocus = eye.clone().add(new THREE.Vector3(0, 0.25 * p.currentScale, 0));
      const camPos = targetFocus.clone().add(offset);

      if (this.zone === 'dojo') {
        camPos.x = THREE.MathUtils.clamp(camPos.x, -20.5, 20.5);
        camPos.z = THREE.MathUtils.clamp(camPos.z, -45.0, 40.0);
        camPos.y = THREE.MathUtils.clamp(camPos.y, 0.7, 12.2);
      } else if (this.zone === 'br') {
        const gh = this.brWorld.getWalkableHeight(camPos.x, camPos.z, camPos.y);
        if (gh > -20 && camPos.y < gh + 0.85) camPos.y = gh + 0.85;
      } else {
        const gh = getArenaWalkableHeight(camPos.x, camPos.z, camPos.y);
        if (gh > -20 && camPos.y < gh + 0.85) {
          camPos.y = gh + 0.85;
        }
      }

      this.camera.position.set(camPos.x + shake.x, camPos.y + shake.y, camPos.z);
      this.camera.lookAt(targetFocus);
    }
  }

  _loop(now) {
    requestAnimationFrame(this._loop);
    const dt = Math.min(0.05, (now - this._prevTime) / 1000);
    this._prevTime = now;
    this.time += dt;
    this.warpCooldown = Math.max(0, this.warpCooldown - dt);

    const ctx = this._getCombatContext();

    // Always animate remote players & world smoothly even when menu is open
    for (const remote of this.remotePlayers.values()) {
      remote.mesh.visible = remote.remoteZone === this.zone;
      if (remote.mesh.visible) {
        remote.interpolateRemote(dt, this.time);
      }
    }

    if (!this.hud.isModalOpen) {
      this._updatePlayerMovement(dt);
      this.player.updateStatusAndTimers(dt, this.time, ctx);
      this.mp.sendState(dt, this.player, this.zone);

      // Battle Royale Gun Cooldown, Auto-Fire & Reload Loop
      this.gunCooldown = Math.max(0, this.gunCooldown - dt);
      if (this.reloadTimer > 0) {
        this.reloadTimer -= dt;
        if (this.reloadTimer <= 0) {
          this.reloadTimer = 0;
          const w = this._getActiveWeapon();
          const slot = this.brActiveSlot >= 0 ? this.brSlots[this.brActiveSlot] : null;
          if (w && slot) {
            slot.ammo = w.magSize;
            this.hud.updateBRHotbar(this.brSlots, this.brActiveSlot, false, this.player.hasPower);
          }
        }
      }
      if (this.isMouseDown && this.isPointerLocked && this.zone === 'br' && this.brPhase === 'ground') {
        const w = this._getActiveWeapon();
        if (w && w.auto) this._fireActiveGun();
      }
    }

    if (this.zone === 'dojo') {
      this.dojo.update(this.time, this.player.powerId);
      if (!this.hud.isModalOpen) {
        this.powerExecutor.update(dt, [this.player], ctx);
        const portalDist = Math.min(
          this.player.position.distanceTo(this.dojo.portalPosition),
          this.player.position.distanceTo(this.dojo.studioPortalPosition),
          this.player.position.distanceTo(this.dojo.comboPortalPosition),
          this.dojo.brPortalPosition ? this.player.position.distanceTo(this.dojo.brPortalPosition) : 99,
          this.dojo.rankedPortalPosition ? this.player.position.distanceTo(this.dojo.rankedPortalPosition) : 99
        );
        this.sound.updateAmbience(dt, portalDist);
      }
    } else if (this.zone === 'custom') {
      this.customWorld.update(this.time);
      if (!this.hud.isModalOpen && !this.studioUi.isWorldModalOpen) {
        if (this.studioEditorMode) {
          this._updateStudioGhost();
        } else {
          this.customWorld.hideGhost();
          this.powerExecutor.update(dt, this._getActiveFighters(), ctx);
        }
        this.sound.updateAmbience(dt, 99);
      }
    } else if (this.zone === 'br') {
      const fighters = this._getActiveFighters();
      this.brWorld.update(this.time, dt);
      if (!this.hud.isModalOpen) {
        this.powerExecutor.update(dt, fighters, ctx);
        this.sound.updateAmbience(dt, 99);
      }
      // Render Live BR Minimap & Full Tactical Map (~15Hz)
      this._minimapTimer -= dt;
      if (this._minimapTimer <= 0) {
        this._minimapTimer = 0.065;
        const remotes = [...this.remotePlayers.values()];
        this.brWorld.renderMapCanvas(this.hud.brMinimapCanvas, this.player.position, this.player.yaw, remotes, false);
        if (this.brFullMapOpen) {
          this.brWorld.renderMapCanvas(this.hud.brFullMapCanvas, this.player.position, this.player.yaw, remotes, true);
        }
      }
    } else {
      const fighters = this._getActiveFighters();
      this.arena.update(this.time, dt);
      if (!this.hud.isModalOpen) {
        if (this.botsEnabled && (this.zone === 'arena' || this.zone === 'combo')) {
          this.botManager.update(dt, this.time, fighters, this.arena, this.powerExecutor, ctx);
        }
        this.powerExecutor.update(dt, fighters, ctx);
        this.sound.updateAmbience(dt, 99);
      }
    }

    this.vfx.update(dt);
    this._updateCamera(dt);
    this.hud.updatePlayerHud(this.player);

    this._lbTimer -= dt;
    if (this._lbTimer <= 0) {
      this._lbTimer = 0.4;
      const lbList = [this.player, ...this.remotePlayers.values()];
      if (this.botsEnabled) lbList.push(...this.botManager.bots);
      this.hud.updateLeaderboard(lbList);
    }

    this.renderer.render(this.scene, this.camera);
  }
}
