import * as THREE from 'three';
import { POWERS, POWER_MAP } from '../powers/PowersData.js';
import {
  createPowerModel,
  createFloatingLabel,
  createPortalMesh,
  createPineTree,
  createSakuraTree,
  createRock,
  createCrystal,
} from '../models/LowPolyModels.js';

export const SKY_PRESETS = {
  day:     { name: 'Jour Émeraude',     bg: 0xcbe5f8, fog: 0xd0e7f8, sun: 0xfff6dc, sunInt: 1.9, hemiTop: 0xd9f2ff, hemiBot: 0x3b6e2e },
  sunset:  { name: 'Coucher de Soleil', bg: 0xf4b68c, fog: 0xf2ba94, sun: 0xffc178, sunInt: 1.85, hemiTop: 0xffd7b0, hemiBot: 0x52312a },
  night:   { name: 'Nuit Étoilée',      bg: 0x0d162e, fog: 0x101c38, sun: 0x8eb8ff, sunInt: 0.95, hemiTop: 0x354f85, hemiBot: 0x101726 },
  cyber:   { name: 'Néon Cyber',        bg: 0x140b29, fog: 0x1d0f3d, sun: 0xff4da6, sunInt: 1.35, hemiTop: 0x29f0ff, hemiBot: 0x2a0f45 },
  volcano: { name: 'Volcan Infernal',   bg: 0x2b110d, fog: 0x3d1710, sun: 0xff7033, sunInt: 1.65, hemiTop: 0xff8c42, hemiBot: 0x290c08 },
  snow:    { name: 'Neige Polaire',     bg: 0xdceeff, fog: 0xe3f1ff, sun: 0xffffff, sunInt: 1.8, hemiTop: 0xffffff, hemiBot: 0x88adc9 },
};

export const GROUND_STYLES = {
  grass: { name: 'Prairie Verte',  color: 0x529b39 },
  wood:  { name: 'Bois Dojo',      color: 0x542e18 },
  stone: { name: 'Pierre Temple',  color: 0x6c7a8c },
  sand:  { name: 'Désert Doré',    color: 0xd9b86c },
  snow:  { name: 'Neige Glacée',   color: 0xe4f2ff },
  cyber: { name: 'Grille Cyber',   color: 0x1a2238 },
  void:  { name: 'Vide Spatial',   color: 0x000000 },
};

export const STUDIO_ITEMS = [
  { type: 'block',    name: 'Bloc / Mur',     icon: '🧱', solid: true,  defaultScale: [3, 3, 3],     defaultColor: '#4c7ef3' },
  { type: 'platform', name: 'Plateforme',     icon: '🟫', solid: true,  defaultScale: [6, 0.8, 6],   defaultColor: '#5cb85c' },
  { type: 'pillar',   name: 'Pilier',         icon: '🏛️', solid: true,  defaultScale: [1.6, 6, 1.6], defaultColor: '#8d99ae' },
  { type: 'ramp',     name: 'Rampe',          icon: '📐', solid: true,  defaultScale: [4, 2.5, 5],   defaultColor: '#c98a4b' },
  { type: 'sign',     name: 'Panneau Texte',  icon: '🪧', solid: false, defaultScale: [1, 1, 1],     defaultColor: '#ffd43b', defaultTitle: 'BIENVENUE', defaultText: 'Écris ton message ici !' },
  { type: 'text3d',   name: 'Texte Flottant', icon: '💬', solid: false, defaultScale: [1.2, 1.2, 1.2], defaultColor: '#38d9ff', defaultTitle: 'MON MONDE', defaultText: 'Créé avec kyotoGame Studio' },
  { type: 'jumppad',  name: 'Tremplin',       icon: '🟢', solid: false, defaultScale: [1, 1, 1],     defaultColor: '#45f2c2' },
  { type: 'lava',     name: 'Zone Lave',      icon: '🌋', solid: false, defaultScale: [5, 0.5, 5],   defaultColor: '#ff4221' },
  { type: 'pedestal', name: 'Piédestal',      icon: '⚡', solid: true,  defaultScale: [1, 1, 1],     defaultColor: '#38d9ff', defaultPowerId: 'thunder' },
  { type: 'lantern',  name: 'Lanterne',       icon: '🏮', solid: false, defaultScale: [1, 1, 1],     defaultColor: '#ffd43b' },
  { type: 'pine',     name: 'Arbre Sapin',    icon: '🌲', solid: false, defaultScale: [1, 1, 1],     defaultColor: '#226b3d' },
  { type: 'sakura',   name: 'Cerisier',       icon: '🌸', solid: false, defaultScale: [1, 1, 1],     defaultColor: '#ff99c8' },
  { type: 'rock',     name: 'Rocher',         icon: '🪨', solid: true,  defaultScale: [2, 1.4, 2],   defaultColor: '#5b6578' },
  { type: 'crystal',  name: 'Cristal',        icon: '💎', solid: false, defaultScale: [1.3, 1.3, 1.3], defaultColor: '#5cf2ff' },
  { type: 'spawn',    name: 'Point Spawn',    icon: '🚩', solid: false, defaultScale: [1, 1, 1],     defaultColor: '#3be384' },
  { type: 'portal',   name: 'Portail Dojo',   icon: '🌀', solid: false, defaultScale: [1, 1, 1],     defaultColor: '#ffd43b' },
];

export const STUDIO_ITEM_MAP = Object.fromEntries(STUDIO_ITEMS.map((i) => [i.type, i]));

export function createTemplateWorld(templateId = 'parkour') {
  const baseId = `world-${Date.now().toString(36)}`;
  if (templateId === 'blank') {
    return {
      id: baseId,
      name: 'Mon Monde Vierge',
      welcomeText: 'Construis tout ce que tu imagines !',
      skyPreset: 'day',
      groundStyle: 'grass',
      groundSize: 80,
      combatMode: 'combo',
      gravity: 30,
      objects: [
        { id: 'obj-spawn', type: 'spawn', pos: [0, 0, 14], rotY: 0, scale: [1, 1, 1], color: '#3be384' },
        { id: 'obj-sign', type: 'sign', pos: [0, 0, 7], rotY: 0, scale: [1, 1, 1], color: '#ffd43b', title: 'MON MONDE', text: 'Clique sur moi en Éditeur pour changer ce texte !' },
        { id: 'obj-portal', type: 'portal', pos: [0, 0, 26], rotY: Math.PI, scale: [1, 1, 1], color: '#ffd43b' },
      ],
    };
  }

  if (templateId === 'tournament') {
    return {
      id: baseId,
      name: 'Arène du Tournoi',
      welcomeText: 'Combat en Mode Combo • Choisis ton pouvoir !',
      skyPreset: 'sunset',
      groundStyle: 'stone',
      groundSize: 64,
      combatMode: 'combo',
      gravity: 30,
      objects: [
        { id: 't-1', type: 'spawn', pos: [0, 0, 18], rotY: 0, scale: [1, 1, 1], color: '#3be384' },
        { id: 't-2', type: 'text3d', pos: [0, 7.5, -14], rotY: 0, scale: [1.5, 1.5, 1.5], color: '#ffd43b', title: 'ARÈNE DU TOURNOI', text: 'Que le meilleur combo gagne !' },
        { id: 't-3', type: 'pillar', pos: [-14, 0, -14], rotY: 0, scale: [2.2, 8, 2.2], color: '#7b8799' },
        { id: 't-4', type: 'pillar', pos: [14, 0, -14], rotY: 0, scale: [2.2, 8, 2.2], color: '#7b8799' },
        { id: 't-5', type: 'pillar', pos: [-14, 0, 14], rotY: 0, scale: [2.2, 8, 2.2], color: '#7b8799' },
        { id: 't-6', type: 'pillar', pos: [14, 0, 14], rotY: 0, scale: [2.2, 8, 2.2], color: '#7b8799' },
        { id: 't-7', type: 'pedestal', pos: [-10, 0, 0], rotY: 0, scale: [1, 1, 1], color: '#38d9ff', powerId: 'thunder' },
        { id: 't-8', type: 'pedestal', pos: [10, 0, 0], rotY: 0, scale: [1, 1, 1], color: '#ff9214', powerId: 'dragon' },
        { id: 't-9', type: 'jumppad', pos: [0, 0, -8], rotY: 0, scale: [1, 1, 1], color: '#45f2c2' },
        { id: 't-10', type: 'lantern', pos: [-14, 8, -14], rotY: 0, scale: [1, 1, 1], color: '#ffd43b' },
        { id: 't-11', type: 'lantern', pos: [14, 8, -14], rotY: 0, scale: [1, 1, 1], color: '#ffd43b' },
        { id: 't-12', type: 'portal', pos: [0, 0, 26], rotY: Math.PI, scale: [1, 1, 1], color: '#ffd43b' },
      ],
    };
  }

  // Default parkour & arena sandbox template
  return {
    id: baseId,
    name: 'Mon Univers Kyoto',
    welcomeText: 'Bienvenue dans mon monde personnalisé ! [TAB] pour éditer',
    skyPreset: 'day',
    groundStyle: 'grass',
    groundSize: 84,
    combatMode: 'combo',
    gravity: 30,
    objects: [
      { id: 'p-spawn', type: 'spawn', pos: [0, 0, 16], rotY: 0, scale: [1, 1, 1], color: '#3be384' },
      { id: 'p-title', type: 'text3d', pos: [0, 8.5, -10], rotY: 0, scale: [1.5, 1.5, 1.5], color: '#38d9ff', title: 'MON UNIVERS KYOTO', text: 'Appuie sur TAB pour modifier tout ce monde !' },
      { id: 'p-sign', type: 'sign', pos: [-5, 0, 10], rotY: 0.4, scale: [1, 1, 1], color: '#ffd43b', title: 'ASTUCE STUDIO', text: 'Clic G: Poser / Sélectionner • R: Tourner • Suppr: Effacer' },
      { id: 'p-plat1', type: 'platform', pos: [0, 3.5, -4], rotY: 0, scale: [8, 0.9, 8], color: '#4c7ef3' },
      { id: 'p-plat2', type: 'platform', pos: [10, 7.2, -10], rotY: 0, scale: [7, 0.9, 7], color: '#9b5de5' },
      { id: 'p-plat3', type: 'platform', pos: [-10, 7.2, -10], rotY: 0, scale: [7, 0.9, 7], color: '#ff7b00' },
      { id: 'p-jp1', type: 'jumppad', pos: [0, 0, 4], rotY: 0, scale: [1, 1, 1], color: '#45f2c2' },
      { id: 'p-jp2', type: 'jumppad', pos: [10, 7.65, -10], rotY: 0, scale: [1, 1, 1], color: '#45f2c2' },
      { id: 'p-lava', type: 'lava', pos: [0, 0, -14], rotY: 0, scale: [8, 0.4, 6], color: '#ff4221' },
      { id: 'p-ped1', type: 'pedestal', pos: [7, 0, 10], rotY: 0, scale: [1, 1, 1], color: '#ff3b9a', powerId: 'cyber' },
      { id: 'p-sak1', type: 'sakura', pos: [-16, 0, 6], rotY: 0.5, scale: [1.1, 1.1, 1.1], color: '#ff99c8' },
      { id: 'p-sak2', type: 'sakura', pos: [16, 0, 6], rotY: 1.8, scale: [1.1, 1.1, 1.1], color: '#ff99c8' },
      { id: 'p-pine1', type: 'pine', pos: [-18, 0, -14], rotY: 0, scale: [1.2, 1.2, 1.2], color: '#226b3d' },
      { id: 'p-pine2', type: 'pine', pos: [18, 0, -14], rotY: 1, scale: [1.2, 1.2, 1.2], color: '#226b3d' },
      { id: 'p-crys', type: 'crystal', pos: [0, 3.95, -4], rotY: 0, scale: [1.4, 1.4, 1.4], color: '#5cf2ff' },
      { id: 'p-portal', type: 'portal', pos: [0, 0, 28], rotY: Math.PI, scale: [1, 1, 1], color: '#ffd43b' },
    ],
  };
}

function createSignCanvasTexture(title, text, accentColor = '#ffd43b') {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 256;
  const ctx = c.getContext('2d');

  ctx.fillStyle = '#3b2112';
  ctx.fillRect(0, 0, 512, 256);
  ctx.strokeStyle = accentColor;
  ctx.lineWidth = 10;
  ctx.strokeRect(10, 10, 492, 236);

  ctx.fillStyle = accentColor;
  ctx.font = 'bold 40px Fredoka, Nunito, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText((title || 'PANNEAU').slice(0, 24), 256, 74);

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 26px Nunito, sans-serif';
  // Simple 2-line wrap
  const words = String(text || '').split(' ');
  const lines = [];
  let line = '';
  for (const w of words) {
    if ((line + ' ' + w).trim().length > 30) {
      lines.push(line.trim());
      line = w;
    } else {
      line = (line + ' ' + w).trim();
    }
  }
  if (line) lines.push(line);
  lines.slice(0, 3).forEach((l, i) => {
    ctx.fillText(l, 256, 134 + i * 38);
  });

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function flatMat(color, opts = {}) {
  return new THREE.MeshStandardMaterial({
    color,
    flatShading: true,
    roughness: opts.roughness ?? 0.65,
    metalness: opts.metalness ?? 0.1,
    emissive: opts.emissive ?? 0x000000,
    emissiveIntensity: opts.emissiveIntensity ?? 0,
    transparent: opts.transparent ?? false,
    opacity: opts.opacity ?? 1,
    side: opts.side ?? THREE.FrontSide,
  });
}

/**
 * Interactive 3D world builder and runtime for custom maps.
 */
export class CustomWorld {
  constructor() {
    this.group = new THREE.Group();
    this.objectsGroup = new THREE.Group();
    this.group.add(this.objectsGroup);

    this.data = createTemplateWorld('parkour');
    this.instances = new Map(); // objId -> { spec, mesh, box }
    this.selectedId = null;

    // Base ground & lights
    this.groundMesh = null;
    this.gridHelper = null;
    this.sunLight = null;
    this.hemiLight = null;
    this.selectionHelper = null;
    this.ghostMesh = null;

    this._initLights();
    this._initSelectionAndGhost();
    this.loadData(this.data);
  }

  _initLights() {
    this.hemiLight = new THREE.HemisphereLight(0xd9f2ff, 0x3b6e2e, 1.0);
    this.group.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff6dc, 1.9);
    this.sunLight.position.set(52, 76, 38);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.width = 2048;
    this.sunLight.shadow.mapSize.height = 2048;
    const d = 80;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.camera.far = 220;
    this.group.add(this.sunLight);
  }

  _initSelectionAndGhost() {
    this.selectionHelper = new THREE.Box3Helper(new THREE.Box3(), 0xffd43b);
    this.selectionHelper.visible = false;
    this.group.add(this.selectionHelper);
  }

  setEditorVisuals(isEditor) {
    if (this.gridHelper) this.gridHelper.visible = isEditor;
    if (this.ghostMesh) this.ghostMesh.visible = isEditor;
    if (!isEditor && this.selectionHelper) this.selectionHelper.visible = false;
    else this._refreshSelectionHelper();
  }

  setShadowsEnabled(enabled) {
    if (this.sunLight) this.sunLight.castShadow = enabled;
  }

  getSkyConfig() {
    return SKY_PRESETS[this.data.skyPreset] || SKY_PRESETS.day;
  }

  _rebuildGround() {
    if (this.groundMesh) {
      this.group.remove(this.groundMesh);
      this.groundMesh = null;
    }
    if (this.gridHelper) {
      this.group.remove(this.gridHelper);
      this.gridHelper = null;
    }

    const size = Math.max(24, Math.min(180, Number(this.data.groundSize) || 80));
    const style = GROUND_STYLES[this.data.groundStyle] || GROUND_STYLES.grass;

    if (this.data.groundStyle !== 'void') {
      const g = new THREE.Group();
      const top = new THREE.Mesh(
        new THREE.BoxGeometry(size, 2.0, size),
        flatMat(style.color, { roughness: 0.88 })
      );
      top.position.y = -1.0;
      top.receiveShadow = true;
      top.userData.isStudioGround = true;
      g.add(top);

      // Stylized floating island rocky underside
      const under = new THREE.Mesh(
        new THREE.ConeGeometry(size * 0.68, 22, 8),
        flatMat(0x4a5363, { roughness: 0.95 })
      );
      under.rotation.x = Math.PI;
      under.rotation.y = Math.PI / 4;
      under.position.y = -13.0;
      g.add(under);

      this.groundMesh = g;
      this.group.add(g);
    }

    // Subtle build grid shown in Editor mode
    const grid = new THREE.GridHelper(size, Math.floor(size / 2), 0xffd43b, 0x3b5985);
    grid.position.y = 0.03;
    grid.material.opacity = 0.32;
    grid.material.transparent = true;
    this.gridHelper = grid;
    this.group.add(grid);

    // Apply sky lighting
    const sky = this.getSkyConfig();
    this.sunLight.color.setHex(sky.sun);
    this.sunLight.intensity = sky.sunInt;
    this.hemiLight.color.setHex(sky.hemiTop);
    this.hemiLight.groundColor.setHex(sky.hemiBot);
  }

  _buildObjectMesh(spec) {
    const colHex = new THREE.Color(spec.color || '#4c7ef3').getHex();
    const g = new THREE.Group();
    const sx = spec.scale?.[0] ?? 1;
    const sy = spec.scale?.[1] ?? 1;
    const sz = spec.scale?.[2] ?? 1;

    switch (spec.type) {
      case 'block': {
        const m = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), flatMat(colHex));
        m.position.y = sy / 2;
        m.castShadow = true;
        m.receiveShadow = true;
        g.add(m);
        break;
      }
      case 'platform': {
        const m = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), flatMat(colHex));
        m.position.y = sy / 2;
        m.castShadow = true;
        m.receiveShadow = true;
        g.add(m);
        const trim = new THREE.Mesh(new THREE.BoxGeometry(sx + 0.12, 0.14, sz + 0.12), flatMat(0x233044));
        trim.position.y = 0.08;
        g.add(trim);
        break;
      }
      case 'pillar': {
        const shaft = new THREE.Mesh(new THREE.CylinderGeometry(sx * 0.45, sx * 0.5, sy, 8), flatMat(colHex));
        shaft.position.y = sy / 2;
        shaft.castShadow = true;
        shaft.receiveShadow = true;
        g.add(shaft);
        const cap = new THREE.Mesh(new THREE.BoxGeometry(sx * 1.15, 0.35, sz * 1.15), flatMat(0x3a4659));
        cap.position.y = sy - 0.15;
        g.add(cap);
        const base = cap.clone();
        base.position.y = 0.18;
        g.add(base);
        break;
      }
      case 'ramp': {
        // Stepped low-poly cartoon staircase / ramp
        const steps = 6;
        const mat = flatMat(colHex);
        for (let i = 0; i < steps; i++) {
          const sh = ((i + 1) / steps) * sy;
          const sd = sz / steps;
          const st = new THREE.Mesh(new THREE.BoxGeometry(sx, sh, sd + 0.04), mat);
          st.position.set(0, sh / 2, -sz / 2 + sd * (i + 0.5));
          st.castShadow = true;
          st.receiveShadow = true;
          g.add(st);
        }
        break;
      }
      case 'sign': {
        const postMat = flatMat(0x5c361e);
        const post = new THREE.Mesh(new THREE.BoxGeometry(0.24, 2.2, 0.24), postMat);
        post.position.y = 1.1;
        post.castShadow = true;
        g.add(post);

        const tex = createSignCanvasTexture(spec.title, spec.text, spec.color || '#ffd43b');
        const faceMat = new THREE.MeshBasicMaterial({ map: tex });
        const woodMat = flatMat(0x472515);
        const board = new THREE.Mesh(
          new THREE.BoxGeometry(3.6, 1.8, 0.18),
          [woodMat, woodMat, woodMat, woodMat, faceMat, faceMat]
        );
        board.position.y = 2.45;
        board.castShadow = true;
        g.add(board);
        g.scale.set(sx, sy, sz);
        break;
      }
      case 'text3d': {
        const label = createFloatingLabel(spec.title || 'TEXTE', spec.text || '', spec.color || '#38d9ff', 520, 128);
        label.position.y = 1.0;
        label.scale.set(4.8 * sx, 1.2 * sy, 1);
        g.add(label);
        break;
      }
      case 'jumppad': {
        const base = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.5, 0.4, 8), flatMat(0x22334d));
        base.position.y = 0.2;
        g.add(base);
        const glow = new THREE.Mesh(new THREE.CylinderGeometry(1.75, 1.75, 0.48, 8), flatMat(colHex, { emissive: colHex, emissiveIntensity: 1.2 }));
        glow.position.y = 0.24;
        g.add(glow);
        const ring = new THREE.Mesh(new THREE.TorusGeometry(1.6, 0.09, 5, 14), new THREE.MeshBasicMaterial({ color: colHex }));
        ring.rotation.x = Math.PI / 2;
        ring.position.y = 0.9;
        g.add(ring);
        g.userData.floatRing = ring;
        g.scale.set(sx, sy, sz);
        break;
      }
      case 'lava': {
        const m = new THREE.Mesh(
          new THREE.BoxGeometry(sx, sy, sz),
          flatMat(colHex, { emissive: colHex, emissiveIntensity: 1.35 })
        );
        m.position.y = sy / 2;
        g.add(m);
        break;
      }
      case 'pedestal': {
        const power = POWER_MAP[spec.powerId] || POWERS[0];
        const base = new THREE.Mesh(new THREE.BoxGeometry(2.6, 1.15, 2.6), flatMat(0x263854));
        base.position.y = 0.575;
        base.castShadow = true;
        base.receiveShadow = true;
        g.add(base);
        const pad = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 1.05, 0.14, 8), flatMat(power.hex, { emissive: power.hex, emissiveIntensity: 1.1 }));
        pad.position.y = 1.2;
        g.add(pad);
        const model = createPowerModel(power.id);
        model.position.y = 2.3;
        model.scale.setScalar(1.2);
        g.add(model);
        const lbl = createFloatingLabel(power.name, power.title, power.color, 320, 94);
        lbl.position.y = 4.0;
        g.add(lbl);
        g.userData.powerModel = model;
        g.userData.power = power;
        break;
      }
      case 'lantern': {
        const post = new THREE.Mesh(new THREE.BoxGeometry(0.24, 3.2, 0.24), flatMat(0x2a180d));
        post.position.y = 1.6;
        g.add(post);
        const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.95, 0.85), flatMat(colHex, { emissive: colHex, emissiveIntensity: 1.5 }));
        lamp.position.y = 3.5;
        g.add(lamp);
        const pt = new THREE.PointLight(colHex, 16, 22, 1.4);
        pt.position.y = 3.5;
        g.add(pt);
        g.scale.set(sx, sy, sz);
        break;
      }
      case 'pine': {
        g.add(createPineTree(1));
        g.scale.set(sx, sy, sz);
        break;
      }
      case 'sakura': {
        g.add(createSakuraTree(1));
        g.scale.set(sx, sy, sz);
        break;
      }
      case 'rock': {
        const r = createRock(1);
        r.material.color.setHex(colHex);
        r.position.y = 0.55;
        g.add(r);
        g.scale.set(sx, sy, sz);
        break;
      }
      case 'crystal': {
        g.add(createCrystal(1, colHex));
        g.scale.set(sx, sy, sz);
        break;
      }
      case 'spawn': {
        const pad = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.8, 0.24, 8), flatMat(colHex, { emissive: colHex, emissiveIntensity: 0.9 }));
        pad.position.y = 0.12;
        g.add(pad);
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 3.2, 6), flatMat(0xffffff));
        pole.position.set(1.1, 1.6, 0);
        g.add(pole);
        const flag = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.7, 0.08), flatMat(colHex, { emissive: colHex, emissiveIntensity: 0.8 }));
        flag.position.set(1.7, 2.8, 0);
        g.add(flag);
        const lbl = createFloatingLabel('SPAWN', 'Point d’apparition', '#3be384', 240, 74);
        lbl.position.y = 3.6;
        g.add(lbl);
        break;
      }
      case 'portal': {
        const pm = createPortalMesh(colHex, 0xffffff, 'RETOUR AU DOJO', 'Quitter le monde perso');
        g.add(pm);
        g.userData.portalMesh = pm;
        break;
      }
    }

    g.position.set(spec.pos[0], spec.pos[1], spec.pos[2]);
    g.rotation.y = spec.rotY || 0;
    g.traverse((o) => {
      o.userData.studioObjectId = spec.id;
    });
    g.userData.studioObjectId = spec.id;
    return g;
  }

  loadData(rawData) {
    this.data = JSON.parse(JSON.stringify(rawData));
    this.selectedId = null;

    while (this.objectsGroup.children.length > 0) {
      this.objectsGroup.remove(this.objectsGroup.children[0]);
    }
    this.instances.clear();

    this._rebuildGround();

    for (const spec of this.data.objects || []) {
      this._mountObject(spec);
    }
    this._refreshSelectionHelper();
  }

  _mountObject(spec) {
    const mesh = this._buildObjectMesh(spec);
    this.objectsGroup.add(mesh);
    mesh.updateMatrixWorld(true);
    const box = new THREE.Box3().setFromObject(mesh);
    this.instances.set(spec.id, { spec, mesh, box });
  }

  addObject(spec) {
    const clean = {
      id: spec.id || `obj-${Date.now().toString(36)}-${Math.floor(Math.random() * 999)}`,
      type: spec.type,
      pos: [Number(spec.pos[0].toFixed(2)), Number(spec.pos[1].toFixed(2)), Number(spec.pos[2].toFixed(2))],
      rotY: Number((spec.rotY || 0).toFixed(3)),
      scale: spec.scale ? spec.scale.map((n) => Number(n.toFixed(2))) : [1, 1, 1],
      color: spec.color || STUDIO_ITEM_MAP[spec.type]?.defaultColor || '#4c7ef3',
      title: spec.title ?? STUDIO_ITEM_MAP[spec.type]?.defaultTitle ?? '',
      text: spec.text ?? STUDIO_ITEM_MAP[spec.type]?.defaultText ?? '',
      powerId: spec.powerId ?? STUDIO_ITEM_MAP[spec.type]?.defaultPowerId ?? 'thunder',
    };
    this.data.objects.push(clean);
    this._mountObject(clean);
    this.selectObject(clean.id);
    return clean;
  }

  updateObject(id, patch) {
    const inst = this.instances.get(id);
    if (!inst) return null;
    Object.assign(inst.spec, patch);
    this.objectsGroup.remove(inst.mesh);
    this._mountObject(inst.spec);
    this._refreshSelectionHelper();
    return inst.spec;
  }

  removeObject(id) {
    const inst = this.instances.get(id);
    if (!inst) return false;
    this.objectsGroup.remove(inst.mesh);
    this.instances.delete(id);
    this.data.objects = this.data.objects.filter((o) => o.id !== id);
    if (this.selectedId === id) this.selectedId = null;
    this._refreshSelectionHelper();
    return true;
  }

  selectObject(id) {
    this.selectedId = id && this.instances.has(id) ? id : null;
    this._refreshSelectionHelper();
    return this.getSelectedSpec();
  }

  getSelectedSpec() {
    return this.selectedId ? this.instances.get(this.selectedId)?.spec || null : null;
  }

  _refreshSelectionHelper() {
    if (!this.selectionHelper) return;
    const inst = this.selectedId ? this.instances.get(this.selectedId) : null;
    if (inst) {
      inst.mesh.updateMatrixWorld(true);
      inst.box.setFromObject(inst.mesh);
      this.selectionHelper.box.copy(inst.box);
      this.selectionHelper.visible = true;
    } else {
      this.selectionHelper.visible = false;
    }
  }

  updateWorldSettings(patch) {
    Object.assign(this.data, patch);
    this._rebuildGround();
  }

  updateGhost(type, pos, rotY, scale, color) {
    if (this.ghostMesh && (this.ghostMesh.userData.ghostType !== type || this.ghostMesh.userData.ghostColor !== color)) {
      this.group.remove(this.ghostMesh);
      this.ghostMesh = null;
    }
    if (!this.ghostMesh) {
      const m = this._buildObjectMesh({
        id: 'ghost',
        type,
        pos: [0, 0, 0],
        rotY: 0,
        scale: STUDIO_ITEM_MAP[type]?.defaultScale || [1, 1, 1],
        color,
        title: STUDIO_ITEM_MAP[type]?.defaultTitle || 'TEXTE',
        text: STUDIO_ITEM_MAP[type]?.defaultText || '',
        powerId: 'thunder',
      });
      m.traverse((o) => {
        if (o.isMesh) {
          o.castShadow = false;
          o.receiveShadow = false;
          o.material = new THREE.MeshBasicMaterial({
            color: new THREE.Color(color || '#38d9ff'),
            transparent: true,
            opacity: 0.42,
            wireframe: false,
          });
        }
      });
      m.userData.ghostType = type;
      m.userData.ghostColor = color;
      this.ghostMesh = m;
      this.group.add(m);
    }
    this.ghostMesh.visible = true;
    this.ghostMesh.position.copy(pos);
    this.ghostMesh.rotation.y = rotY;
    const def = STUDIO_ITEM_MAP[type]?.defaultScale || [1, 1, 1];
    this.ghostMesh.scale.set(scale[0] / def[0], scale[1] / def[1], scale[2] / def[2]);
  }

  hideGhost() {
    if (this.ghostMesh) this.ghostMesh.visible = false;
  }

  /**
   * Raycast against ground + all placed objects for accurate stacking & selection
   */
  raycast(raycaster) {
    const targets = [];
    if (this.groundMesh) targets.push(this.groundMesh);
    targets.push(this.objectsGroup);
    const hits = raycaster.intersectObjects(targets, true);
    for (const h of hits) {
      if (h.object.type === 'Sprite' && !h.object.userData.studioObjectId) continue;
      return {
        point: h.point,
        normal: h.face ? h.face.normal.clone().transformDirection(h.object.matrixWorld).normalize() : new THREE.Vector3(0, 1, 0),
        objectId: h.object.userData.studioObjectId || null,
      };
    }
    return null;
  }

  getBaseGroundHeight(x, z) {
    if (this.data.groundStyle === 'void') return -45;
    const half = (Number(this.data.groundSize) || 80) / 2;
    if (Math.abs(x) > half || Math.abs(z) > half) return -45;
    return 0;
  }

  /**
   * Resolves player/fighter physics against base ground AND all solid placed blocks/platforms/ramps
   */
  getSurfaceHeightAt(x, z, currentY) {
    let bestY = this.getBaseGroundHeight(x, z);
    for (const inst of this.instances.values()) {
      const def = STUDIO_ITEM_MAP[inst.spec.type];
      if (!def || !def.solid) continue;
      const b = inst.box;
      if (x >= b.min.x - 0.45 && x <= b.max.x + 0.45 && z >= b.min.z - 0.45 && z <= b.max.z + 0.45) {
        // Allow stepping smoothly onto ramps or landing on top of platforms/blocks
        if (inst.spec.type === 'ramp') {
          const localZ = (z - b.min.z) / Math.max(0.1, b.max.z - b.min.z);
          const rampY = b.min.y + THREE.MathUtils.clamp(localZ, 0, 1) * (b.max.y - b.min.y);
          if (currentY >= rampY - 1.3) bestY = Math.max(bestY, rampY);
        } else if (currentY >= b.max.y - 1.05) {
          bestY = Math.max(bestY, b.max.y);
        }
      }
    }
    return bestY;
  }

  resolveSideCollisions(pos, radius = 0.65) {
    for (const inst of this.instances.values()) {
      const def = STUDIO_ITEM_MAP[inst.spec.type];
      if (!def || !def.solid || inst.spec.type === 'ramp') continue;
      const b = inst.box;
      // Only block horizontally if player body overlaps vertically (not standing on top)
      if (pos.y < b.max.y - 0.7 && pos.y + 2.0 > b.min.y + 0.15) {
        const cx = THREE.MathUtils.clamp(pos.x, b.min.x, b.max.x);
        const cz = THREE.MathUtils.clamp(pos.z, b.min.z, b.max.z);
        const dx = pos.x - cx;
        const dz = pos.z - cz;
        const dist = Math.hypot(dx, dz);
        if (dist < radius && dist > 0.0001) {
          pos.x = cx + (dx / dist) * radius;
          pos.z = cz + (dz / dist) * radius;
        }
      }
    }
  }

  getSpawnPoint() {
    for (const inst of this.instances.values()) {
      if (inst.spec.type === 'spawn') {
        return new THREE.Vector3(inst.spec.pos[0], inst.spec.pos[1] + 1.2, inst.spec.pos[2]);
      }
    }
    return new THREE.Vector3(0, 1.5, 14);
  }

  getInteractiveObjects() {
    const jumpPads = [];
    const lavas = [];
    const pedestals = [];
    const portals = [];
    for (const inst of this.instances.values()) {
      const p = new THREE.Vector3(...inst.spec.pos);
      if (inst.spec.type === 'jumppad') jumpPads.push({ position: p, radius: 2.3 * (inst.spec.scale?.[0] || 1) });
      else if (inst.spec.type === 'lava') lavas.push({ box: inst.box, position: p });
      else if (inst.spec.type === 'pedestal') pedestals.push({ position: p, power: inst.mesh.userData.power });
      else if (inst.spec.type === 'portal') portals.push({ position: p });
    }
    return { jumpPads, lavas, pedestals, portals };
  }

  update(t) {
    for (const inst of this.instances.values()) {
      if (inst.mesh.userData.floatRing) {
        inst.mesh.userData.floatRing.position.y = 0.8 + Math.sin(t * 4) * 0.25;
        inst.mesh.userData.floatRing.rotation.z = t * 2.2;
      }
      if (inst.mesh.userData.powerModel) {
        inst.mesh.userData.powerModel.rotation.y = t * 1.4;
        inst.mesh.userData.powerModel.position.y = 2.3 + Math.sin(t * 2.5) * 0.16;
        inst.mesh.userData.powerModel.userData.animate?.(t);
      }
      if (inst.mesh.userData.portalMesh) {
        inst.mesh.userData.portalMesh.userData.animate?.(t);
      }
    }
  }

  // --- LOCAL STORAGE WORLD SAVES ---
  static listSavedWorlds() {
    try {
      return JSON.parse(localStorage.getItem('kyoto_studio_worlds') || '[]');
    } catch {
      return [];
    }
  }

  static saveWorldToStorage(worldData) {
    const list = CustomWorld.listSavedWorlds();
    const copy = JSON.parse(JSON.stringify(worldData));
    const idx = list.findIndex((w) => w.id === copy.id);
    if (idx >= 0) list[idx] = copy;
    else list.unshift(copy);
    localStorage.setItem('kyoto_studio_worlds', JSON.stringify(list.slice(0, 20)));
    return list;
  }

  static deleteSavedWorld(id) {
    const list = CustomWorld.listSavedWorlds().filter((w) => w.id !== id);
    localStorage.setItem('kyoto_studio_worlds', JSON.stringify(list));
    return list;
  }
}
