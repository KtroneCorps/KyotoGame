import * as THREE from 'three';
import { POWERS } from '../powers/PowersData.js';
import {
  createPowerModel,
  createFloatingLabel,
  createPortalMesh,
  createSakuraTree,
} from '../models/LowPolyModels.js';

function createWoodPlankTexture() {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 512;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#472515';
  ctx.fillRect(0, 0, 512, 512);
  const rows = 8;
  const rowH = 512 / rows;
  for (let r = 0; r < rows; r++) {
    const tone = 62 + (r % 3) * 10 + Math.floor(Math.random() * 8);
    ctx.fillStyle = `rgb(${tone + 20}, ${Math.floor(tone * 0.58)}, ${Math.floor(tone * 0.34)})`;
    ctx.fillRect(0, r * rowH + 2, 512, rowH - 4);
    ctx.fillStyle = '#241108';
    ctx.fillRect(0, r * rowH, 512, 3);
    const splitX = ((r * 173 + 90) % 440) + 36;
    ctx.fillRect(splitX, r * rowH, 3, rowH);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(8, 14);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createShojiWallTexture() {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 512;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#e5dcc8';
  ctx.fillRect(0, 0, 512, 512);

  // Subtle shoji warm window lattice glow
  ctx.fillStyle = 'rgba(255, 224, 150, 0.22)';
  for (let i = 0; i < 4; i++) {
    ctx.fillRect(i * 128 + 18, 52, 92, 190);
  }

  ctx.fillStyle = '#2a160c';
  for (let i = 0; i <= 4; i++) ctx.fillRect(i * 128 - 10, 0, 20, 512);
  for (let j = 0; j <= 3; j++) ctx.fillRect(0, j * 170 - 11, 512, 22);

  ctx.fillStyle = '#331b0e';
  ctx.fillRect(0, 392, 512, 120);

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(7, 1);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Central hub dojo with 28 power pedestals, character customization mirror,
 * and portals to Classic, Combo, Battle Royale, Ranked, and Studio modes.
 */
export class DojoWorld {
  constructor() {
    this.group = new THREE.Group();
    this.pedestals = [];
    this.portalPosition = new THREE.Vector3(-12.2, 0, -40.2);
    this.comboPortalPosition = new THREE.Vector3(-6.1, 0, -41.4);
    this.brPortalPosition = new THREE.Vector3(0, 0, -42.0);
    this.rankedPortalPosition = new THREE.Vector3(6.1, 0, -41.4);
    this.studioPortalPosition = new THREE.Vector3(12.2, 0, -40.2);
    this.mirrorPosition = new THREE.Vector3(-5.8, 0, 31.0);
    this.portalMesh = null;
    this.comboPortalMesh = null;
    this.brPortalMesh = null;
    this.rankedPortalMesh = null;
    this.studioPortalMesh = null;
    this.mirrorMesh = null;
    this.dustPoints = null;
    this.petalPoints = null;
    this.bounds = { minX: -19.5, maxX: 19.5, minZ: -43.5, maxZ: 38.5 };
    this.pillars = [];

    this._buildArchitecture();
    this._buildLanterns();
    this._buildPedestals();
    this._buildCustomizationMirror();
    this._buildPortalAndTorii();
    this._buildDecorations();
    this._buildParticles();
  }

  _buildArchitecture() {
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x3f2213, roughness: 0.82, flatShading: true });
    const darkBeamMat = new THREE.MeshStandardMaterial({ color: 0x241209, roughness: 0.9, flatShading: true });
    const goldMat = new THREE.MeshStandardMaterial({ color: 0xe6b635, metalness: 0.45, roughness: 0.35 });

    // Grand Hardwood Floor (28 pedestals)
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(44, 92),
      new THREE.MeshStandardMaterial({ map: createWoodPlankTexture(), roughness: 0.5, metalness: 0.08 })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(0, 0, -2.5);
    floor.receiveShadow = true;
    this.group.add(floor);

    // Imperial Navy & Gold Central Carpet
    const carpet = new THREE.Mesh(
      new THREE.BoxGeometry(5.6, 0.045, 76),
      new THREE.MeshStandardMaterial({ color: 0x1b3459, roughness: 0.88 })
    );
    carpet.position.set(0, 0.02, -2);
    carpet.receiveShadow = true;
    this.group.add(carpet);

    for (const sx of [-2.85, 2.85]) {
      const trim = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.05, 76), goldMat);
      trim.position.set(sx, 0.025, -2);
      this.group.add(trim);
    }

    // Crimson side runners along the 28 pedestals
    const redMat = new THREE.MeshStandardMaterial({ color: 0x7c1d28, roughness: 0.88 });
    for (const sx of [-12.5, 12.5]) {
      const sideRun = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.035, 72), redMat);
      sideRun.position.set(sx, 0.018, -2);
      sideRun.receiveShadow = true;
      this.group.add(sideRun);
    }

    // Shoji Half-Timbered Walls
    const shojiTex = createShojiWallTexture();
    const wallMat = new THREE.MeshStandardMaterial({ map: shojiTex, roughness: 0.85 });

    const leftWall = new THREE.Mesh(new THREE.PlaneGeometry(92, 13.5), wallMat);
    leftWall.position.set(-21.5, 6.75, -2.5);
    leftWall.rotation.y = Math.PI / 2;
    leftWall.receiveShadow = true;
    this.group.add(leftWall);

    const rightWall = new THREE.Mesh(new THREE.PlaneGeometry(92, 13.5), wallMat);
    rightWall.position.set(21.5, 6.75, -2.5);
    rightWall.rotation.y = -Math.PI / 2;
    rightWall.receiveShadow = true;
    this.group.add(rightWall);

    const endTex = createShojiWallTexture();
    endTex.repeat.set(4.5, 1);
    const endMat = new THREE.MeshStandardMaterial({ map: endTex, roughness: 0.85 });

    const backWall = new THREE.Mesh(new THREE.PlaneGeometry(43, 13.5), endMat);
    backWall.position.set(0, 6.75, -46.5);
    this.group.add(backWall);

    const frontWall = new THREE.Mesh(new THREE.PlaneGeometry(43, 13.5), endMat);
    frontWall.position.set(0, 6.75, 41.5);
    frontWall.rotation.y = Math.PI;
    this.group.add(frontWall);

    // Ceiling + Grand Cross Rafters
    const ceiling = new THREE.Mesh(new THREE.PlaneGeometry(44, 92), darkBeamMat);
    ceiling.rotation.x = Math.PI / 2;
    ceiling.position.set(0, 13.2, -2.5);
    this.group.add(ceiling);

    for (let z = -42; z <= 38; z += 8.0) {
      const beam = new THREE.Mesh(new THREE.BoxGeometry(43, 0.85, 0.85), woodMat);
      beam.position.set(0, 12.6, z);
      this.group.add(beam);
    }
    for (const x of [-8.8, 8.8]) {
      const longBeam = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.75, 88), woodMat);
      longBeam.position.set(x, 12.3, -2.5);
      this.group.add(longBeam);
    }

    // Grand Cylindrical Wooden Pillars with Gold Rings & Stone Bases
    const stoneMat = new THREE.MeshStandardMaterial({ color: 0x4b5361, flatShading: true, roughness: 0.9 });
    for (let pz = -32; pz <= 30; pz += 12.4) {
      for (const px of [-8.8, 8.8]) {
        const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.66, 0.74, 12.8, 10), woodMat);
        pillar.position.set(px, 6.4, pz);
        pillar.castShadow = true;
        pillar.receiveShadow = true;
        this.group.add(pillar);

        const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.76, 0.76, 0.25, 10), goldMat);
        collar.position.set(px, 2.2, pz);
        this.group.add(collar);

        const base = new THREE.Mesh(new THREE.CylinderGeometry(0.92, 1.05, 0.72, 8), stoneMat);
        base.position.set(px, 0.36, pz);
        this.group.add(base);

        this.pillars.push({ x: px, z: pz, r: 1.0 });
      }
    }

    // Warm Inviting Dojo Illumination
    this.group.add(new THREE.AmbientLight(0xffe5c4, 0.82));
    this.group.add(new THREE.HemisphereLight(0xffebc7, 0x472a18, 0.65));
  }

  _buildLanterns() {
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x1d110a, flatShading: true });
    const paperMat = new THREE.MeshStandardMaterial({
      color: 0xfff5d6,
      emissive: 0xffcf70,
      emissiveIntensity: 1.6,
      roughness: 0.35,
    });
    const tasselMat = new THREE.MeshStandardMaterial({ color: 0xd93838, flatShading: true });

    let idx = 0;
    for (let lz = -26; lz <= 22; lz += 8) {
      for (const lx of [-6.0, 6.0]) {
        const lantern = new THREE.Group();
        lantern.position.set(lx, 10.2, lz);

        const rod = new THREE.Mesh(new THREE.BoxGeometry(0.1, 2.6, 0.1), frameMat);
        rod.position.y = 1.6;
        lantern.add(rod);

        lantern.add(new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.22, 1.25), frameMat)).position.set(0, 0.58, 0);
        const capTop = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.22, 1.25), frameMat);
        capTop.position.y = 0.58;
        lantern.add(capTop);

        const capBot = new THREE.Mesh(new THREE.BoxGeometry(1.12, 0.18, 1.12), frameMat);
        capBot.position.y = -0.58;
        lantern.add(capBot);

        const core = new THREE.Mesh(new THREE.BoxGeometry(0.96, 1.04, 0.96), paperMat);
        lantern.add(core);

        const tassel = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.55, 5), tasselMat);
        tassel.position.y = -0.92;
        lantern.add(tassel);

        if (idx % 3 === 0) {
          const pt = new THREE.PointLight(0xffcf82, 24, 28, 1.4);
          pt.position.set(0, -0.5, 0);
          lantern.add(pt);
        }

        this.group.add(lantern);
        idx++;
      }
    }
  }

  _buildPedestals() {
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x1d283a, flatShading: true, roughness: 0.7 });
    const trimMat = new THREE.MeshStandardMaterial({ color: 0x2f4361, flatShading: true, roughness: 0.5 });
    const goldMat = new THREE.MeshStandardMaterial({ color: 0xf5c842, metalness: 0.55, roughness: 0.3 });

    // 14 powers on Left Gallery (x = -16.8), 14 powers on Right Gallery (x = 16.8) -> 28 powers
    const half = Math.ceil(POWERS.length / 2);
    POWERS.forEach((power, index) => {
      const isLeft = index < half;
      const rowIdx = isLeft ? index : index - half;
      const px = isLeft ? -16.8 : 16.8;
      const pz = 31.5 - rowIdx * 4.85;

      const pedGroup = new THREE.Group();
      pedGroup.position.set(px, 0, pz);

      const step1 = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.36, 3.2), baseMat);
      step1.position.y = 0.18;
      step1.receiveShadow = true;
      step1.castShadow = true;
      pedGroup.add(step1);

      const step2 = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.08, 2.4), trimMat);
      step2.position.y = 0.88;
      step2.receiveShadow = true;
      step2.castShadow = true;
      pedGroup.add(step2);

      const goldRim = new THREE.Mesh(new THREE.BoxGeometry(2.55, 0.1, 2.55), goldMat);
      goldRim.position.y = 1.42;
      pedGroup.add(goldRim);

      const pad = new THREE.Mesh(
        new THREE.CylinderGeometry(1.0, 1.1, 0.14, 8),
        new THREE.MeshStandardMaterial({ color: power.hex, emissive: power.hex, emissiveIntensity: 1.1 })
      );
      pad.position.y = 1.49;
      pedGroup.add(pad);

      // Detailed animated 3D Weapon / Tool floating above pedestal
      const model = createPowerModel(power.id);
      model.position.y = 2.65;
      model.scale.setScalar(1.3);
      pedGroup.add(model);

      const label = createFloatingLabel(power.name, power.title, power.color, 340, 100);
      label.position.y = 4.45;
      pedGroup.add(label);

      const selectRing = new THREE.Mesh(
        new THREE.RingGeometry(1.55, 1.9, 20),
        new THREE.MeshBasicMaterial({ color: power.hex, side: THREE.DoubleSide, transparent: true, opacity: 0.25 })
      );
      selectRing.rotation.x = -Math.PI / 2;
      selectRing.position.y = 0.05;
      pedGroup.add(selectRing);

      this.group.add(pedGroup);
      this.pedestals.push({
        power,
        position: new THREE.Vector3(px, 0, pz),
        model,
        selectRing,
      });
    });

    // Grand Welcome Banner behind spawn
    const welcome = createFloatingLabel('GRAND DOJO DES 28 POUVOIRS', 'Choisis ton pouvoir, customise ton héros (C) et traverse un Portail !', '#ffd43b', 680, 114);
    welcome.position.set(0, 5.4, 38.5);
    welcome.scale.set(6.5, 1.15, 1);
    this.group.add(welcome);
  }

  _buildCustomizationMirror() {
    const g = new THREE.Group();
    g.position.copy(this.mirrorPosition);
    g.rotation.y = 0.48;

    const frameMat = new THREE.MeshStandardMaterial({ color: 0xe6b842, metalness: 0.55, roughness: 0.28, flatShading: true });
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x1e2c42, flatShading: true });
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x74e8ff,
      emissive: 0x38b6ff,
      emissiveIntensity: 0.85,
      metalness: 0.4,
      roughness: 0.1,
    });

    const base = new THREE.Mesh(new THREE.CylinderGeometry(1.7, 2.0, 0.4, 8), baseMat);
    base.position.y = 0.2;
    g.add(base);

    const glass = new THREE.Mesh(new THREE.BoxGeometry(2.1, 3.2, 0.12), glassMat);
    glass.position.y = 2.15;
    g.add(glass);

    // Ornate golden mirror border
    const leftF = new THREE.Mesh(new THREE.BoxGeometry(0.22, 3.5, 0.24), frameMat);
    leftF.position.set(-1.12, 2.15, 0);
    g.add(leftF);
    const rightF = leftF.clone();
    rightF.position.x = 1.12;
    g.add(rightF);
    const topF = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.26, 0.26), frameMat);
    topF.position.set(0, 3.82, 0);
    g.add(topF);

    const crown = new THREE.Mesh(new THREE.OctahedronGeometry(0.32, 0), frameMat);
    crown.position.set(0, 4.35, 0);
    g.add(crown);

    const label = createFloatingLabel('VESTIAIRE DU HÉROS', 'Appuie sur [E] ou [C] pour modifier ton perso', '#ffd43b', 460, 108);
    label.position.set(0, 5.4, 0);
    g.add(label);

    const light = new THREE.PointLight(0x74e8ff, 12, 12, 1.5);
    light.position.set(0, 2.3, 1.0);
    g.add(light);

    g.userData.crown = crown;
    this.mirrorMesh = g;
    this.group.add(g);
  }

  _buildPortalAndTorii() {
    // Grand Wide Crimson Torii Archway framing the Portals
    const torii = new THREE.Group();
    torii.position.set(0, 0, -36.5);
    const redMat = new THREE.MeshStandardMaterial({ color: 0xc92a2a, flatShading: true, roughness: 0.65 });
    const blackMat = new THREE.MeshStandardMaterial({ color: 0x1b1d24, flatShading: true });

    for (const sx of [-10.2, 10.2]) {
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.52, 9.0, 8), redMat);
      col.position.set(sx, 4.5, 0);
      torii.add(col);
      const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.66, 0.78, 1.0, 8), blackMat);
      foot.position.set(sx, 0.5, 0);
      torii.add(foot);
    }
    const barLow = new THREE.Mesh(new THREE.BoxGeometry(22.4, 0.52, 0.52), redMat);
    barLow.position.set(0, 7.6, 0);
    torii.add(barLow);
    const barTop = new THREE.Mesh(new THREE.BoxGeometry(24.6, 0.72, 0.85), redMat);
    barTop.position.set(0, 8.9, 0);
    torii.add(barTop);
    const capTop = new THREE.Mesh(new THREE.BoxGeometry(25.4, 0.36, 1.0), blackMat);
    capTop.position.set(0, 9.35, 0);
    torii.add(capTop);
    this.group.add(torii);

    // 5 Grand Mode Portals cleanly arrayed in a semi-circle under the Torii
    this.portalMesh = createPortalMesh(0x52e5ff, 0xffffff, 'CLASSIQUE', 'Combat libre');
    this.portalMesh.position.copy(this.portalPosition);
    this.portalMesh.scale.setScalar(0.84);
    this.group.add(this.portalMesh);

    this.comboPortalMesh = createPortalMesh(0xff5a36, 0xffd43b, 'MODE COMBO', 'Sol 1.6s • Contre 1.1s');
    this.comboPortalMesh.position.copy(this.comboPortalPosition);
    this.comboPortalMesh.scale.setScalar(0.84);
    this.group.add(this.comboPortalMesh);

    this.brPortalMesh = createPortalMesh(0x38d97c, 0xffe066, 'BATTLE ROYALE', 'Avion 3D • Monde Ouvert • Armes');
    this.brPortalMesh.position.copy(this.brPortalPosition);
    this.brPortalMesh.scale.setScalar(0.95);
    this.group.add(this.brPortalMesh);

    this.rankedPortalMesh = createPortalMesh(0xffd43b, 0x7b61ff, 'MODE CLASSÉ', 'Grades & Elo (Min. 2 joueurs)');
    this.rankedPortalMesh.position.copy(this.rankedPortalPosition);
    this.rankedPortalMesh.scale.setScalar(0.84);
    this.group.add(this.rankedPortalMesh);

    this.studioPortalMesh = createPortalMesh(0xb15cff, 0xffd43b, 'STUDIO 3D', 'Crée & modifie ton monde');
    this.studioPortalMesh.position.copy(this.studioPortalPosition);
    this.studioPortalMesh.scale.setScalar(0.84);
    this.group.add(this.studioPortalMesh);
  }

  _buildDecorations() {
    // Potted indoor Sakura Bonsai trees near the Torii gate and corners
    const potMat = new THREE.MeshStandardMaterial({ color: 0x2b3648, flatShading: true });
    const spots = [
      [-13.5, -41.5], [13.5, -41.5],
      [-11.5, 34], [11.5, 34],
    ];
    for (const [x, z] of spots) {
      const pot = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.0, 1.1, 8), potMat);
      pot.position.set(x, 0.55, z);
      this.group.add(pot);

      const bonsai = createSakuraTree(0.75);
      bonsai.position.set(x, 1.0, z);
      this.group.add(bonsai);
    }
  }

  _buildParticles() {
    // Golden lantern dust motes
    const dCount = 120;
    const dPos = new Float32Array(dCount * 3);
    for (let i = 0; i < dCount; i++) {
      dPos[i * 3] = (Math.random() - 0.5) * 38;
      dPos[i * 3 + 1] = 0.8 + Math.random() * 10.5;
      dPos[i * 3 + 2] = -32 + Math.random() * 58;
    }
    const dGeo = new THREE.BufferGeometry();
    dGeo.setAttribute('position', new THREE.BufferAttribute(dPos, 3));
    this.dustPoints = new THREE.Points(
      dGeo,
      new THREE.PointsMaterial({ color: 0xffe5a8, size: 0.16, transparent: true, opacity: 0.58 })
    );
    this.group.add(this.dustPoints);

    // Drifting pink Sakura petals
    const pCount = 85;
    const pPos = new Float32Array(pCount * 3);
    for (let i = 0; i < pCount; i++) {
      pPos[i * 3] = (Math.random() - 0.5) * 36;
      pPos[i * 3 + 1] = 1.0 + Math.random() * 10;
      pPos[i * 3 + 2] = -32 + Math.random() * 56;
    }
    const pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
    this.petalPoints = new THREE.Points(
      pGeo,
      new THREE.PointsMaterial({ color: 0xffa6d1, size: 0.22, transparent: true, opacity: 0.72 })
    );
    this.group.add(this.petalPoints);
  }

  update(t, equippedPowerId) {
    if (this.portalMesh) this.portalMesh.userData.animate(t);
    if (this.studioPortalMesh) this.studioPortalMesh.userData.animate(t);
    if (this.comboPortalMesh) this.comboPortalMesh.userData.animate(t);
    if (this.brPortalMesh) this.brPortalMesh.userData.animate(t);
    if (this.rankedPortalMesh) this.rankedPortalMesh.userData.animate(t);
    if (this.mirrorMesh?.userData.crown) {
      this.mirrorMesh.userData.crown.rotation.y = t * 2.2;
      this.mirrorMesh.userData.crown.position.y = 4.35 + Math.sin(t * 3) * 0.14;
    }

    this.pedestals.forEach((ped, idx) => {
      ped.model.rotation.y = t * 1.2 + idx * 0.45;
      ped.model.position.y = 2.65 + Math.sin(t * 2.4 + idx) * 0.18;
      if (ped.model.userData.animate) ped.model.userData.animate(t);

      const isEquipped = ped.power.id === equippedPowerId;
      ped.selectRing.material.opacity = isEquipped ? 0.9 : 0.2;
      ped.selectRing.scale.setScalar(isEquipped ? 1.1 + Math.sin(t * 5) * 0.06 : 1);
    });

    if (this.dustPoints) {
      this.dustPoints.position.y = Math.sin(t * 0.5) * 0.25;
      this.dustPoints.rotation.y = t * 0.012;
    }
    if (this.petalPoints) {
      const arr = this.petalPoints.geometry.attributes.position.array;
      for (let i = 0; i < arr.length; i += 3) {
        arr[i] += Math.sin(t + i) * 0.008;
        arr[i + 1] -= 0.014;
        if (arr[i + 1] < 0.3) arr[i + 1] = 11.2;
      }
      this.petalPoints.geometry.attributes.position.needsUpdate = true;
    }
  }

  resolveCollision(pos, radius = 0.65) {
    pos.x = Math.max(this.bounds.minX + radius, Math.min(this.bounds.maxX - radius, pos.x));
    pos.z = Math.max(this.bounds.minZ + radius, Math.min(this.bounds.maxZ - radius, pos.z));

    for (const p of this.pillars) {
      const dx = pos.x - p.x;
      const dz = pos.z - p.z;
      const dist = Math.hypot(dx, dz);
      const minDist = p.r + radius;
      if (dist < minDist && dist > 0.0001) {
        pos.x = p.x + (dx / dist) * minDist;
        pos.z = p.z + (dz / dist) * minDist;
      }
    }

    for (const ped of this.pedestals) {
      const dx = pos.x - ped.position.x;
      const dz = pos.z - ped.position.z;
      const minD = 1.65 + radius;
      if (Math.abs(dx) < minD && Math.abs(dz) < minD) {
        if (Math.abs(dx) > Math.abs(dz)) {
          pos.x = ped.position.x + Math.sign(dx) * minD;
        } else {
          pos.z = ped.position.z + Math.sign(dz) * minD;
        }
      }
    }
  }
}
