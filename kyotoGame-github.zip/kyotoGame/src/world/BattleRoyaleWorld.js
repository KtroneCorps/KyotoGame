import * as THREE from 'three';
import { POWERS } from '../powers/PowersData.js';
import { WEAPON_LIST } from '../weapons/WeaponsData.js';
import {
  createPowerModel,
  createPineTree,
  createSakuraTree,
  createRock,
  createCrystal,
  createFloatingLabel,
} from '../models/LowPolyModels.js';
import {
  createGunModel,
  createConsumableModel,
  createBattlePlaneModel,
} from '../models/WeaponModels.js';

export const BR_RADIUS = 215;

function smoothstep(e0, e1, x) {
  const t = Math.max(0, Math.min(1, (x - e0) / (e1 - e0)));
  return t * t * (3 - 2 * t);
}

function seededRand(seed) {
  let s = Math.abs(Math.floor(seed)) % 2147483647 || 1337;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

/**
 * Procedurally generated open-world island for Battle Royale mode:
 * multi-biome terrain, canyon river with bridges, drop plane, shrinking storm,
 * loot spawns, and minimap/full-map canvas rendering.
 */
export class BattleRoyaleWorld {
  constructor() {
    this.group = new THREE.Group();
    this.lootGroup = new THREE.Group();
    this.group.add(this.lootGroup);

    this.seed = 42026;
    this.phaseOffset = 0;
    this.obstacles = [];
    this.loots = new Map(); // id -> { id, kind, itemId, name, color, pos, mesh, taken }
    this.bridges = [
      { z: -42, halfZ: 2.6, halfDeckX: 8.4, rampLen: 3.0, deckY: 1.35 },
      { z: 48, halfZ: 2.6, halfDeckX: 8.4, rampLen: 3.0, deckY: 1.35 },
    ];
    this.pois = [
      { name: 'Pic Gelé', x: -35, z: -120 },
      { name: 'Dunes d’Or', x: 115, z: -15 },
      { name: 'Village Central', x: -18, z: 8 },
      { name: 'Bois Sakura', x: -105, z: 42 },
      { name: 'Pont du Canyon', x: 35, z: 48 },
    ];

    // Battle Plane state
    this.planeMesh = createBattlePlaneModel();
    this.group.add(this.planeMesh);
    this.planeStart = new THREE.Vector3(-190, 96, -165);
    this.planeEnd = new THREE.Vector3(190, 96, 165);
    this.planeProgress = 0;
    this.planeDuration = 34; // seconds to cross entire island

    // Shrinking Storm Circle state
    this.stormCenter = new THREE.Vector3(0, 0, 0);
    this.stormRadius = BR_RADIUS + 18;
    this.stormTargetRadius = 12;
    this.stormShrinkSpeed = 1.65;
    this.stormMesh = null;

    // Pre-rendered minimap bitmap
    this.mapCanvasBase = document.createElement('canvas');
    this.mapCanvasBase.width = 256;
    this.mapCanvasBase.height = 256;

    this.worldContent = new THREE.Group();
    this.group.add(this.worldContent);
    this.sunLight = null;
    this.clouds = [];

    this._initLightsAndSky();
    this._initStormWall();
    this.generate(this.seed);
  }

  _initLightsAndSky() {
    this.group.add(new THREE.HemisphereLight(0xe0f3ff, 0x3b6e2e, 1.05));
    const sun = new THREE.DirectionalLight(0xfff5dc, 1.95);
    sun.position.set(110, 145, 75);
    sun.castShadow = true;
    sun.shadow.mapSize.width = 2048;
    sun.shadow.mapSize.height = 2048;
    const d = 180;
    sun.shadow.camera.left = -d;
    sun.shadow.camera.right = d;
    sun.shadow.camera.top = d;
    sun.shadow.camera.bottom = -d;
    sun.shadow.camera.far = 400;
    this.group.add(sun);
    this.sunLight = sun;

    // Gradient sky dome
    const c = document.createElement('canvas');
    c.width = 32; c.height = 128;
    const ctx = c.getContext('2d');
    const g = ctx.createLinearGradient(0, 0, 0, 128);
    g.addColorStop(0, '#2f8ae3');
    g.addColorStop(0.55, '#8fd1ff');
    g.addColorStop(1, '#e8f7ff');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 32, 128);
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    const dome = new THREE.Mesh(
      new THREE.SphereGeometry(420, 20, 14),
      new THREE.MeshBasicMaterial({ map: tex, side: THREE.BackSide, fog: false })
    );
    this.group.add(dome);
  }

  _initStormWall() {
    const geo = new THREE.CylinderGeometry(1, 1, 140, 40, 1, true);
    const mat = new THREE.MeshBasicMaterial({
      color: 0x9b30ff,
      transparent: true,
      opacity: 0.28,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.stormMesh = new THREE.Mesh(geo, mat);
    this.stormMesh.position.y = 55;
    this.group.add(this.stormMesh);
  }

  setShadowsEnabled(enabled) {
    if (this.sunLight) this.sunLight.castShadow = enabled;
  }

  getRiverX(z) {
    return 36 + Math.sin(z * 0.022 + this.phaseOffset) * 16;
  }

  getBiome(x, z) {
    if (z < -62) return 'snow';
    if (x > 58 && z > -68) return 'desert';
    if (x < -68 && z > 10) return 'sakura';
    return 'forest';
  }

  getTerrainHeight(x, z) {
    const dist = Math.hypot(x, z);
    if (dist > BR_RADIUS) return -48;

    const p = this.phaseOffset;
    const h1 = Math.sin(x * 0.024 + p) * Math.cos(z * 0.024 - p) * 9.5;
    const h2 = Math.sin((x - z) * 0.017 + p * 1.4) * 5.8;
    const h3 = Math.cos(x * 0.055 + z * 0.048) * 1.6;

    // Dramatic Snowy Alpine Mountains in the North
    const snowBoost = smoothstep(-50, -135, z) * (12 + Math.abs(Math.sin(x * 0.04 + p)) * 12);
    // Gentle Golden Dunes in the East
    const duneBoost = smoothstep(55, 130, x) * (2.5 + Math.sin(z * 0.06 + x * 0.03) * 3.2);

    let h = Math.max(0.4, h1 + h2 + h3 + 7.2 + snowBoost + duneBoost);

    // Flatten Central Village plateau (-18, 8)
    const dVil = Math.hypot(x + 18, z - 8);
    if (dVil < 34) {
      const w = 1 - smoothstep(16, 34, dVil);
      h = THREE.MathUtils.lerp(h, 3.2, w);
    }

    // Carve flat canyon river at y = -0.9 so water at y = 0.05 is 100% flush
    const rDist = Math.abs(x - this.getRiverX(z));
    if (rDist < 20) {
      const vb = 1 - smoothstep(8, 20, rDist);
      h = THREE.MathUtils.lerp(h, 0.7, vb);
      if (rDist < 8) {
        const cb = 1 - smoothstep(4.2, 8, rDist);
        h = THREE.MathUtils.lerp(h, -0.9, cb);
      }
    }

    // Coastal beach taper near edge
    const beach = smoothstep(BR_RADIUS - 26, BR_RADIUS - 4, dist);
    h = THREE.MathUtils.lerp(h, 0.35, beach);
    const cliff = dist > BR_RADIUS - 4 ? Math.max(0, (BR_RADIUS - dist) / 4) : 1;
    return h * cliff;
  }

  getWalkableHeight(x, z, currentY = 20) {
    let h = this.getTerrainHeight(x, z);
    for (const b of this.bridges) {
      if (Math.abs(z - b.z) <= b.halfZ) {
        const bx = this.getRiverX(b.z);
        const dx = Math.abs(x - bx);
        if (dx <= b.halfDeckX) {
          if (currentY >= b.deckY - 1.2) h = Math.max(h, b.deckY);
        } else if (dx <= b.halfDeckX + b.rampLen) {
          const t = 1 - (dx - b.halfDeckX) / b.rampLen;
          const ry = 0.3 + t * (b.deckY - 0.3);
          if (currentY >= ry - 1.2) h = Math.max(h, ry);
        }
      }
    }
    return h;
  }

  generate(seed = Date.now() % 999999) {
    this.seed = Number(seed) || 42026;
    const rand = seededRand(this.seed);
    this.phaseOffset = rand() * Math.PI * 2;

    while (this.worldContent.children.length > 0) this.worldContent.remove(this.worldContent.children[0]);
    while (this.lootGroup.children.length > 0) this.lootGroup.remove(this.lootGroup.children[0]);
    this.obstacles = [];
    this.loots.clear();
    this.clouds = [];

    // Reset Plane & Storm
    const flightAngle = rand() * Math.PI * 2;
    const r = BR_RADIUS + 10;
    this.planeStart.set(Math.cos(flightAngle) * r, 94, Math.sin(flightAngle) * r);
    this.planeEnd.set(-Math.cos(flightAngle) * r, 94, -Math.sin(flightAngle) * r);
    this.planeProgress = 0.05;
    this.planeMesh.position.copy(this.planeStart);
    this.planeMesh.lookAt(this.planeEnd);
    this.planeMesh.rotateY(Math.PI); // plane faces -Z locally

    this.stormCenter.set((rand() - 0.5) * 70, 0, (rand() - 0.5) * 70);
    this.stormRadius = BR_RADIUS + 20;

    this._buildProceduralTerrain();
    this._buildRiverAndBridges();
    this._buildVillageAndLandmarks(rand);
    this._buildBiomeNature(rand);
    this._buildLootSpawns(rand);
    this._buildClouds(rand);
    this._bakeMinimapTexture();
  }

  _buildProceduralTerrain() {
    const rings = 48;
    const segs = 68;
    const positions = [];
    const colors = [];
    const indices = [];

    const cForestLow = new THREE.Color(0x3a7d2e);
    const cForestHigh = new THREE.Color(0x74be48);
    const cSnow = new THREE.Color(0xeef6ff);
    const cSnowRock = new THREE.Color(0x8899ad);
    const cDesert = new THREE.Color(0xe6c373);
    const cDesertDark = new THREE.Color(0xc99f4f);
    const cSakura = new THREE.Color(0x63ad4b);
    const cSand = new THREE.Color(0xdcc486);
    const tmp = new THREE.Color();

    positions.push(0, this.getTerrainHeight(0, 0), 0);
    colors.push(cForestLow.r, cForestLow.g, cForestLow.b);

    for (let r = 1; r <= rings; r++) {
      const rad = (r / rings) * BR_RADIUS;
      for (let s = 0; s < segs; s++) {
        const a = (s / segs) * Math.PI * 2;
        const x = Math.cos(a) * rad;
        const z = Math.sin(a) * rad;
        const y = this.getTerrainHeight(x, z);
        positions.push(x, y, z);

        const rDist = Math.abs(x - this.getRiverX(z));
        const biome = this.getBiome(x, z);
        if (rad > BR_RADIUS - 18 || rDist < 9.5) {
          tmp.copy(cSand);
        } else if (biome === 'snow') {
          tmp.copy(y > 14 ? cSnow : cSnowRock).lerp(cSnow, Math.min(1, y / 18));
        } else if (biome === 'desert') {
          tmp.copy(cDesertDark).lerp(cDesert, Math.min(1, y / 14));
        } else if (biome === 'sakura') {
          tmp.copy(cSakura);
        } else {
          tmp.copy(cForestLow).lerp(cForestHigh, Math.min(1, y / 18));
        }
        const shade = 0.94 + (((r * 17 + s * 11) % 10) / 10) * 0.12;
        tmp.multiplyScalar(shade);
        colors.push(tmp.r, tmp.g, tmp.b);
      }
    }

    for (let s = 0; s < segs; s++) indices.push(0, 1 + ((s + 1) % segs), 1 + s);
    for (let r = 1; r < rings; r++) {
      const r0 = 1 + (r - 1) * segs;
      const r1 = 1 + r * segs;
      for (let s = 0; s < segs; s++) {
        const next = (s + 1) % segs;
        indices.push(r0 + s, r0 + next, r1 + next);
        indices.push(r0 + s, r1 + next, r1 + s);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geo.setIndex(indices);
    const nonIdx = geo.toNonIndexed();
    nonIdx.computeVertexNormals();

    const terrain = new THREE.Mesh(
      nonIdx,
      new THREE.MeshStandardMaterial({ vertexColors: true, flatShading: true, roughness: 0.92 })
    );
    terrain.receiveShadow = true;
    this.worldContent.add(terrain);

    // Sparkling Surrounding Ocean Plane
    const ocean = new THREE.Mesh(
      new THREE.CircleGeometry(520, 32),
      new THREE.MeshStandardMaterial({
        color: 0x1b8ed6,
        emissive: 0x0b528c,
        emissiveIntensity: 0.35,
        roughness: 0.2,
        flatShading: true,
      })
    );
    ocean.rotation.x = -Math.PI / 2;
    ocean.position.y = -0.3;
    this.worldContent.add(ocean);
  }

  _buildRiverAndBridges() {
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x2ec4f6,
      emissive: 0x1088c9,
      emissiveIntensity: 0.4,
      transparent: true,
      opacity: 0.85,
      flatShading: true,
      side: THREE.DoubleSide,
    });
    const verts = [];
    const indices = [];
    let count = 0;
    for (let z = -BR_RADIUS + 4; z <= BR_RADIUS - 4; z += 6) {
      const cx = this.getRiverX(z);
      if (Math.hypot(cx, z) > BR_RADIUS - 2) continue;
      verts.push(cx - 6.0, 0.05, z);
      verts.push(cx + 6.0, 0.05, z);
      if (count > 0) {
        const i0 = (count - 1) * 2;
        const i1 = count * 2;
        indices.push(i0, i1, i0 + 1);
        indices.push(i0 + 1, i1, i1 + 1);
      }
      count++;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    this.worldContent.add(new THREE.Mesh(geo, waterMat));

    // Walkable Canyon Bridges
    const wood = new THREE.MeshStandardMaterial({ color: 0x734728, flatShading: true });
    const dark = new THREE.MeshStandardMaterial({ color: 0x3b2212, flatShading: true });
    for (const br of this.bridges) {
      const bx = this.getRiverX(br.z);
      const g = new THREE.Group();
      g.position.set(bx, 0, br.z);
      const deck = new THREE.Mesh(new THREE.BoxGeometry(16.8, 0.45, 5.2), wood);
      deck.position.y = 1.15;
      deck.castShadow = true;
      deck.receiveShadow = true;
      g.add(deck);
      for (const s of [-1, 1]) {
        const ramp = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.35, 5.2), wood);
        ramp.position.set(s * 9.5, 0.72, 0);
        ramp.rotation.z = -s * 0.34;
        g.add(ramp);
      }
      for (const sz of [-2.4, 2.4]) {
        const rail = new THREE.Mesh(new THREE.BoxGeometry(16.8, 0.22, 0.22), dark);
        rail.position.set(0, 2.3, sz);
        g.add(rail);
      }
      this.worldContent.add(g);
    }
  }

  _buildVillageAndLandmarks(rand) {
    const plaster = new THREE.MeshStandardMaterial({ color: 0xeee4d0, flatShading: true });
    const roofRed = new THREE.MeshStandardMaterial({ color: 0xc93b3b, flatShading: true });
    const roofBlue = new THREE.MeshStandardMaterial({ color: 0x2a5c8a, flatShading: true });
    const wood = new THREE.MeshStandardMaterial({ color: 0x5c361e, flatShading: true });
    const sandStone = new THREE.MeshStandardMaterial({ color: 0xd9b05b, flatShading: true });

    // Central Village Houses (grounded on flattened village plateau)
    const houses = [
      [-28, 2, 0.2, roofBlue],
      [-10, -4, -0.4, roofRed],
      [-22, 18, 0.9, roofBlue],
      [-6, 16, -0.8, roofRed],
      [-45, -112, 0.3, roofBlue], // Snowy cabin!
      [-22, -124, -0.5, roofRed], // Snowy cabin 2!
    ];

    for (const [hx, hz, rot, rMat] of houses) {
      const hy = this.getTerrainHeight(hx, hz);
      const h = new THREE.Group();
      h.position.set(hx, hy - 0.5, hz);
      h.rotation.y = rot;
      const base = new THREE.Mesh(new THREE.BoxGeometry(7.2, 5.0, 6.2), plaster);
      base.position.y = 2.5;
      base.castShadow = true;
      base.receiveShadow = true;
      h.add(base);
      const roof = new THREE.Mesh(new THREE.ConeGeometry(5.8, 3.4, 4), rMat);
      roof.position.y = 6.6;
      roof.rotation.y = Math.PI / 4;
      roof.castShadow = true;
      h.add(roof);
      const door = new THREE.Mesh(new THREE.BoxGeometry(1.5, 2.4, 0.25), wood);
      door.position.set(0, 1.3, 3.1);
      h.add(door);
      this.worldContent.add(h);
      this.obstacles.push({ x: hx, z: hz, r: 4.1 });
    }

    // Desert Pyramids in East Biome
    const pyrs = [
      [115, -15, 16, 14],
      [135, 18, 11, 10],
      [96, -42, 10, 9],
    ];
    for (const [px, pz, rad, ht] of pyrs) {
      const py = this.getTerrainHeight(px, pz);
      const pyr = new THREE.Mesh(new THREE.ConeGeometry(rad, ht, 4), sandStone);
      pyr.position.set(px, py + ht * 0.42, pz);
      pyr.rotation.y = Math.PI / 4;
      pyr.castShadow = true;
      pyr.receiveShadow = true;
      this.worldContent.add(pyr);
      this.obstacles.push({ x: px, z: pz, r: rad * 0.65 });
    }

    // Floating POI Landmark labels high above each biome
    for (const poi of this.pois) {
      const py = this.getTerrainHeight(poi.x, poi.z);
      const lbl = createFloatingLabel(poi.name.toUpperCase(), '', '#ffd43b', 340, 74);
      lbl.position.set(poi.x, py + 15, poi.z);
      lbl.scale.set(6.5, 1.4, 1);
      this.worldContent.add(lbl);
    }
  }

  _buildBiomeNature(rand) {
    for (let i = 0; i < 165; i++) {
      const a = rand() * Math.PI * 2;
      const d = 14 + rand() * (BR_RADIUS - 30);
      const x = Math.cos(a) * d;
      const z = Math.sin(a) * d;
      if (Math.abs(x - this.getRiverX(z)) < 11) continue;
      if (Math.hypot(x + 18, z - 8) < 22) continue;

      const y = this.getTerrainHeight(x, z);
      if (y < 0.8) continue;
      const biome = this.getBiome(x, z);
      const s = 0.9 + rand() * 0.95;

      if (biome === 'desert') {
        const rock = createRock(s * 1.1);
        rock.material.color.setHex(0xc29b59);
        rock.position.set(x, y + 0.1, z);
        this.worldContent.add(rock);
      } else if (biome === 'sakura') {
        const t = createSakuraTree(s);
        t.position.set(x, y - 0.35, z);
        this.worldContent.add(t);
        this.obstacles.push({ x, z, r: 0.7 * s });
      } else {
        const t = createPineTree(s);
        t.position.set(x, y - 0.35, z);
        this.worldContent.add(t);
        this.obstacles.push({ x, z, r: 0.7 * s });
      }
    }

    // Scattered Crystals & Boulders
    for (let i = 0; i < 36; i++) {
      const a = rand() * Math.PI * 2;
      const d = 18 + rand() * (BR_RADIUS - 35);
      const x = Math.cos(a) * d;
      const z = Math.sin(a) * d;
      const y = this.getTerrainHeight(x, z);
      if (y < 0.6) continue;
      const c = createCrystal(1.1 + rand() * 0.9, i % 2 ? 0x63f0ff : 0xff8fab);
      c.position.set(x, y - 0.2, z);
      this.worldContent.add(c);
    }
  }

  _buildLootSpawns(rand) {
    // 68 Loot Pickups distributed across the entire open world
    // Mix: 32 Guns (all 5 firearm types), 18 Powers (from 28 powers), 10 Medkits, 8 Shield Potions
    const total = 68;
    for (let i = 0; i < total; i++) {
      let x, z;
      if (i < 16) {
        // Cluster rich loot around Village & POIs
        const poi = this.pois[i % this.pois.length];
        x = poi.x + (rand() - 0.5) * 34;
        z = poi.z + (rand() - 0.5) * 34;
      } else {
        const a = rand() * Math.PI * 2;
        const d = 12 + rand() * (BR_RADIUS - 32);
        x = Math.cos(a) * d;
        z = Math.sin(a) * d;
      }
      if (Math.abs(x - this.getRiverX(z)) < 9) x += 12;
      const y = this.getTerrainHeight(x, z);
      if (y < 0.4) continue;

      let kind, itemId, name, color, model;
      if (i % 4 === 0 || i % 4 === 1) {
        kind = 'gun';
        const w = WEAPON_LIST[Math.floor(rand() * WEAPON_LIST.length)];
        itemId = w.id;
        name = w.name;
        color = w.rarityColor;
        model = createGunModel(w.id);
        model.scale.setScalar(1.35);
      } else if (i % 4 === 2) {
        kind = 'power';
        const p = POWERS[Math.floor(rand() * POWERS.length)];
        itemId = p.id;
        name = `Pouvoir ${p.name}`;
        color = p.color;
        model = createPowerModel(p.id);
        model.scale.setScalar(1.1);
      } else {
        kind = rand() < 0.55 ? 'medkit' : 'shield';
        itemId = kind;
        name = kind === 'medkit' ? 'Kit de Soin (+45 PV)' : 'Potion Bouclier (+50)';
        color = kind === 'medkit' ? '#ff5964' : '#29c7ff';
        model = createConsumableModel(kind);
        model.scale.setScalar(1.15);
      }

      const wrap = new THREE.Group();
      wrap.position.set(x, y + 0.15, z);
      model.position.y = 1.05;
      wrap.add(model);

      // Subtle glowing rarity beacon column so loot is visible from afar
      const colHex = new THREE.Color(color).getHex();
      const beam = new THREE.Mesh(
        new THREE.CylinderGeometry(0.12, 0.36, 4.5, 6),
        new THREE.MeshBasicMaterial({ color: colHex, transparent: true, opacity: 0.28, depthWrite: false })
      );
      beam.position.y = 2.25;
      wrap.add(beam);

      const ring = new THREE.Mesh(
        new THREE.RingGeometry(0.65, 0.9, 14),
        new THREE.MeshBasicMaterial({ color: colHex, side: THREE.DoubleSide, transparent: true, opacity: 0.75 })
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.08;
      wrap.add(ring);

      this.lootGroup.add(wrap);
      const id = `loot-${this.seed}-${i}`;
      this.loots.set(id, {
        id,
        kind,
        itemId,
        name,
        color,
        pos: new THREE.Vector3(x, y, z),
        mesh: wrap,
        model,
        taken: false,
      });
    }
  }

  _buildClouds(rand) {
    const mat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0xfff5eb,
      emissiveIntensity: 0.55,
      flatShading: true,
      transparent: true,
      opacity: 0.92,
    });
    for (let i = 0; i < 26; i++) {
      const c = new THREE.Group();
      for (let p = 0; p < 3; p++) {
        const m = new THREE.Mesh(new THREE.DodecahedronGeometry(6 + (p % 2) * 2.5, 0), mat);
        m.position.set((p - 1) * 6, (p % 2) * 1.4, 0);
        m.scale.set(1.3, 0.55, 1.0);
        c.add(m);
      }
      c.position.set((rand() - 0.5) * 440, 118 + rand() * 24, (rand() - 0.5) * 440);
      c.userData.speed = 1.8 + rand() * 2.0;
      this.worldContent.add(c);
      this.clouds.push(c);
    }
  }

  markLootTaken(id) {
    const item = this.loots.get(id);
    if (!item || item.taken) return null;
    item.taken = true;
    item.mesh.visible = false;
    return item;
  }

  findNearestLoot(pos, maxDist = 3.6) {
    let best = null;
    let bestD = maxDist;
    for (const item of this.loots.values()) {
      if (item.taken) continue;
      const d = Math.hypot(item.pos.x - pos.x, item.pos.z - pos.z);
      if (d < bestD && Math.abs(item.pos.y - pos.y) < 3.0) {
        bestD = d;
        best = item;
      }
    }
    return best;
  }

  resolveObstacles(pos, radius = 0.65) {
    for (const obs of this.obstacles) {
      const dx = pos.x - obs.x;
      const dz = pos.z - obs.z;
      const d = Math.hypot(dx, dz);
      const minD = obs.r + radius;
      if (d < minD && d > 0.0001) {
        pos.x = obs.x + (dx / d) * minD;
        pos.z = obs.z + (dz / d) * minD;
      }
    }
  }

  isOutsideStorm(pos) {
    return Math.hypot(pos.x - this.stormCenter.x, pos.z - this.stormCenter.z) > this.stormRadius;
  }

  _bakeMinimapTexture() {
    const ctx = this.mapCanvasBase.getContext('2d');
    const W = 256;
    ctx.fillStyle = '#146cb0';
    ctx.fillRect(0, 0, W, W);

    const step = 2;
    for (let py = 0; py < W; py += step) {
      for (let px = 0; px < W; px += step) {
        const wx = ((px / W) * 2 - 1) * (BR_RADIUS + 20);
        const wz = ((py / W) * 2 - 1) * (BR_RADIUS + 20);
        const d = Math.hypot(wx, wz);
        if (d > BR_RADIUS) continue;
        const rDist = Math.abs(wx - this.getRiverX(wz));
        const biome = this.getBiome(wx, wz);
        if (rDist < 6.5) ctx.fillStyle = '#38d9ff';
        else if (d > BR_RADIUS - 16) ctx.fillStyle = '#e0c686';
        else if (biome === 'snow') ctx.fillStyle = '#e8f4ff';
        else if (biome === 'desert') ctx.fillStyle = '#e4c16f';
        else if (biome === 'sakura') ctx.fillStyle = '#e89ec2';
        else ctx.fillStyle = '#4e9938';
        ctx.fillRect(px, py, step, step);
      }
    }
  }

  /**
   * Renders live Minimap OR Full Tactical Map Canvas (terrain biomes + plane flight line + storm circle + loot + players)
   */
  renderMapCanvas(canvas, playerPos, playerYaw, remotePlayers = [], isFull = false) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width;
    const H = canvas.height;
    const worldSpan = (BR_RADIUS + 20) * 2;
    const toMap = (wx, wz) => [
      ((wx + BR_RADIUS + 20) / worldSpan) * W,
      ((wz + BR_RADIUS + 20) / worldSpan) * H,
    ];

    ctx.clearRect(0, 0, W, H);
    ctx.drawImage(this.mapCanvasBase, 0, 0, W, H);

    // Storm Circle overlay
    const [scx, scz] = toMap(this.stormCenter.x, this.stormCenter.z);
    const sr = (this.stormRadius / worldSpan) * W;
    ctx.strokeStyle = '#c77dff';
    ctx.lineWidth = isFull ? 4 : 2.5;
    ctx.beginPath();
    ctx.arc(scx, scz, Math.max(2, sr), 0, Math.PI * 2);
    ctx.stroke();

    // Plane Flight Path
    const [p1x, p1y] = toMap(this.planeStart.x, this.planeStart.z);
    const [p2x, p2y] = toMap(this.planeEnd.x, this.planeEnd.z);
    ctx.strokeStyle = 'rgba(255, 224, 102, 0.65)';
    ctx.setLineDash([6, 6]);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(p1x, p1y);
    ctx.lineTo(p2x, p2y);
    ctx.stroke();
    ctx.setLineDash([]);

    // Battle Plane icon
    if (this.planeProgress < 1) {
      const [plx, ply] = toMap(this.planeMesh.position.x, this.planeMesh.position.z);
      ctx.fillStyle = '#ffe066';
      ctx.beginPath();
      ctx.arc(plx, ply, isFull ? 7 : 4.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // POI names on Full Tactical Map
    if (isFull) {
      ctx.font = 'bold 14px Nunito, sans-serif';
      ctx.textAlign = 'center';
      for (const poi of this.pois) {
        const [lx, ly] = toMap(poi.x, poi.z);
        ctx.fillStyle = 'rgba(12, 22, 38, 0.78)';
        ctx.fillRect(lx - 58, ly - 11, 116, 20);
        ctx.fillStyle = '#fff4c4';
        ctx.fillText(poi.name, lx, ly + 4);
      }

      // Loot dots on full map
      for (const item of this.loots.values()) {
        if (item.taken) continue;
        const [ix, iy] = toMap(item.pos.x, item.pos.z);
        ctx.fillStyle = item.color;
        ctx.fillRect(ix - 2, iy - 2, 4, 4);
      }
    }

    // Remote BR players
    for (const r of remotePlayers) {
      if (r.isDead || r.remoteZone !== 'br') continue;
      const [rx, ry] = toMap(r.position.x, r.position.z);
      ctx.fillStyle = '#ff5964';
      ctx.beginPath();
      ctx.arc(rx, ry, isFull ? 6 : 3.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Local Player Arrow
    const [px, py] = toMap(playerPos.x, playerPos.z);
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(-playerYaw);
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#122138';
    ctx.lineWidth = 2;
    ctx.beginPath();
    const s = isFull ? 10 : 6.5;
    ctx.moveTo(0, -s);
    ctx.lineTo(s * 0.72, s * 0.8);
    ctx.lineTo(0, s * 0.4);
    ctx.lineTo(-s * 0.72, s * 0.8);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  update(t, dt) {
    // Advance Battle Plane across island
    if (this.planeProgress < 1.05) {
      this.planeProgress += dt / this.planeDuration;
      this.planeMesh.position.lerpVectors(this.planeStart, this.planeEnd, Math.min(1, this.planeProgress));
      this.planeMesh.userData.animate?.(t);
    }

    // Shrink Storm Wall smoothly
    if (this.stormRadius > this.stormTargetRadius) {
      this.stormRadius = Math.max(this.stormTargetRadius, this.stormRadius - this.stormShrinkSpeed * dt);
    }
    this.stormMesh.position.x = this.stormCenter.x;
    this.stormMesh.position.z = this.stormCenter.z;
    this.stormMesh.scale.set(this.stormRadius, 1, this.stormRadius);

    // Animate visible loot pickups
    for (const item of this.loots.values()) {
      if (item.taken) continue;
      item.model.rotation.y = t * 1.6;
      item.model.position.y = 1.05 + Math.sin(t * 3 + item.pos.x) * 0.14;
      if (item.model.userData.animate) item.model.userData.animate(t);
    }

    for (const c of this.clouds) {
      c.position.x += c.userData.speed * dt;
      if (c.position.x > 240) c.position.x = -240;
    }
  }
}
