import * as THREE from 'three';
import {
  createPineTree,
  createSakuraTree,
  createRock,
  createCrystal,
  createBlueMushroom,
  createPortalMesh,
} from '../models/LowPolyModels.js';

export const ARENA_RADIUS = 116;

function smoothstep(edge0, edge1, x) {
  const t = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

/**
 * River centerline X(z), shared by terrain carving, water mesh, bridges, and waterfall.
 */
export function getRiverCenterX(z) {
  return 31 + Math.sin(z * 0.036) * 8.5;
}

/**
 * Computes terrain elevation at (x, z) with flattened terraces for landmarks
 * and a carved riverbed along getRiverCenterX(z).
 */
export function getArenaTerrainHeight(x, z) {
  const dist = Math.hypot(x, z);
  if (dist > ARENA_RADIUS) return -45;

  // Rolling meadow hills outside central plaza
  const centerBlend = smoothstep(18, 36, dist);
  const h1 = Math.sin(x * 0.04) * Math.cos(z * 0.038) * 5.8;
  const h2 = Math.sin((x + z) * 0.028 + 1.2) * 3.6;
  const h3 = Math.cos(x * 0.085 - z * 0.075) * 1.1;

  // Scenic northern & western hills
  const northHill = Math.max(0, 1 - Math.hypot(x + 12, z + 64) / 36) ** 2 * 13.5;
  const eastHill = Math.max(0, 1 - Math.hypot(x - 64, z + 18) / 32) ** 2 * 10.5;

  let h = Math.max(0, (h1 + h2 + h3 + 3.8) * centerBlend * 0.65 + northHill + eastHill);

  // Smoothly flatten Watchtower Village terrace at (-38, -20) to y = 5.4
  const dVillage = Math.hypot(x + 38, z + 20);
  if (dVillage < 24) {
    const w = 1 - smoothstep(11, 24, dVillage);
    h = THREE.MathUtils.lerp(h, 5.4, w);
  }

  // Smoothly flatten Sakura Shrine Glade at (-32, 24) to y = 2.2
  const dShrine = Math.hypot(x + 32, z - 24);
  if (dShrine < 20) {
    const w = 1 - smoothstep(9, 20, dShrine);
    h = THREE.MathUtils.lerp(h, 2.2, w);
  }

  // Smoothly flatten Return Portal stone terrace at (0, 56) to y = 1.6
  const dPortal = Math.hypot(x, z - 56);
  if (dPortal < 18) {
    const w = 1 - smoothstep(8, 18, dPortal);
    h = THREE.MathUtils.lerp(h, 1.6, w);
  }

  // Carve flat flat valley riverbed down to y = -0.85 so continuous flat water sits cleanly inside its banks
  const riverDist = Math.abs(x - getRiverCenterX(z));
  if (riverDist < 18) {
    // Bank transitions cleanly from terrain height -> flat 0.65 bank -> -0.85 channel
    const valleyBlend = 1 - smoothstep(7, 18, riverDist);
    h = THREE.MathUtils.lerp(h, 0.55, valleyBlend);
    if (riverDist < 7.2) {
      const channelBlend = 1 - smoothstep(3.8, 7.2, riverDist);
      h = THREE.MathUtils.lerp(h, -0.85, channelBlend);
    }
  }

  // Gentle bevel at island cliff edge
  const edgeFade = dist > ARENA_RADIUS - 8 ? Math.max(0, (ARENA_RADIUS - dist) / 8) : 1;
  return h * edgeFade;
}

export const ARENA_BRIDGES = [
  { z: 12, halfZ: 2.4, halfDeckX: 7.6, rampLen: 2.6, deckY: 1.26 },
  { z: -28, halfZ: 2.4, halfDeckX: 7.6, rampLen: 2.6, deckY: 1.26 },
];

/**
 * Walkable height at (x, z), taking into account the two wooden bridges and their ramps.
 */
export function getArenaWalkableHeight(x, z, currentY = 10) {
  let h = getArenaTerrainHeight(x, z);
  for (const b of ARENA_BRIDGES) {
    if (Math.abs(z - b.z) <= b.halfZ) {
      const bx = getRiverCenterX(b.z);
      const dx = Math.abs(x - bx);
      if (dx <= b.halfDeckX) {
        if (currentY >= b.deckY - 1.15) h = Math.max(h, b.deckY);
      } else if (dx <= b.halfDeckX + b.rampLen) {
        const t = 1 - (dx - b.halfDeckX) / b.rampLen;
        const rampY = 0.25 + t * (b.deckY - 0.25);
        if (currentY >= rampY - 1.15) h = Math.max(h, rampY);
      }
    }
  }
  return h;
}

function createSkyDomeTexture(topHex, midHex, botHex) {
  const c = document.createElement('canvas');
  c.width = 64;
  c.height = 256;
  const ctx = c.getContext('2d');
  const g = ctx.createLinearGradient(0, 0, 0, 256);
  g.addColorStop(0, topHex);
  g.addColorStop(0.52, midHex);
  g.addColorStop(1, botHex);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 64, 256);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Main combat valley arena (classic, combo, and ranked modes).
 */
export class ArenaWorld {
  constructor() {
    this.group = new THREE.Group();
    this.returnPortalPos = new THREE.Vector3(0, 0, 56);
    this.returnPortalMesh = null;
    this.jumpPads = [];
    this.clouds = [];
    this.birds = [];
    this.waterfallDrops = [];
    this.fireflies = null;
    this.skyIslands = [];
    this.obstacles = [];
    this.sunLight = null;
    this.sunHalo = null;
    this.skyDome = null;

    this._buildSkyAndLighting();
    this._buildTerrain();
    this._buildCobblestonePaths();
    this._buildAncientTemple();
    this._buildCoherentRiverAndWaterfall();
    this._buildBridge();
    this._buildVillageOutpost();
    this._buildSakuraShrine();
    this._buildCrystalOutcrop();
    this._buildProps();
    this._buildJumpPads();
    this._buildReturnPortal();
    this._buildSkyIslands();
    this._buildCloudsAndBirds();
    this._buildFireflies();
  }

  _buildSkyAndLighting() {
    const hemi = new THREE.HemisphereLight(0xe3f4ff, 0x3b6e2e, 1.05);
    this.group.add(hemi);

    const sun = new THREE.DirectionalLight(0xfff6dc, 1.95);
    sun.position.set(64, 88, 44);
    sun.castShadow = true;
    sun.shadow.mapSize.width = 2048;
    sun.shadow.mapSize.height = 2048;
    sun.shadow.camera.near = 15;
    sun.shadow.camera.far = 260;
    const d = 120;
    sun.shadow.camera.left = -d;
    sun.shadow.camera.right = d;
    sun.shadow.camera.top = d;
    sun.shadow.camera.bottom = -d;
    sun.shadow.bias = -0.0005;
    this.group.add(sun);
    this.sunLight = sun;

    // Gradient Sky Dome (never flat dull single color)
    const domeGeo = new THREE.SphereGeometry(260, 20, 14);
    const domeMat = new THREE.MeshBasicMaterial({
      map: createSkyDomeTexture('#4fa8f0', '#9fd8ff', '#e8f6ff'),
      side: THREE.BackSide,
      fog: false,
    });
    this.skyDome = new THREE.Mesh(domeGeo, domeMat);
    this.group.add(this.skyDome);

    // Stylized Low-Poly Sun
    const sunGroup = new THREE.Group();
    sunGroup.position.set(120, 112, -98);
    sunGroup.add(new THREE.Mesh(new THREE.IcosahedronGeometry(11, 0), new THREE.MeshBasicMaterial({ color: 0xfff4ad, fog: false })));
    const halo = new THREE.Mesh(
      new THREE.RingGeometry(13.5, 17.0, 16),
      new THREE.MeshBasicMaterial({ color: 0xffe066, side: THREE.DoubleSide, transparent: true, opacity: 0.45, fog: false })
    );
    halo.lookAt(0, 0, 0);
    sunGroup.add(halo);
    this.sunHalo = halo;
    this.group.add(sunGroup);
  }

  setAtmosphere(mode = 'arena') {
    if (!this.skyDome) return;
    if (this.skyDome.material.map) this.skyDome.material.map.dispose();
    if (mode === 'combo') {
      this.skyDome.material.map = createSkyDomeTexture('#5e4b8b', '#e88b68', '#ffdcb4');
    } else {
      this.skyDome.material.map = createSkyDomeTexture('#439be8', '#99d5ff', '#e8f6ff');
    }
    this.skyDome.material.needsUpdate = true;
  }

  _buildTerrain() {
    const rings = 44;
    const segs = 64;
    const positions = [];
    const colors = [];
    const indices = [];

    const cLow = new THREE.Color(0x3a7c2c);
    const cMid = new THREE.Color(0x569e3a);
    const cHigh = new THREE.Color(0x7ac44d);
    const cSand = new THREE.Color(0xdcc488);
    const cRiverBed = new THREE.Color(0x6e8579);
    const cRim = new THREE.Color(0x586270);
    const tmp = new THREE.Color();

    positions.push(0, getArenaTerrainHeight(0, 0), 0);
    colors.push(cMid.r, cMid.g, cMid.b);

    for (let r = 1; r <= rings; r++) {
      const radius = (r / rings) * ARENA_RADIUS;
      for (let s = 0; s < segs; s++) {
        const a = (s / segs) * Math.PI * 2;
        const x = Math.cos(a) * radius;
        const z = Math.sin(a) * radius;
        const y = getArenaTerrainHeight(x, z);
        positions.push(x, y, z);

        const riverDist = Math.abs(x - getRiverCenterX(z));
        if (r >= rings - 1) {
          tmp.copy(cRim);
        } else if (riverDist < 5.0) {
          tmp.copy(cRiverBed);
        } else if (riverDist < 9.0) {
          tmp.copy(cSand);
        } else {
          const t = Math.min(1, Math.max(0, y) / 13);
          tmp.copy(cLow).lerp(cMid, Math.min(1, t * 1.45)).lerp(cHigh, Math.max(0, t - 0.35));
          const shade = 0.94 + (((r * 13 + s * 7) % 10) / 10) * 0.12;
          tmp.multiplyScalar(shade);
        }
        colors.push(tmp.r, tmp.g, tmp.b);
      }
    }

    for (let s = 0; s < segs; s++) indices.push(0, 1 + ((s + 1) % segs), 1 + s);
    for (let r = 1; r < rings; r++) {
      const r0 = 1 + (r - 1) * segs;
      const r1 = 1 + r * segs;
      for (let s = 0; s < segs; s++) {
        const next = (s + 1) % segs;
        indices.push(r0 + s, r0 + next, r1 + next);
        indices.push(r0 + s, r1 + next, r1 + s);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geo.setIndex(indices);
    const nonIndexed = geo.toNonIndexed();
    nonIndexed.computeVertexNormals();

    const terrain = new THREE.Mesh(
      nonIndexed,
      new THREE.MeshStandardMaterial({ vertexColors: true, flatShading: true, roughness: 0.9, metalness: 0.02 })
    );
    terrain.receiveShadow = true;
    terrain.castShadow = true;
    this.group.add(terrain);

    // Floating Island Rocky Underside
    const underside = new THREE.Mesh(
      new THREE.ConeGeometry(ARENA_RADIUS * 1.01, 46, 28),
      new THREE.MeshStandardMaterial({ color: 0x4b5362, flatShading: true, roughness: 0.95 })
    );
    underside.rotation.x = Math.PI;
    underside.position.y = -23.1;
    this.group.add(underside);
  }

  _buildCobblestonePaths() {
    // Stepping stones naturally connecting Central Temple -> Portal, Bridge, Sakura Shrine, and Village
    const stoneMat = new THREE.MeshStandardMaterial({ color: 0x8d97a6, flatShading: true, roughness: 0.88 });
    const paths = [
      // Temple -> Return Portal
      { from: [0, 18], to: [0, 50], steps: 11 },
      // Temple -> Wooden Bridge
      { from: [16, 6], to: [getRiverCenterX(12) - 7, 12], steps: 6 },
      // Temple -> Sakura Shrine
      { from: [-15, 11], to: [-28, 22], steps: 7 },
      // Temple -> Watchtower Village
      { from: [-16, -9], to: [-30, -16], steps: 7 },
    ];

    for (const p of paths) {
      for (let i = 0; i <= p.steps; i++) {
        const t = i / p.steps;
        const x = THREE.MathUtils.lerp(p.from[0], p.to[0], t) + Math.sin(i * 1.7) * 0.45;
        const z = THREE.MathUtils.lerp(p.from[1], p.to[1], t);
        const y = getArenaTerrainHeight(x, z);
        if (y < 0.1) continue;
        const tile = new THREE.Mesh(new THREE.CylinderGeometry(1.15, 1.3, 0.24, 6), stoneMat);
        tile.position.set(x, y + 0.02, z);
        tile.rotation.y = i * 0.7;
        tile.receiveShadow = true;
        this.group.add(tile);
      }
    }
  }

  _buildAncientTemple() {
    const stone = new THREE.MeshStandardMaterial({ color: 0x828fa1, flatShading: true, roughness: 0.84 });
    const darkStone = new THREE.MeshStandardMaterial({ color: 0x526073, flatShading: true, roughness: 0.9 });
    const goldMat = new THREE.MeshStandardMaterial({ color: 0xe6b842, metalness: 0.45, roughness: 0.35 });
    const runeGlow = new THREE.MeshStandardMaterial({ color: 0x45f2ff, emissive: 0x22d0ff, emissiveIntensity: 1.2 });
    const fireMat = new THREE.MeshStandardMaterial({ color: 0xffaa2b, emissive: 0xff6600, emissiveIntensity: 1.45 });

    // Stepped Circular Temple Dais firmly anchored into y = 0
    const stepBase = new THREE.Mesh(new THREE.CylinderGeometry(18.2, 19.2, 0.8, 16), darkStone);
    stepBase.position.set(0, -0.1, 0);
    stepBase.receiveShadow = true;
    this.group.add(stepBase);

    const plaza = new THREE.Mesh(new THREE.CylinderGeometry(16.6, 17.2, 0.5, 16), stone);
    plaza.position.set(0, 0.22, 0);
    plaza.receiveShadow = true;
    this.group.add(plaza);

    const innerRing = new THREE.Mesh(
      new THREE.RingGeometry(8.5, 9.6, 24),
      new THREE.MeshBasicMaterial({ color: 0x7ceeff, side: THREE.DoubleSide, transparent: true, opacity: 0.55 })
    );
    innerRing.rotation.x = -Math.PI / 2;
    innerRing.position.y = 0.49;
    this.group.add(innerRing);

    const centerEmblem = new THREE.Mesh(
      new THREE.RingGeometry(2.4, 3.0, 8),
      new THREE.MeshBasicMaterial({ color: 0xffd43b, side: THREE.DoubleSide, transparent: true, opacity: 0.5 })
    );
    centerEmblem.rotation.x = -Math.PI / 2;
    centerEmblem.position.y = 0.49;
    this.group.add(centerEmblem);

    // 8 Grounded Ancient Columns with Stone Arches & Braziers
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2 + Math.PI / 8;
      const px = Math.cos(a) * 16.0;
      const pz = Math.sin(a) * 16.0;
      const colH = i % 2 === 0 ? 7.2 : 4.8;

      const col = new THREE.Group();
      col.position.set(px, 0.35, pz);

      const base = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.9, 2.1), darkStone);
      base.position.y = 0.4;
      col.add(base);

      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.66, 0.8, colH, 8), stone);
      shaft.position.y = colH / 2 + 0.4;
      shaft.castShadow = true;
      col.add(shaft);

      const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.84, 0.84, 0.25, 8), goldMat);
      ring.position.y = colH * 0.72;
      col.add(ring);

      const cap = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.45, 1.9), darkStone);
      cap.position.y = colH + 0.55;
      col.add(cap);

      if (i % 2 === 0) {
        const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(0.62, 0), runeGlow);
        crystal.position.y = colH + 1.5;
        col.add(crystal);
      } else {
        const flame = new THREE.Mesh(new THREE.OctahedronGeometry(0.6, 0), fireMat);
        flame.position.y = colH + 1.25;
        flame.scale.set(0.8, 1.45, 0.8);
        col.add(flame);
      }

      this.group.add(col);
      this.obstacles.push({ x: px, z: pz, r: 1.05 });
    }
  }

  _buildCoherentRiverAndWaterfall() {
    // Continuous WATER RIBBON lying flat at constant y = 0.05 inside the carved riverbed
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x2ec4f6,
      emissive: 0x1088c9,
      emissiveIntensity: 0.42,
      transparent: true,
      opacity: 0.84,
      roughness: 0.14,
      flatShading: true,
      side: THREE.DoubleSide,
    });

    const verts = [];
    const indices = [];
    const halfWidth = 5.4;
    const zStart = -104;
    const zEnd = 106;
    const step = 4;
    let count = 0;

    for (let z = zStart; z <= zEnd; z += step) {
      const cx = getRiverCenterX(z);
      const rDist = Math.hypot(cx, z);
      if (rDist > ARENA_RADIUS + 1.5 && count > 0) continue;
      verts.push(cx - halfWidth, 0.05, z);
      verts.push(cx + halfWidth, 0.05, z);
      if (count > 0) {
        const i0 = (count - 1) * 2;
        const i1 = count * 2;
        indices.push(i0, i1, i0 + 1);
        indices.push(i0 + 1, i1, i1 + 1);
      }
      count++;
    }

    const riverGeo = new THREE.BufferGeometry();
    riverGeo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    riverGeo.setIndex(indices);
    riverGeo.computeVertexNormals();
    const riverMesh = new THREE.Mesh(riverGeo, waterMat);
    riverMesh.receiveShadow = true;
    this.group.add(riverMesh);

    // Sparkling Waterfall pouring smoothly from the exact southern cliff mouth of the river
    const mouthZ = 108;
    const mouthX = getRiverCenterX(mouthZ);
    const waterfallMat = new THREE.MeshStandardMaterial({
      color: 0x5ee0ff,
      emissive: 0x2ab8f5,
      emissiveIntensity: 0.55,
      transparent: true,
      opacity: 0.85,
      flatShading: true,
    });
    const column = new THREE.Mesh(new THREE.BoxGeometry(9.6, 36, 1.8), waterfallMat);
    column.position.set(mouthX, -18, mouthZ + 1.2);
    this.group.add(column);

    const foamMat = new THREE.MeshBasicMaterial({ color: 0xe8fbff, transparent: true, opacity: 0.85 });
    for (let i = 0; i < 14; i++) {
      const drop = new THREE.Mesh(new THREE.DodecahedronGeometry(0.9 + (i % 3) * 0.35, 0), foamMat);
      drop.position.set(mouthX + ((i % 5) - 2) * 1.8, -i * 2.5, mouthZ + 2.0);
      drop.userData.phase = i / 14;
      drop.userData.baseX = drop.position.x;
      this.group.add(drop);
      this.waterfallDrops.push(drop);
    }
  }

  _buildBridge() {
    const wood = new THREE.MeshStandardMaterial({ color: 0x734728, flatShading: true, roughness: 0.85 });
    const darkWood = new THREE.MeshStandardMaterial({ color: 0x3d2211, flatShading: true });
    const stone = new THREE.MeshStandardMaterial({ color: 0x626f82, flatShading: true });
    const lanternGlow = new THREE.MeshStandardMaterial({ color: 0xfff1a8, emissive: 0xffc845, emissiveIntensity: 1.5 });

    for (const br of ARENA_BRIDGES) {
      const bz = br.z;
      const bx = getRiverCenterX(bz);
      const bridge = new THREE.Group();
      bridge.position.set(bx, 0, bz);

      for (const sx of [-7.4, 7.4]) {
        const abut = new THREE.Mesh(new THREE.BoxGeometry(2.4, 2.2, 5.2), stone);
        abut.position.set(sx, 0.1, 0);
        abut.castShadow = true;
        abut.receiveShadow = true;
        bridge.add(abut);
      }

      const deck = new THREE.Mesh(new THREE.BoxGeometry(15.2, 0.42, 4.8), wood);
      deck.position.y = 1.05;
      deck.castShadow = true;
      deck.receiveShadow = true;
      bridge.add(deck);

      for (const s of [-1, 1]) {
        const ramp = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.34, 4.8), wood);
        ramp.position.set(s * 8.6, 0.65, 0);
        ramp.rotation.z = -s * 0.36;
        ramp.receiveShadow = true;
        bridge.add(ramp);
      }

      for (const sz of [-2.2, 2.2]) {
        const rail = new THREE.Mesh(new THREE.BoxGeometry(15.0, 0.22, 0.22), darkWood);
        rail.position.set(0, 2.25, sz);
        bridge.add(rail);
        for (const sx of [-6.8, -2.2, 2.2, 6.8]) {
          const post = new THREE.Mesh(new THREE.BoxGeometry(0.28, 1.5, 0.28), darkWood);
          post.position.set(sx, 1.75, sz);
          bridge.add(post);
        }
        const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.55, 0.45), lanternGlow);
        lamp.position.set(0, 2.75, sz);
        bridge.add(lamp);
      }
      this.group.add(bridge);
    }
  }

  _buildVillageOutpost() {
    // Perched cleanly on the flattened terrace at (-38, -20, y = 5.4)
    const tx = -38;
    const tz = -20;
    const ty = getArenaTerrainHeight(tx, tz);
    const wood = new THREE.MeshStandardMaterial({ color: 0x6e4326, flatShading: true, roughness: 0.85 });
    const darkWood = new THREE.MeshStandardMaterial({ color: 0x3b2212, flatShading: true });
    const plaster = new THREE.MeshStandardMaterial({ color: 0xebe2cf, flatShading: true });
    const roofBlue = new THREE.MeshStandardMaterial({ color: 0x26547c, flatShading: true });
    const stone = new THREE.MeshStandardMaterial({ color: 0x5c6778, flatShading: true });
    const warmWindow = new THREE.MeshStandardMaterial({ color: 0xfff0a8, emissive: 0xffc845, emissiveIntensity: 1.5 });

    const outpost = new THREE.Group();
    outpost.position.set(tx, ty, tz);

    // Stone terrace foundation sunk deep so nothing ever floats
    const found = new THREE.Mesh(new THREE.CylinderGeometry(11.5, 13.0, 2.4, 8), stone);
    found.position.y = -1.0;
    found.receiveShadow = true;
    outpost.add(found);

    // Watchtower
    const tower = new THREE.Group();
    tower.position.set(-2.5, 0, -2.5);
    for (const sx of [-2.0, 2.0]) {
      for (const sz of [-2.0, 2.0]) {
        const leg = new THREE.Mesh(new THREE.BoxGeometry(0.55, 11.5, 0.55), darkWood);
        leg.position.set(sx, 5.2, sz);
        leg.castShadow = true;
        tower.add(leg);
      }
    }
    const plat = new THREE.Mesh(new THREE.BoxGeometry(5.8, 0.5, 5.8), wood);
    plat.position.y = 7.4;
    plat.castShadow = true;
    tower.add(plat);
    const roofCone = new THREE.Mesh(new THREE.ConeGeometry(4.8, 3.6, 4), roofBlue);
    roofCone.position.y = 12.2;
    roofCone.rotation.y = Math.PI / 4;
    roofCone.castShadow = true;
    tower.add(roofCone);
    const beacon = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.1, 0.9), warmWindow);
    beacon.position.y = 9.2;
    tower.add(beacon);
    outpost.add(tower);

    // Cozy Low-Poly Timber Cabin beside the watchtower
    const cabin = new THREE.Group();
    cabin.position.set(4.5, 0, 2.5);
    cabin.rotation.y = -0.45;
    const body = new THREE.Mesh(new THREE.BoxGeometry(5.2, 3.6, 4.4), plaster);
    body.position.y = 1.8;
    body.castShadow = true;
    body.receiveShadow = true;
    cabin.add(body);
    const cabinRoof = new THREE.Mesh(new THREE.ConeGeometry(4.4, 2.6, 4), roofBlue);
    cabinRoof.position.y = 4.9;
    cabinRoof.rotation.y = Math.PI / 4;
    cabinRoof.castShadow = true;
    cabin.add(cabinRoof);
    const door = new THREE.Mesh(new THREE.BoxGeometry(1.2, 2.1, 0.2), darkWood);
    door.position.set(0, 1.05, 2.2);
    cabin.add(door);
    const win = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.0, 0.2), warmWindow);
    win.position.set(1.5, 2.1, 2.2);
    cabin.add(win);
    outpost.add(cabin);

    this.group.add(outpost);
    this.obstacles.push({ x: tx - 2.5, z: tz - 2.5, r: 2.8 });
    this.obstacles.push({ x: tx + 4.5, z: tz + 2.5, r: 3.1 });
  }

  _buildSakuraShrine() {
    // Grounded Sakura Torii Shrine on the flattened terrace at (-32, 24)
    const sx = -32;
    const sz = 24;
    const sy = getArenaTerrainHeight(sx, sz);
    const g = new THREE.Group();
    g.position.set(sx, sy, sz);
    g.rotation.y = 0.65;

    const red = new THREE.MeshStandardMaterial({ color: 0xc92a2a, flatShading: true });
    const black = new THREE.MeshStandardMaterial({ color: 0x1b1d24, flatShading: true });
    const stone = new THREE.MeshStandardMaterial({ color: 0x7b8799, flatShading: true });

    const pad = new THREE.Mesh(new THREE.CylinderGeometry(7.2, 8.2, 1.2, 8), stone);
    pad.position.y = -0.5;
    pad.receiveShadow = true;
    g.add(pad);

    for (const ox of [-3.2, 3.2]) {
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.38, 6.2, 8), red);
      col.position.set(ox, 3.0, 0);
      col.castShadow = true;
      g.add(col);
    }
    const bar1 = new THREE.Mesh(new THREE.BoxGeometry(7.8, 0.4, 0.4), red);
    bar1.position.y = 5.0;
    g.add(bar1);
    const bar2 = new THREE.Mesh(new THREE.BoxGeometry(9.0, 0.55, 0.65), black);
    bar2.position.y = 6.1;
    g.add(bar2);

    const crystal = createCrystal(1.8, 0xff8fab);
    crystal.position.set(0, 0.05, -2.5);
    g.add(crystal);

    this.group.add(g);
    this.obstacles.push({ x: sx, z: sz - 1.5, r: 1.4 });
  }

  _buildCrystalOutcrop() {
    // Dramatic Crystal Cluster Landmark on the eastern hill (62, -22)
    const cx = 62;
    const cz = -22;
    const cy = getArenaTerrainHeight(cx, cz);
    const g = new THREE.Group();
    g.position.set(cx, cy - 0.5, cz);

    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const rock = createRock(1.8 + (i % 2) * 0.7);
      rock.position.set(Math.cos(a) * 4.5, 0.6, Math.sin(a) * 4.5);
      g.add(rock);
    }
    const big = createCrystal(3.2, 0x5cf2ff);
    g.add(big);
    const side = createCrystal(2.1, 0xc77dff);
    side.position.set(2.4, 0, -1.6);
    side.rotation.y = 1.2;
    g.add(side);

    this.group.add(g);
    this.obstacles.push({ x: cx, z: cz, r: 3.4 });
  }

  _buildProps() {
    let seed = 8831;
    const rand = () => {
      seed = (seed * 16807) % 2147483647;
      return (seed - 1) / 2147483646;
    };

    const isClearZone = (x, z) => {
      if (Math.hypot(x, z) < 23) return false;
      if (Math.hypot(x - this.returnPortalPos.x, z - this.returnPortalPos.z) < 12) return false;
      if (Math.abs(x - getRiverCenterX(z)) < 11) return false;
      if (Math.hypot(x + 38, z + 20) < 15) return false;
      if (Math.hypot(x + 32, z - 24) < 12) return false;
      if (Math.hypot(x - 62, z + 22) < 10) return false;
      return true;
    };

    // Grounded Pine & Sakura Forests
    for (let i = 0; i < 96; i++) {
      const angle = rand() * Math.PI * 2;
      const dist = 24 + rand() * (ARENA_RADIUS - 32);
      const x = Math.cos(angle) * dist;
      const z = Math.sin(angle) * dist;
      if (!isClearZone(x, z)) continue;

      const y = getArenaTerrainHeight(x, z);
      if (y < 0.25) continue;
      const scale = 0.88 + rand() * 0.82;
      const isSakura = (x < -10 && z > 4 && rand() < 0.65) || rand() < 0.14;
      const tree = isSakura ? createSakuraTree(scale) : createPineTree(scale);
      tree.position.set(x, y - 0.35, z); // Deeply rooted — zero floating trunks!
      tree.rotation.y = rand() * Math.PI * 2;
      this.group.add(tree);
      this.obstacles.push({ x, z, r: 0.65 * scale });
    }

    // Grounded Rocks
    for (let i = 0; i < 50; i++) {
      const a = rand() * Math.PI * 2;
      const d = 22 + rand() * (ARENA_RADIUS - 28);
      const x = Math.cos(a) * d;
      const z = Math.sin(a) * d;
      if (!isClearZone(x, z)) continue;
      const y = getArenaTerrainHeight(x, z);
      const scale = 0.75 + rand() * 1.25;
      const rock = createRock(scale);
      rock.position.set(x, y + scale * 0.05, z);
      rock.rotation.set(rand() * 0.4, rand() * 3, rand() * 0.4);
      this.group.add(rock);
      if (scale > 1.25) this.obstacles.push({ x, z, r: scale * 0.9 });
    }

    // Grounded Crystals & Blue Mushrooms
    for (let i = 0; i < 28; i++) {
      const a = rand() * Math.PI * 2;
      const d = 22 + rand() * (ARENA_RADIUS - 30);
      const x = Math.cos(a) * d;
      const z = Math.sin(a) * d;
      if (!isClearZone(x, z)) continue;
      const y = getArenaTerrainHeight(x, z);
      if (y < 0.2) continue;
      const crys = createCrystal(0.8 + rand() * 0.8, i % 3 === 0 ? 0xc77dff : 0x63f0ff);
      crys.position.set(x, y - 0.18, z);
      crys.rotation.y = rand() * Math.PI * 2;
      this.group.add(crys);
    }

    for (let i = 0; i < 34; i++) {
      const a = rand() * Math.PI * 2;
      const d = 19 + rand() * (ARENA_RADIUS - 25);
      const x = Math.cos(a) * d;
      const z = Math.sin(a) * d;
      if (!isClearZone(x, z)) continue;
      const y = getArenaTerrainHeight(x, z);
      if (y < 0.2) continue;
      const mush = createBlueMushroom(0.75 + rand() * 0.6);
      mush.position.set(x, y - 0.12, z);
      this.group.add(mush);
    }

    // Grass Tufts (never placed in water)
    const bladeGeo = new THREE.ConeGeometry(0.16, 0.58, 3);
    const bladeMat = new THREE.MeshStandardMaterial({ color: 0x3b7a2a, flatShading: true });
    const grassCount = 300;
    const inst = new THREE.InstancedMesh(bladeGeo, bladeMat, grassCount);
    const dummy = new THREE.Object3D();
    let placed = 0;
    for (let i = 0; i < grassCount * 2 && placed < grassCount; i++) {
      const a = rand() * Math.PI * 2;
      const d = 20 + rand() * (ARENA_RADIUS - 26);
      const x = Math.cos(a) * d;
      const z = Math.sin(a) * d;
      if (Math.abs(x - getRiverCenterX(z)) < 9.5) continue;
      const y = getArenaTerrainHeight(x, z);
      if (y < 0.2) continue;
      dummy.position.set(x, y + 0.15, z);
      dummy.rotation.y = rand() * Math.PI;
      const s = 0.7 + rand() * 0.9;
      dummy.scale.set(s, s, s);
      dummy.updateMatrix();
      inst.setMatrixAt(placed++, dummy.matrix);
    }
    inst.count = placed;
    this.group.add(inst);
  }

  _buildJumpPads() {
    const padCoords = [
      [18, 26],
      [-20, 14],
      [0, -28],
      [-42, -4],
      [48, -18],
    ];
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x22334d, flatShading: true });
    const glowMat = new THREE.MeshStandardMaterial({ color: 0x45f2c2, emissive: 0x20d8a5, emissiveIntensity: 1.2, flatShading: true });

    for (const [x, z] of padCoords) {
      const y = getArenaTerrainHeight(x, z);
      const pad = new THREE.Group();
      pad.position.set(x, y - 0.15, z);

      const base = new THREE.Mesh(new THREE.CylinderGeometry(2.3, 2.7, 0.75, 8), baseMat);
      base.position.y = 0.25;
      pad.add(base);

      const ring = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 1.8, 0.55, 8), glowMat);
      ring.position.y = 0.42;
      pad.add(ring);

      const floatRing = new THREE.Mesh(
        new THREE.TorusGeometry(1.65, 0.09, 5, 14),
        new THREE.MeshBasicMaterial({ color: 0x99ffe0 })
      );
      floatRing.rotation.x = Math.PI / 2;
      floatRing.position.y = 1.05;
      pad.add(floatRing);

      this.group.add(pad);
      this.jumpPads.push({ position: new THREE.Vector3(x, y, z), floatRing, radius: 2.4 });
    }
  }

  _buildReturnPortal() {
    const py = getArenaTerrainHeight(this.returnPortalPos.x, this.returnPortalPos.z);
    this.returnPortalPos.y = py;

    // Grounded stone terrace under Return Portal
    const terrace = new THREE.Mesh(
      new THREE.CylinderGeometry(7.2, 8.4, 1.4, 10),
      new THREE.MeshStandardMaterial({ color: 0x6f7c8f, flatShading: true })
    );
    terrace.position.set(this.returnPortalPos.x, py - 0.6, this.returnPortalPos.z);
    terrace.receiveShadow = true;
    this.group.add(terrace);

    this.returnPortalMesh = createPortalMesh(0xffd43b, 0xffffff, 'RETOUR AU DOJO', 'Changer de pouvoir ou de mode (touche T)');
    this.returnPortalMesh.position.copy(this.returnPortalPos);
    this.returnPortalMesh.rotation.y = Math.PI;
    this.group.add(this.returnPortalMesh);
  }

  _buildSkyIslands() {
    const rockMat = new THREE.MeshStandardMaterial({ color: 0x525d6e, flatShading: true });
    const grassMat = new THREE.MeshStandardMaterial({ color: 0x58a641, flatShading: true });

    const spots = [
      [162, 24, -65, 20],
      [-165, 32, -88, 24],
      [-150, 18, 98, 18],
      [152, 28, 108, 22],
      [8, 44, -172, 26],
    ];
    for (const [x, y, z, r] of spots) {
      const isl = new THREE.Group();
      isl.position.set(x, y, z);
      const cone = new THREE.Mesh(new THREE.ConeGeometry(r, r * 1.3, 7), rockMat);
      cone.rotation.x = Math.PI;
      cone.position.y = -r * 0.65;
      isl.add(cone);

      const cap = new THREE.Mesh(new THREE.CylinderGeometry(r * 1.02, r * 0.95, 2.4, 7), grassMat);
      isl.add(cap);

      const tree = createPineTree(1.25);
      tree.position.set(r * 0.25, 0.9, 0);
      isl.add(tree);

      const crys = createCrystal(2.0, 0x63f0ff);
      crys.position.set(-r * 0.3, 0.9, r * 0.15);
      isl.add(crys);

      isl.userData.baseY = y;
      isl.userData.phase = Math.random() * 6;
      this.group.add(isl);
      this.skyIslands.push(isl);
    }
  }

  _buildCloudsAndBirds() {
    // Bright, sunlit fluffy cartoon clouds — never dark grey undersides
    const cloudMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0xfff4ea,
      emissiveIntensity: 0.55,
      flatShading: true,
      roughness: 1,
      transparent: true,
      opacity: 0.94,
    });

    for (let i = 0; i < 22; i++) {
      const cloud = new THREE.Group();
      const puffs = 3 + (i % 3);
      for (let p = 0; p < puffs; p++) {
        const m = new THREE.Mesh(new THREE.DodecahedronGeometry(4.2 + (p % 2) * 1.8, 0), cloudMat);
        m.position.set((p - 1) * 4.4, (p % 2) * 1.0, (p % 3 - 1) * 1.4);
        m.scale.set(1.3, 0.58, 1.0);
        cloud.add(m);
      }
      cloud.position.set((Math.random() - 0.5) * 260, 50 + Math.random() * 26, (Math.random() - 0.5) * 260);
      cloud.userData.speed = 1.3 + Math.random() * 1.8;
      this.group.add(cloud);
      this.clouds.push(cloud);
    }

    const birdMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    for (let i = 0; i < 12; i++) {
      const bird = new THREE.Group();
      const body = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.9, 4), birdMat);
      body.rotation.x = Math.PI / 2;
      bird.add(body);
      const leftWing = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.06, 0.35), birdMat);
      leftWing.position.x = -0.45;
      bird.add(leftWing);
      const rightWing = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.06, 0.35), birdMat);
      rightWing.position.x = 0.45;
      bird.add(rightWing);
      bird.userData = {
        leftWing,
        rightWing,
        radius: 28 + (i % 4) * 18,
        height: 26 + (i % 5) * 4.5,
        speed: 0.24 + (i % 3) * 0.08,
        angle: (i / 12) * Math.PI * 2,
      };
      this.group.add(bird);
      this.birds.push(bird);
    }
  }

  _buildFireflies() {
    const count = 130;
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const d = 12 + Math.random() * (ARENA_RADIUS - 20);
      const x = Math.cos(a) * d;
      const z = Math.sin(a) * d;
      pos[i * 3] = x;
      pos[i * 3 + 1] = Math.max(0.5, getArenaTerrainHeight(x, z)) + 1.2 + Math.random() * 5.5;
      pos[i * 3 + 2] = z;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    this.fireflies = new THREE.Points(
      geo,
      new THREE.PointsMaterial({ color: 0xfff08a, size: 0.24, transparent: true, opacity: 0.72 })
    );
    this.group.add(this.fireflies);
  }

  setShadowsEnabled(enabled) {
    if (this.sunLight) this.sunLight.castShadow = enabled;
  }

  resolveObstacles(pos, radius = 0.65) {
    for (const obs of this.obstacles) {
      const dx = pos.x - obs.x;
      const dz = pos.z - obs.z;
      const dist = Math.hypot(dx, dz);
      const minD = obs.r + radius;
      if (dist < minD && dist > 0.0001) {
        pos.x = obs.x + (dx / dist) * minD;
        pos.z = obs.z + (dz / dist) * minD;
      }
    }
  }

  update(t, dt) {
    if (this.returnPortalMesh) this.returnPortalMesh.userData.animate(t);
    if (this.sunHalo) this.sunHalo.rotation.z = t * 0.35;

    this.jumpPads.forEach((pad, idx) => {
      pad.floatRing.position.y = 0.95 + Math.sin(t * 4 + idx) * 0.3;
      pad.floatRing.rotation.z = t * 2.2;
    });

    this.clouds.forEach((c) => {
      c.position.x += c.userData.speed * dt;
      if (c.position.x > 145) c.position.x = -145;
    });

    this.skyIslands.forEach((isl) => {
      isl.position.y = isl.userData.baseY + Math.sin(t * 0.6 + isl.userData.phase) * 1.4;
    });

    this.birds.forEach((b) => {
      const d = b.userData;
      d.angle += d.speed * dt;
      b.position.set(Math.cos(d.angle) * d.radius, d.height + Math.sin(t * 1.5 + d.angle) * 1.4, Math.sin(d.angle) * d.radius);
      b.rotation.y = -d.angle;
      const flap = Math.sin(t * 9 + d.angle * 3) * 0.55;
      d.leftWing.rotation.z = flap;
      d.rightWing.rotation.z = -flap;
    });

    this.waterfallDrops.forEach((drop) => {
      drop.userData.phase = (drop.userData.phase + dt * 0.55) % 1;
      drop.position.y = 0.2 - drop.userData.phase * 35;
    });

    if (this.fireflies) {
      this.fireflies.position.y = Math.sin(t * 0.9) * 0.4;
    }
  }
}
