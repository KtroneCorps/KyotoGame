import * as THREE from 'three';
import { createGunModel, createGliderModel } from './WeaponModels.js';

export const CHARACTER_OPTIONS = {
  skins: [
    { name: 'Doré Classique', hex: 0xf2c96b },
    { name: 'Pêche Clair', hex: 0xffd7b5 },
    { name: 'Beige Doux', hex: 0xf1c27d },
    { name: 'Caramel', hex: 0xc68642 },
    { name: 'Ébène', hex: 0x7a4b2a },
    { name: 'Glace', hex: 0x9cecff },
    { name: 'Ombre', hex: 0x5c4b7d },
    { name: 'Émeraude', hex: 0x7ae582 },
  ],
  shirts: [
    { name: 'Bleu Cubex', hex: 0x2b7de9 },
    { name: 'Rouge Héros', hex: 0xe63946 },
    { name: 'Émeraude', hex: 0x22b573 },
    { name: 'Violet Néon', hex: 0x8338ec },
    { name: 'Orange Feu', hex: 0xff7b00 },
    { name: 'Or Royal', hex: 0xf5b700 },
    { name: 'Rose Cyber', hex: 0xff3b9a },
    { name: 'Noir Ninja', hex: 0x1d222e },
    { name: 'Blanc Pur', hex: 0xeef3fa },
    { name: 'Cyan Glace', hex: 0x17c3e6 },
  ],
  pants: [
    { name: 'Bleu Nuit', hex: 0x243447 },
    { name: 'Charbon', hex: 0x1c1f26 },
    { name: 'Forêt', hex: 0x2f4d36 },
    { name: 'Jean', hex: 0x366599 },
    { name: 'Bordeaux', hex: 0x5e1d2c },
    { name: 'Sable', hex: 0x8f7a5b },
    { name: 'Indigo', hex: 0x2b1e4d },
    { name: 'Neige', hex: 0xd0dce8 },
  ],
  hairs: [
    { name: 'Châtain', hex: 0x5c361a },
    { name: 'Noir Corbeau', hex: 0x1c1c24 },
    { name: 'Blond Solaire', hex: 0xf5cb42 },
    { name: 'Blanc Anime', hex: 0xf0f6ff },
    { name: 'Rouge Flamme', hex: 0xd92b2b },
    { name: 'Bleu Électrique', hex: 0x22a6ff },
    { name: 'Violet Cosmique', hex: 0x9b4dff },
    { name: 'Vert Néon', hex: 0x35e06a },
    { name: 'Rose Sakura', hex: 0xff75b5 },
    { name: 'Or Pur', hex: 0xffb703 },
  ],
  hats: [
    'Épis Classiques',
    'Bandeau Ninja',
    'Casquette Street',
    'Couronne Royale',
    'Chapeau Sorcier',
    'Casque Viking',
    'Casque Cyber',
    'Capuche Assassin',
    'Auréole Angélique',
    'Cornes Démoniaques',
  ],
  faces: [
    'Sourire Joyeux',
    'Déterminé',
    'Lunettes Cool',
    'Yeux Étoilés',
    'Cicatrice Guerrier',
    'Visière Cyber',
  ],
  backs: [
    'Aucun',
    'Cape de Héros',
    'Ailes de Dragon',
    'Ailes d’Ange',
    'Jetpack Cyber',
    'Katana Dorsal',
  ],
};

function flatMat(color, opts = {}) {
  return new THREE.MeshStandardMaterial({
    color,
    flatShading: true,
    roughness: opts.roughness ?? 0.55,
    metalness: opts.metalness ?? 0.14,
    emissive: opts.emissive ?? 0x000000,
    emissiveIntensity: opts.emissiveIntensity ?? 0,
    transparent: opts.transparent ?? false,
    opacity: opts.opacity ?? 1,
    side: opts.side ?? THREE.FrontSide,
  });
}

function makeBox(w, h, d, mat, pos = [0, 0, 0], rot = [0, 0, 0]) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(...pos);
  m.rotation.set(...rot);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}

function makeCyl(rt, rb, h, seg, mat, pos = [0, 0, 0], rot = [0, 0, 0]) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), mat);
  m.position.set(...pos);
  m.rotation.set(...rot);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}

function makeCone(r, h, seg, mat, pos = [0, 0, 0], rot = [0, 0, 0]) {
  const m = new THREE.Mesh(new THREE.ConeGeometry(r, h, seg), mat);
  m.position.set(...pos);
  m.rotation.set(...rot);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}

function makeGem(r, mat, pos = [0, 0, 0], scale = [1, 1, 1], rot = [0, 0, 0]) {
  const m = new THREE.Mesh(new THREE.OctahedronGeometry(r, 0), mat);
  m.position.set(...pos);
  m.scale.set(...scale);
  m.rotation.set(...rot);
  m.castShadow = true;
  return m;
}

/**
 * Helper: builds an ornate wrapped grip + metallic pommel + crossguard collar
 * so every weapon/tool looks genuinely sculpted and handcrafted!
 */
function addWrappedHilt(group, {
  length = 0.65,
  yOffset = -0.35,
  gripColor = 0x4a2c1a,
  wrapColor = 0x261710,
  metalColor = 0xd9a738,
  gemColor = 0x38d9ff,
} = {}) {
  const gripMat = flatMat(gripColor, { roughness: 0.85 });
  const wrapMat = flatMat(wrapColor, { roughness: 0.9 });
  const metalMat = flatMat(metalColor, { metalness: 0.55, roughness: 0.28 });
  const gemMat = flatMat(gemColor, { emissive: gemColor, emissiveIntensity: 1.2 });

  group.add(makeBox(0.11, length, 0.11, gripMat, [0, yOffset, 0]));
  // Leather wrap rings
  const bands = Math.max(3, Math.floor(length / 0.14));
  for (let i = 0; i < bands; i++) {
    const by = yOffset - length * 0.38 + (i / (bands - 1 || 1)) * (length * 0.76);
    group.add(makeBox(0.132, 0.045, 0.132, wrapMat, [0, by, 0], [0, 0, 0.12]));
  }
  // Ornate pommel
  const py = yOffset - length * 0.54;
  group.add(makeBox(0.19, 0.1, 0.19, metalMat, [0, py, 0]));
  group.add(makeGem(0.08, gemMat, [0, py - 0.08, 0]));
  // Upper collar
  group.add(makeBox(0.2, 0.09, 0.2, metalMat, [0, yOffset + length * 0.5, 0]));
}

/**
 * Creates ultra-detailed, multi-part Blockbench-grade 3D weapon/tool models
 * for ALL 20 POWERS! Each model has layered blades/heads, metallic bevels,
 * glowing runes, and bespoke live animations.
 */
export function createPowerModel(powerId) {
  const group = new THREE.Group();
  const animators = [];

  switch (powerId) {
    case 'thunder': {
      // Ornate Runic Storm War-Hammer (Mjolnir-inspired)
      addWrappedHilt(group, { length: 0.85, yOffset: -0.25, metalColor: 0xe6b842, gemColor: 0x38d9ff });
      const steel = flatMat(0x3a4860, { metalness: 0.55, roughness: 0.3 });
      const darkSteel = flatMat(0x1f2838, { metalness: 0.6, roughness: 0.35 });
      const gold = flatMat(0xffd43b, { metalness: 0.55, roughness: 0.25 });
      const glow = flatMat(0x38d9ff, { emissive: 0x38d9ff, emissiveIntensity: 1.5 });

      // Layered beveled hammerhead
      group.add(makeBox(0.84, 0.48, 0.48, steel, [0, 0.45, 0]));
      group.add(makeBox(0.94, 0.38, 0.38, darkSteel, [0, 0.45, 0]));
      group.add(makeBox(0.98, 0.26, 0.26, steel, [0, 0.45, 0]));
      // Gold trim bands
      group.add(makeBox(0.12, 0.52, 0.52, gold, [-0.26, 0.45, 0]));
      group.add(makeBox(0.12, 0.52, 0.52, gold, [0.26, 0.45, 0]));
      // Glowing lightning runes on all faces
      group.add(makeBox(1.0, 0.1, 0.1, glow, [0, 0.45, 0]));
      group.add(makeBox(0.18, 0.51, 0.51, glow, [0, 0.45, 0]));
      group.add(makeGem(0.14, glow, [0, 0.76, 0], [0.8, 1.3, 0.8]));

      // Orbiting electric arcs
      const orbit = new THREE.Group();
      orbit.position.y = 0.45;
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2;
        const arc = makeGem(0.09, i % 2 ? gold : glow, [Math.cos(a) * 0.66, 0, Math.sin(a) * 0.66], [0.5, 1.9, 0.5], [0, a, 0.4]);
        orbit.add(arc);
      }
      group.add(orbit);
      animators.push((t) => {
        orbit.rotation.y = t * 3.8;
        orbit.rotation.x = Math.sin(t * 4) * 0.28;
      });
      break;
    }

    case 'pyro': {
      // Volcanic Molten Greatsword with Obsidian Spine & Blazing Edges
      addWrappedHilt(group, { length: 0.52, yOffset: -0.45, gripColor: 0x2b1814, metalColor: 0x3b2c35, gemColor: 0xff551a });
      const obsidian = flatMat(0x211b24, { metalness: 0.4, roughness: 0.4 });
      const magma = flatMat(0xff551a, { emissive: 0xff3b00, emissiveIntensity: 1.5 });
      const flare = flatMat(0xffd43b, { emissive: 0xffaa00, emissiveIntensity: 1.5 });

      // Winged horned crossguard
      group.add(makeBox(0.68, 0.14, 0.2, obsidian, [0, -0.14, 0]));
      group.add(makeCone(0.1, 0.34, 4, magma, [-0.36, -0.02, 0], [0, 0, 0.55]));
      group.add(makeCone(0.1, 0.34, 4, magma, [0.36, -0.02, 0], [0, 0, -0.55]));
      group.add(makeGem(0.14, flare, [0, -0.14, 0.1], [1, 1, 0.6]));

      // Wide segmented fiery greatsword blade
      group.add(makeBox(0.26, 1.05, 0.08, obsidian, [0, 0.44, 0]));
      group.add(makeBox(0.36, 0.96, 0.045, magma, [0, 0.44, 0]));
      group.add(makeBox(0.1, 0.92, 0.1, flare, [0, 0.44, 0]));
      // Serrated flame teeth
      for (let i = 0; i < 4; i++) {
        const y = 0.08 + i * 0.24;
        group.add(makeCone(0.08, 0.2, 4, flare, [0.22, y, 0], [0, 0, -1.2]));
        group.add(makeCone(0.08, 0.2, 4, flare, [-0.22, y, 0], [0, 0, 1.2]));
      }
      group.add(makeCone(0.22, 0.42, 4, flare, [0, 1.15, 0]));

      const embers = [];
      for (let i = 0; i < 5; i++) {
        const e = makeGem(0.075, i % 2 ? flare : magma);
        group.add(e);
        embers.push(e);
      }
      animators.push((t) => {
        embers.forEach((e, idx) => {
          const cyc = (t * 1.4 + idx * 0.2) % 1;
          e.position.set(Math.sin(t * 4 + idx * 2) * 0.28, -0.1 + cyc * 1.4, Math.cos(t * 3 + idx) * 0.2);
          e.scale.setScalar(1 - cyc * 0.7);
        });
      });
      break;
    }

    case 'cryo': {
      // Crystalline Frost War-Scythe
      addWrappedHilt(group, { length: 1.25, yOffset: -0.05, gripColor: 0x1f3d59, wrapColor: 0x102538, metalColor: 0x9beeff, gemColor: 0x74e8ff });
      const darkIce = flatMat(0x1f6b99, { metalness: 0.35, roughness: 0.2 });
      const ice = flatMat(0x74e8ff, { emissive: 0x3bc9db, emissiveIntensity: 0.95, roughness: 0.12 });
      const bright = flatMat(0xe8fdff, { emissive: 0xaaf5ff, emissiveIntensity: 1.25, roughness: 0.08 });

      // Ornate frost crown at top of staff
      group.add(makeGem(0.18, bright, [0, 0.72, 0], [0.9, 1.4, 0.9]));
      // Multi-segmented sweeping crystalline scythe blade
      group.add(makeBox(0.56, 0.22, 0.08, darkIce, [0.24, 0.64, 0], [0, 0, -0.15]));
      group.add(makeBox(0.54, 0.16, 0.05, ice, [0.26, 0.58, 0], [0, 0, -0.15]));
      group.add(makeBox(0.48, 0.18, 0.07, ice, [0.64, 0.44, 0], [0, 0, -0.62]));
      group.add(makeBox(0.36, 0.12, 0.04, bright, [0.85, 0.18, 0], [0, 0, -1.1]));
      group.add(makeCone(0.1, 0.38, 4, bright, [0.92, -0.06, 0], [0, 0, -2.75]));
      // Back frost spike
      group.add(makeCone(0.09, 0.36, 4, ice, [-0.22, 0.64, 0], [0, 0, 1.45]));

      const flakes = new THREE.Group();
      flakes.position.set(0.35, 0.45, 0);
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2;
        flakes.add(makeGem(0.08, bright, [Math.cos(a) * 0.58, Math.sin(a * 2) * 0.14, Math.sin(a) * 0.58]));
      }
      group.add(flakes);
      animators.push((t) => {
        flakes.rotation.y = -t * 2.5;
        flakes.rotation.z = Math.sin(t * 2) * 0.25;
      });
      break;
    }

    case 'gravity': {
      // Arcane Cosmic Singularity Scepter
      addWrappedHilt(group, { length: 0.92, yOffset: -0.28, gripColor: 0x26153b, metalColor: 0xd4a23d, gemColor: 0xb15cff });
      const gold = flatMat(0xe6b842, { metalness: 0.6, roughness: 0.25 });
      const coreMat = flatMat(0x12041f, { emissive: 0x5c18a8, emissiveIntensity: 0.85 });
      const ring1Mat = flatMat(0xb15cff, { emissive: 0x9d4edd, emissiveIntensity: 1.3 });
      const ring2Mat = flatMat(0xff87eb, { emissive: 0xff70e0, emissiveIntensity: 1.35 });

      // Curved golden cradle arms holding the black hole
      group.add(makeBox(0.08, 0.42, 0.08, gold, [-0.26, 0.38, 0], [0, 0, 0.38]));
      group.add(makeBox(0.08, 0.42, 0.08, gold, [0.26, 0.38, 0], [0, 0, -0.38]));

      const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.28, 0), coreMat);
      core.position.y = 0.62;
      group.add(core);

      const r1 = new THREE.Mesh(new THREE.TorusGeometry(0.44, 0.045, 5, 14), ring1Mat);
      r1.position.y = 0.62;
      group.add(r1);
      const r2 = new THREE.Mesh(new THREE.TorusGeometry(0.58, 0.032, 5, 14), ring2Mat);
      r2.position.y = 0.62;
      group.add(r2);

      animators.push((t) => {
        core.rotation.y = t * 2.0;
        r1.rotation.x = t * 2.6;
        r1.rotation.y = t * 1.4;
        r2.rotation.y = -t * 2.1;
        r2.rotation.z = t * 2.4;
      });
      break;
    }

    case 'wind': {
      // Ornate Jade & Pearl Zephyr War-Fan
      addWrappedHilt(group, { length: 0.45, yOffset: -0.45, gripColor: 0x1a5943, metalColor: 0xffe066, gemColor: 0x63f5b8 });
      const jade = flatMat(0x22c98d, { emissive: 0x169c6a, emissiveIntensity: 0.55 });
      const pearl = flatMat(0xeafff7, { emissive: 0x9ef5d8, emissiveIntensity: 0.7 });
      const gold = flatMat(0xffd43b, { metalness: 0.5 });

      for (let i = -3; i <= 3; i++) {
        const ang = -i * 0.22;
        const blade = new THREE.Group();
        blade.position.y = -0.15;
        blade.rotation.z = ang;
        blade.add(makeBox(0.14, 0.82 - Math.abs(i) * 0.04, 0.035, i % 2 === 0 ? pearl : jade, [0, 0.46, 0]));
        blade.add(makeBox(0.04, 0.88 - Math.abs(i) * 0.04, 0.05, gold, [0, 0.46, 0]));
        blade.add(makeCone(0.075, 0.2, 4, pearl, [0, 0.94 - Math.abs(i) * 0.04, 0]));
        group.add(blade);
      }

      const swirl = new THREE.Group();
      swirl.position.y = 0.35;
      const t1 = new THREE.Mesh(new THREE.TorusGeometry(0.55, 0.03, 4, 12), pearl);
      t1.rotation.x = Math.PI / 2.3;
      swirl.add(t1);
      const t2 = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.025, 4, 12), jade);
      t2.rotation.x = -Math.PI / 3;
      swirl.add(t2);
      group.add(swirl);
      animators.push((t) => {
        swirl.rotation.y = t * 5.2;
      });
      break;
    }

    case 'earth': {
      // Colossal Cracked Granite & Glowing Amber Warhammer
      addWrappedHilt(group, { length: 0.82, yOffset: -0.28, gripColor: 0x4d331f, metalColor: 0x8a6d4b, gemColor: 0xffaa33 });
      const granite = flatMat(0x6e665e, { roughness: 0.92 });
      const darkGranite = flatMat(0x453f39, { roughness: 0.95 });
      const amber = flatMat(0xffaa33, { emissive: 0xff8800, emissiveIntensity: 1.2 });

      const core = new THREE.Mesh(new THREE.DodecahedronGeometry(0.42, 0), granite);
      core.position.y = 0.44;
      core.scale.set(1.35, 0.95, 1.0);
      group.add(core);
      const sideL = new THREE.Mesh(new THREE.DodecahedronGeometry(0.28, 0), darkGranite);
      sideL.position.set(-0.44, 0.44, 0);
      group.add(sideL);
      const sideR = new THREE.Mesh(new THREE.DodecahedronGeometry(0.28, 0), darkGranite);
      sideR.position.set(0.44, 0.44, 0);
      group.add(sideR);

      // Protruding amber crystals
      group.add(makeGem(0.16, amber, [0, 0.82, 0], [0.7, 1.7, 0.7]));
      group.add(makeGem(0.12, amber, [0.34, 0.72, 0.12], [0.6, 1.5, 0.6], [0, 0, -0.45]));
      group.add(makeGem(0.12, amber, [-0.34, 0.72, -0.12], [0.6, 1.5, 0.6], [0, 0, 0.45]));

      const rocks = new THREE.Group();
      rocks.position.y = 0.44;
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2;
        const p = new THREE.Mesh(new THREE.DodecahedronGeometry(0.08, 0), granite);
        p.position.set(Math.cos(a) * 0.72, (i % 2 ? 0.14 : -0.14), Math.sin(a) * 0.72);
        rocks.add(p);
      }
      group.add(rocks);
      animators.push((t) => { rocks.rotation.y = t * 1.6; });
      break;
    }

    case 'shadow': {
      // Twin Curved Phantom Assassin Daggers + Shadow Wisps
      const obs = flatMat(0x160d24, { metalness: 0.6, roughness: 0.3 });
      const glow = flatMat(0x9b5de5, { emissive: 0x7c4dff, emissiveIntensity: 1.4 });
      const silver = flatMat(0x7c859e, { metalness: 0.65, roughness: 0.25 });

      const buildBlade = (ox, tilt) => {
        const d = new THREE.Group();
        d.position.set(ox, 0, 0);
        d.rotation.z = tilt;
        addWrappedHilt(d, { length: 0.36, yOffset: -0.35, gripColor: 0x1c1229, metalColor: 0x5c3699, gemColor: 0x9b5de5 });
        d.add(makeBox(0.32, 0.08, 0.12, silver, [0, -0.14, 0]));
        d.add(makeBox(0.15, 0.74, 0.04, obs, [0, 0.28, 0]));
        d.add(makeBox(0.05, 0.76, 0.06, glow, [0.06, 0.28, 0]));
        d.add(makeCone(0.09, 0.3, 4, glow, [0, 0.78, 0]));
        return d;
      };
      group.add(buildBlade(-0.22, 0.2));
      group.add(buildBlade(0.22, -0.2));

      const wisps = [];
      for (let i = 0; i < 4; i++) {
        const w = makeBox(0.1, 0.1, 0.1, i % 2 ? glow : obs);
        group.add(w);
        wisps.push(w);
      }
      animators.push((t) => {
        wisps.forEach((w, i) => {
          const a = t * 2.8 + i * 1.57;
          w.position.set(Math.cos(a) * 0.52, 0.25 + Math.sin(t * 3 + i) * 0.22, Math.sin(a) * 0.52);
          w.rotation.set(t * 2, t * 2, 0);
        });
      });
      break;
    }

    case 'light': {
      // Radiant Angelic Solar Greatsword with Spinning Halo
      addWrappedHilt(group, { length: 0.54, yOffset: -0.44, gripColor: 0xf0ead6, wrapColor: 0xd4a23d, metalColor: 0xffd43b, gemColor: 0xffffff });
      const gold = flatMat(0xffcc33, { metalness: 0.55, emissive: 0xffaa00, emissiveIntensity: 0.45 });
      const sun = flatMat(0xfff6b3, { emissive: 0xffe066, emissiveIntensity: 1.5 });
      const ivory = flatMat(0xffffff, { emissive: 0xfff3cc, emissiveIntensity: 0.55 });

      // Winged golden crossguard
      group.add(makeBox(0.76, 0.12, 0.16, gold, [0, -0.14, 0]));
      group.add(makeBox(0.28, 0.16, 0.08, ivory, [-0.36, -0.02, 0], [0, 0, 0.5]));
      group.add(makeBox(0.28, 0.16, 0.08, ivory, [0.36, -0.02, 0], [0, 0, -0.5]));
      // Blade
      group.add(makeBox(0.24, 1.05, 0.055, ivory, [0, 0.45, 0]));
      group.add(makeBox(0.1, 1.08, 0.08, sun, [0, 0.45, 0]));
      group.add(makeCone(0.17, 0.38, 4, sun, [0, 1.14, 0]));

      // Spinning solar halo behind crossguard
      const halo = new THREE.Group();
      halo.position.set(0, -0.14, -0.08);
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2;
        halo.add(makeCone(0.05, 0.22, 4, gold, [Math.cos(a) * 0.38, Math.sin(a) * 0.38, 0], [0, 0, a - Math.PI / 2]));
      }
      group.add(halo);
      animators.push((t) => { halo.rotation.z = t * 2.2; });
      break;
    }

    case 'poison': {
      // Alchemist Acid Lantern-Staff with Bubbling Toxic Vial
      addWrappedHilt(group, { length: 0.9, yOffset: -0.28, gripColor: 0x2a3b26, metalColor: 0x5c7054, gemColor: 0x5df249 });
      const iron = flatMat(0x2c3630, { metalness: 0.5, roughness: 0.45 });
      const glass = flatMat(0xd6ffe3, { transparent: true, opacity: 0.48, roughness: 0.1 });
      const acid = flatMat(0x52ff3b, { emissive: 0x39e622, emissiveIntensity: 1.4 });

      // Cage frame holding bubbling flask
      group.add(makeBox(0.54, 0.08, 0.54, iron, [0, 0.2, 0]));
      group.add(makeBox(0.54, 0.08, 0.54, iron, [0, 0.78, 0]));
      for (const sx of [-0.22, 0.22]) {
        for (const sz of [-0.22, 0.22]) {
          group.add(makeBox(0.06, 0.58, 0.06, iron, [sx, 0.49, sz]));
        }
      }
      group.add(makeBox(0.42, 0.5, 0.42, glass, [0, 0.49, 0]));
      group.add(makeBox(0.34, 0.36, 0.34, acid, [0, 0.43, 0]));
      group.add(makeCone(0.18, 0.26, 4, iron, [0, 0.94, 0]));

      const bubbles = [];
      for (let i = 0; i < 4; i++) {
        const b = new THREE.Mesh(new THREE.IcosahedronGeometry(0.075, 0), acid);
        group.add(b);
        bubbles.push(b);
      }
      animators.push((t) => {
        bubbles.forEach((b, i) => {
          const cyc = (t * 1.1 + i * 0.25) % 1;
          b.position.set(Math.sin(t * 2 + i * 2) * 0.3, 0.4 + cyc * 0.75, Math.cos(t * 2 + i * 2) * 0.3);
          b.scale.setScalar(1 - cyc * 0.55);
        });
      });
      break;
    }

    case 'chrono': {
      // Arcane Brass Clockwork Chronometer-Staff
      addWrappedHilt(group, { length: 0.75, yOffset: -0.34, gripColor: 0x26384d, metalColor: 0xd4a23d, gemColor: 0x34e8d6 });
      const brass = flatMat(0xd9a841, { metalness: 0.6, roughness: 0.3 });
      const dial = flatMat(0x10273d, { emissive: 0x12788a, emissiveIntensity: 0.75 });
      const cyan = flatMat(0x34e8d6, { emissive: 0x34e8d6, emissiveIntensity: 1.45 });

      group.add(makeCyl(0.46, 0.46, 0.14, 10, brass, [0, 0.48, 0], [Math.PI / 2, 0, 0]));
      group.add(makeCyl(0.37, 0.37, 0.16, 10, dial, [0, 0.48, 0], [Math.PI / 2, 0, 0]));

      const handL = new THREE.Group();
      handL.position.set(0, 0.48, 0.1);
      handL.add(makeBox(0.04, 0.28, 0.03, cyan, [0, 0.12, 0]));
      group.add(handL);

      const handS = new THREE.Group();
      handS.position.set(0, 0.48, 0.11);
      handS.add(makeBox(0.05, 0.18, 0.03, brass, [0, 0.08, 0]));
      group.add(handS);

      const gear = new THREE.Group();
      gear.position.y = 0.48;
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * Math.PI * 2;
        gear.add(makeBox(0.1, 0.13, 0.07, brass, [Math.cos(a) * 0.54, Math.sin(a) * 0.54, 0], [0, 0, a]));
      }
      group.add(gear);
      animators.push((t) => {
        handL.rotation.z = -t * 4.2;
        handS.rotation.z = -t * 0.8;
        gear.rotation.z = t * 1.2;
      });
      break;
    }

    case 'cyber': {
      // Sleek Neon Plasma Katana with Holographic Ring
      addWrappedHilt(group, { length: 0.46, yOffset: -0.46, gripColor: 0x161d2b, wrapColor: 0x29f0ff, metalColor: 0x263247, gemColor: 0xff3b9a });
      const tech = flatMat(0x1b2436, { metalness: 0.7, roughness: 0.25 });
      const pink = flatMat(0xff3b9a, { emissive: 0xff2a88, emissiveIntensity: 1.5 });
      const cyan = flatMat(0x29f0ff, { emissive: 0x00e5ff, emissiveIntensity: 1.45 });

      group.add(makeBox(0.4, 0.09, 0.2, tech, [0, -0.2, 0]));
      group.add(makeBox(0.44, 0.035, 0.22, cyan, [0, -0.2, 0]));
      // Angled energy katana blade
      group.add(makeBox(0.12, 1.15, 0.04, tech, [-0.03, 0.42, 0]));
      group.add(makeBox(0.08, 1.18, 0.055, pink, [0.04, 0.44, 0]));
      group.add(makeBox(0.035, 1.2, 0.065, cyan, [0.09, 0.45, 0]));
      group.add(makeCone(0.09, 0.28, 4, pink, [0.03, 1.14, 0], [0, 0, -0.15]));

      const holo = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.025, 4, 12), cyan);
      holo.rotation.x = Math.PI / 2;
      group.add(holo);
      animators.push((t) => {
        holo.rotation.z = t * 4.5;
        holo.position.y = 0.25 + Math.sin(t * 4.2) * 0.32;
      });
      break;
    }

    case 'titan': {
      // Massive Runic Bronze & Gold Champion Gauntlet
      const bronze = flatMat(0xb86d24, { metalness: 0.55, roughness: 0.3 });
      const darkBronze = flatMat(0x5c3614, { metalness: 0.5, roughness: 0.4 });
      const gold = flatMat(0xffd43b, { metalness: 0.6, emissive: 0xffaa00, emissiveIntensity: 0.45 });
      const rune = flatMat(0xff6b00, { emissive: 0xff5500, emissiveIntensity: 1.5 });

      group.add(makeBox(0.56, 0.34, 0.54, darkBronze, [0, -0.34, 0]));
      group.add(makeBox(0.62, 0.14, 0.6, gold, [0, -0.16, 0]));
      group.add(makeBox(0.72, 0.64, 0.66, bronze, [0, 0.22, 0]));
      group.add(makeBox(0.78, 0.18, 0.72, gold, [0, 0.44, 0]));
      group.add(makeBox(0.28, 0.28, 0.72, rune, [0, 0.18, 0]));
      for (let i = -1; i <= 1; i++) {
        group.add(makeCone(0.11, 0.28, 4, gold, [i * 0.24, 0.64, 0.22], [0.25, 0, 0]));
      }
      animators.push((t) => {
        group.scale.setScalar(1 + Math.sin(t * 4.5) * 0.04);
      });
      break;
    }

    case 'aqua': {
      // Abyssal Coral & Sapphire Royal Trident
      addWrappedHilt(group, { length: 1.05, yOffset: -0.22, gripColor: 0x10436b, metalColor: 0x3bc9ff, gemColor: 0x88f3ff });
      const gold = flatMat(0xf5c842, { metalness: 0.55, roughness: 0.25 });
      const aqua = flatMat(0x1da1ff, { emissive: 0x0d7ce6, emissiveIntensity: 1.0 });
      const foam = flatMat(0xa6f7ff, { emissive: 0x6ceeff, emissiveIntensity: 1.3 });

      // Crossbar + central jewel
      group.add(makeBox(0.72, 0.12, 0.14, gold, [0, 0.35, 0]));
      group.add(makeGem(0.14, foam, [0, 0.35, 0.08]));
      // 3 Trident prongs
      group.add(makeBox(0.1, 0.72, 0.08, aqua, [0, 0.74, 0]));
      group.add(makeCone(0.1, 0.34, 4, foam, [0, 1.24, 0]));
      group.add(makeBox(0.08, 0.52, 0.07, aqua, [-0.32, 0.64, 0], [0, 0, 0.08]));
      group.add(makeCone(0.08, 0.26, 4, foam, [-0.35, 0.99, 0], [0, 0, 0.1]));
      group.add(makeBox(0.08, 0.52, 0.07, aqua, [0.32, 0.64, 0], [0, 0, -0.08]));
      group.add(makeCone(0.08, 0.26, 4, foam, [0.35, 0.99, 0], [0, 0, -0.1]));

      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.03, 5, 14), foam);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = 0.35;
      group.add(ring);
      animators.push((t) => {
        ring.rotation.z = t * 3.2;
        ring.position.y = 0.35 + Math.sin(t * 4) * 0.12;
      });
      break;
    }

    case 'nature': {
      // Blooming Druidic Blossom Staff
      addWrappedHilt(group, { length: 1.05, yOffset: -0.22, gripColor: 0x5c3a21, wrapColor: 0x2c8a4b, metalColor: 0x38d97c, gemColor: 0xff8fab });
      const bark = flatMat(0x6e472b, { roughness: 0.9 });
      const leaf = flatMat(0x38d97c, { emissive: 0x1fb35d, emissiveIntensity: 0.5 });
      const petal = flatMat(0xff8fab, { emissive: 0xff5c8a, emissiveIntensity: 0.8 });
      const pollen = flatMat(0xffe066, { emissive: 0xffd43b, emissiveIntensity: 1.3 });

      // Twisted wooden crown
      group.add(makeBox(0.12, 0.42, 0.12, bark, [-0.18, 0.48, 0], [0, 0, 0.42]));
      group.add(makeBox(0.12, 0.42, 0.12, bark, [0.18, 0.48, 0], [0, 0, -0.42]));
      // Floating blooming flower core
      const flower = new THREE.Group();
      flower.position.y = 0.68;
      flower.add(makeGem(0.16, pollen));
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        flower.add(makeGem(0.12, i % 2 ? petal : leaf, [Math.cos(a) * 0.28, Math.sin(a) * 0.28, 0], [1.2, 0.6, 0.5], [0, 0, a]));
      }
      group.add(flower);
      animators.push((t) => {
        flower.rotation.z = t * 1.8;
        flower.position.y = 0.68 + Math.sin(t * 3.5) * 0.07;
      });
      break;
    }

    case 'magma': {
      // Double-Bladed Obsidian & Lava Battleaxe
      addWrappedHilt(group, { length: 1.05, yOffset: -0.18, gripColor: 0x261d1c, metalColor: 0x453533, gemColor: 0xff4221 });
      const obs = flatMat(0x1f1921, { metalness: 0.45, roughness: 0.45 });
      const lava = flatMat(0xff4221, { emissive: 0xff2b00, emissiveIntensity: 1.45 });
      const ember = flatMat(0xffae2b, { emissive: 0xff9500, emissiveIntensity: 1.3 });

      group.add(makeBox(0.24, 0.56, 0.24, obs, [0, 0.46, 0]));
      // Left & right bearded axe blades
      for (const s of [-1, 1]) {
        group.add(makeBox(0.46, 0.56, 0.08, obs, [s * 0.34, 0.46, 0], [0, 0, s * 0.15]));
        group.add(makeBox(0.14, 0.68, 0.055, lava, [s * 0.58, 0.46, 0]));
        group.add(makeCone(0.12, 0.28, 4, ember, [s * 0.55, 0.82, 0], [0, 0, -s * 0.6]));
        group.add(makeCone(0.12, 0.28, 4, ember, [s * 0.55, 0.1, 0], [0, 0, s * 2.5]));
      }
      group.add(makeCone(0.14, 0.34, 4, lava, [0, 0.9, 0]));
      animators.push((t) => {
        lava.emissiveIntensity = 1.2 + Math.sin(t * 6) * 0.35;
      });
      break;
    }

    case 'blood': {
      // Crimson Vampire Great-Scythe
      addWrappedHilt(group, { length: 1.15, yOffset: -0.12, gripColor: 0x260912, wrapColor: 0x6b0f24, metalColor: 0x3b1721, gemColor: 0xe62249 });
      const dark = flatMat(0x1c0d14, { metalness: 0.55, roughness: 0.3 });
      const crimson = flatMat(0xe62249, { emissive: 0xd90429, emissiveIntensity: 1.35 });
      const ruby = flatMat(0xff6b8a, { emissive: 0xff3b6b, emissiveIntensity: 1.4 });

      group.add(makeGem(0.18, ruby, [0, 0.66, 0], [0.9, 1.3, 0.9]));
      group.add(makeBox(0.62, 0.2, 0.07, dark, [0.28, 0.62, 0], [0, 0, -0.18]));
      group.add(makeBox(0.6, 0.1, 0.05, crimson, [0.3, 0.52, 0], [0, 0, -0.18]));
      group.add(makeBox(0.46, 0.16, 0.06, crimson, [0.7, 0.38, 0], [0, 0, -0.78]));
      group.add(makeCone(0.1, 0.42, 4, ruby, [0.85, 0.06, 0], [0, 0, -2.7]));
      // Bat wing ornament
      group.add(makeCone(0.14, 0.38, 3, crimson, [-0.24, 0.66, 0], [0, 0, 1.35]));

      const drops = [];
      for (let i = 0; i < 4; i++) {
        const d = makeGem(0.065, crimson);
        group.add(d);
        drops.push(d);
      }
      animators.push((t) => {
        drops.forEach((d, i) => {
          const a = t * 3 + i * 1.57;
          d.position.set(0.35 + Math.cos(a) * 0.45, 0.4 + Math.sin(a * 2) * 0.18, Math.sin(a) * 0.35);
        });
      });
      break;
    }

    case 'sonic': {
      // Twin Supersonic Energy Tonfa-Blades
      const navy = flatMat(0x162b4d, { metalness: 0.6, roughness: 0.25 });
      const cyan = flatMat(0x00f2fe, { emissive: 0x00d9ff, emissiveIntensity: 1.5 });
      const gold = flatMat(0xffd43b, { emissive: 0xffbb00, emissiveIntensity: 1.0 });

      addWrappedHilt(group, { length: 0.44, yOffset: -0.44, gripColor: 0x162b4d, metalColor: 0xffd43b, gemColor: 0x00f2fe });
      // Twin parallel lightning speed blades
      group.add(makeBox(0.44, 0.12, 0.16, navy, [0, -0.18, 0]));
      group.add(makeBox(0.09, 1.0, 0.05, cyan, [-0.12, 0.38, 0], [0, 0, 0.08]));
      group.add(makeBox(0.09, 1.0, 0.05, cyan, [0.12, 0.38, 0], [0, 0, -0.08]));
      group.add(makeCone(0.07, 0.32, 4, gold, [-0.16, 1.02, 0], [0, 0, 0.08]));
      group.add(makeCone(0.07, 0.32, 4, gold, [0.16, 1.02, 0], [0, 0, -0.08]));

      const rings = [];
      for (let i = 0; i < 3; i++) {
        const r = new THREE.Mesh(new THREE.TorusGeometry(0.26 + i * 0.06, 0.022, 4, 12), i === 1 ? gold : cyan);
        r.rotation.x = Math.PI / 2;
        group.add(r);
        rings.push(r);
      }
      animators.push((t) => {
        rings.forEach((r, i) => {
          const cyc = (t * 2.5 + i * 0.33) % 1;
          r.position.y = -0.1 + cyc * 1.1;
          r.scale.setScalar(1.2 - cyc * 0.6);
        });
      });
      break;
    }

    case 'crystal': {
      // Prismatic Diamond Halberd-Lance
      addWrappedHilt(group, { length: 0.92, yOffset: -0.32, gripColor: 0x263459, metalColor: 0xb8d0ff, gemColor: 0x5cf2ff });
      const diamond = flatMat(0x5cf2ff, { emissive: 0x29dfff, emissiveIntensity: 1.1, roughness: 0.1 });
      const prism = flatMat(0xe0aaff, { emissive: 0xc77dff, emissiveIntensity: 1.0, roughness: 0.1 });
      const white = flatMat(0xf0fdff, { emissive: 0xbdf8ff, emissiveIntensity: 1.3, roughness: 0.08 });

      group.add(makeGem(0.24, prism, [0, 0.26, 0], [1.1, 0.9, 1.1]));
      group.add(makeCone(0.2, 1.05, 6, diamond, [0, 0.88, 0]));
      group.add(makeGem(0.14, white, [-0.26, 0.42, 0], [0.6, 1.6, 0.6], [0, 0, 0.5]));
      group.add(makeGem(0.14, white, [0.26, 0.42, 0], [0.6, 1.6, 0.6], [0, 0, -0.5]));

      const shards = new THREE.Group();
      shards.position.y = 0.62;
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2;
        shards.add(makeGem(0.08, i % 2 ? prism : white, [Math.cos(a) * 0.46, 0, Math.sin(a) * 0.46], [0.6, 1.5, 0.6]));
      }
      group.add(shards);
      animators.push((t) => { shards.rotation.y = t * 2.6; });
      break;
    }

    case 'dragon': {
      // Golden Imperial Dragon Halberd with Winged Blade & Flame Core
      addWrappedHilt(group, { length: 0.95, yOffset: -0.28, gripColor: 0x591515, wrapColor: 0xffb703, metalColor: 0xffb703, gemColor: 0xff5500 });
      const gold = flatMat(0xffaa14, { metalness: 0.6, roughness: 0.25 });
      const crimson = flatMat(0xc9182b, { roughness: 0.45 });
      const fire = flatMat(0xffe047, { emissive: 0xff8800, emissiveIntensity: 1.45 });

      // Dragon collar wings
      group.add(makeBox(0.68, 0.14, 0.18, gold, [0, 0.26, 0]));
      group.add(makeBox(0.32, 0.22, 0.08, crimson, [-0.36, 0.4, 0], [0, 0, 0.55]));
      group.add(makeBox(0.32, 0.22, 0.08, crimson, [0.36, 0.4, 0], [0, 0, -0.55]));
      // Fiery dragon core + blade
      const core = makeGem(0.18, fire, [0, 0.46, 0]);
      group.add(core);
      group.add(makeBox(0.18, 0.88, 0.07, gold, [0, 0.82, 0]));
      group.add(makeCone(0.18, 0.42, 4, fire, [0, 1.38, 0]));

      animators.push((t) => {
        core.rotation.y = t * 4;
        core.scale.setScalar(1 + Math.sin(t * 7) * 0.14);
      });
      break;
    }

    case 'void': {
      // Dimensional Void Greatsword with Floating Rift Segments
      addWrappedHilt(group, { length: 0.52, yOffset: -0.46, gripColor: 0x10051f, metalColor: 0x4b1a82, gemColor: 0xc77dff });
      const darkVoid = flatMat(0x0d031a, { emissive: 0x2f0b59, emissiveIntensity: 0.8 });
      const purple = flatMat(0x9b30ff, { emissive: 0x9b30ff, emissiveIntensity: 1.5 });
      const bright = flatMat(0xe7c6ff, { emissive: 0xd08aff, emissiveIntensity: 1.4 });

      group.add(makeBox(0.66, 0.12, 0.18, darkVoid, [0, -0.15, 0]));
      group.add(makeGem(0.15, purple, [0, -0.15, 0.08]));

      // Floating disconnected dimensional blade shards!
      const segs = [];
      for (let i = 0; i < 4; i++) {
        const seg = new THREE.Group();
        seg.position.y = 0.12 + i * 0.3;
        const w = 0.3 - i * 0.04;
        seg.add(makeBox(w, 0.22, 0.06, darkVoid));
        seg.add(makeBox(w + 0.06, 0.16, 0.035, i === 3 ? bright : purple));
        group.add(seg);
        segs.push(seg);
      }
      group.add(makeCone(0.14, 0.34, 4, bright, [0, 1.3, 0]));

      animators.push((t) => {
        segs.forEach((s, i) => {
          s.position.y = 0.12 + i * 0.3 + Math.sin(t * 4 + i * 0.8) * 0.04;
          s.rotation.y = Math.sin(t * 2 + i) * 0.18;
        });
      });
      break;
    }

    // === 8 NEW ULTRA-DETAILED 3D POWER WEAPONS ===
    case 'star': {
      // Celestial Star-Orrery Staff
      addWrappedHilt(group, { length: 1.0, yOffset: -0.25, gripColor: 0x1b294d, metalColor: 0xffd43b, gemColor: 0x9bf6ff });
      const gold = flatMat(0xffd43b, { metalness: 0.6, emissive: 0xffaa00, emissiveIntensity: 0.5 });
      const starGlow = flatMat(0xfff59d, { emissive: 0xffe047, emissiveIntensity: 1.5 });
      const cyan = flatMat(0x9bf6ff, { emissive: 0x6ceeff, emissiveIntensity: 1.3 });

      const star = new THREE.Group();
      star.position.y = 0.62;
      star.add(makeGem(0.24, starGlow));
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        star.add(makeCone(0.08, 0.34, 4, gold, [Math.cos(a) * 0.3, Math.sin(a) * 0.3, 0], [0, 0, a - Math.PI / 2]));
      }
      group.add(star);

      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.56, 0.032, 5, 16), cyan);
      ring.position.y = 0.62;
      group.add(ring);

      animators.push((t) => {
        star.rotation.z = t * 1.8;
        ring.rotation.x = t * 2.2;
        ring.rotation.y = t * 1.5;
      });
      break;
    }

    case 'prism': {
      // Iridescent Multi-Color Rainbow Greatsword
      addWrappedHilt(group, { length: 0.52, yOffset: -0.45, gripColor: 0xf4f7ff, wrapColor: 0x7b2cbf, metalColor: 0xe6efff, gemColor: 0xff66d9 });
      const rainbow = [0xff4d6d, 0xff9f1c, 0xffe066, 0x38d97c, 0x29f0ff, 0x9b5de5];
      group.add(makeBox(0.72, 0.12, 0.18, flatMat(0xffffff, { metalness: 0.5 }), [0, -0.14, 0]));
      rainbow.forEach((hex, idx) => {
        const m = flatMat(hex, { emissive: hex, emissiveIntensity: 1.25 });
        group.add(makeBox(0.26 - idx * 0.015, 0.19, 0.06, m, [0, 0.04 + idx * 0.18, 0]));
      });
      group.add(makeCone(0.16, 0.36, 4, flatMat(0xffffff, { emissive: 0x9bf6ff, emissiveIntensity: 1.4 }), [0, 1.28, 0]));

      const cubes = new THREE.Group();
      cubes.position.y = 0.55;
      rainbow.forEach((hex, i) => {
        const a = (i / rainbow.length) * Math.PI * 2;
        cubes.add(makeBox(0.09, 0.09, 0.09, flatMat(hex, { emissive: hex, emissiveIntensity: 1.4 }), [Math.cos(a) * 0.45, (i - 2.5) * 0.12, Math.sin(a) * 0.45]));
      });
      group.add(cubes);
      animators.push((t) => { cubes.rotation.y = t * 3.2; });
      break;
    }

    case 'mecha': {
      // Heavy Armored Hydraulic Rail-Cannon Gauntlet
      const armor = flatMat(0xd93838, { metalness: 0.55, roughness: 0.3 });
      const steel = flatMat(0x2b3648, { metalness: 0.7, roughness: 0.28 });
      const glow = flatMat(0x40c4ff, { emissive: 0x00b0ff, emissiveIntensity: 1.5 });
      const yellow = flatMat(0xffd43b, { metalness: 0.4 });

      group.add(makeBox(0.58, 0.45, 0.58, steel, [0, -0.22, 0]));
      group.add(makeBox(0.66, 0.58, 0.64, armor, [0, 0.25, 0]));
      group.add(makeBox(0.72, 0.12, 0.7, yellow, [0, 0.04, 0]));
      // Twin top rocket-launcher barrels!
      group.add(makeCyl(0.12, 0.13, 0.55, 8, steel, [-0.18, 0.65, 0.12]));
      group.add(makeCyl(0.12, 0.13, 0.55, 8, steel, [0.18, 0.65, 0.12]));
      const core = makeCyl(0.14, 0.14, 0.12, 8, glow, [0, 0.28, -0.32], [Math.PI / 2, 0, 0]);
      group.add(core);
      animators.push((t) => {
        core.material.emissiveIntensity = 1.2 + Math.sin(t * 8) * 0.4;
      });
      break;
    }

    case 'phoenix': {
      // Winged Crimson & Golden Fire Phoenix Blade
      addWrappedHilt(group, { length: 0.5, yOffset: -0.45, gripColor: 0x591111, metalColor: 0xffb703, gemColor: 0xffe866 });
      const gold = flatMat(0xffb703, { metalness: 0.6, emissive: 0xff8800, emissiveIntensity: 0.55 });
      const fire = flatMat(0xff5500, { emissive: 0xff3b00, emissiveIntensity: 1.45 });
      const bright = flatMat(0xfff08a, { emissive: 0xffd43b, emissiveIntensity: 1.5 });

      // Sculpted spreading phoenix wings at guard
      for (const s of [-1, 1]) {
        group.add(makeBox(0.42, 0.14, 0.08, gold, [s * 0.26, -0.1, 0], [0, 0, -s * 0.35]));
        group.add(makeBox(0.36, 0.12, 0.06, fire, [s * 0.48, 0.08, 0], [0, 0, -s * 0.72]));
        group.add(makeCone(0.08, 0.32, 4, bright, [s * 0.62, 0.26, 0], [0, 0, -s * 0.9]));
      }
      group.add(makeBox(0.22, 1.02, 0.06, fire, [0, 0.44, 0]));
      group.add(makeBox(0.1, 1.08, 0.085, bright, [0, 0.46, 0]));
      group.add(makeCone(0.16, 0.4, 4, bright, [0, 1.15, 0]));
      animators.push((t) => {
        fire.emissiveIntensity = 1.25 + Math.sin(t * 7) * 0.3;
      });
      break;
    }

    case 'abyss': {
      // Colossal Spectral Deep-Sea Anchor
      addWrappedHilt(group, { length: 0.95, yOffset: -0.15, gripColor: 0x102a36, metalColor: 0x1b4d5e, gemColor: 0x00f5c8 });
      const iron = flatMat(0x183442, { metalness: 0.6, roughness: 0.35 });
      const teal = flatMat(0x00d2a8, { emissive: 0x00b894, emissiveIntensity: 1.25 });

      // Top anchor ring
      const topRing = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.06, 5, 10), teal);
      topRing.position.y = 0.88;
      group.add(topRing);
      // Cross stock
      group.add(makeBox(0.86, 0.16, 0.18, iron, [0, 0.48, 0]));
      group.add(makeBox(0.24, 0.92, 0.2, iron, [0, 0.05, 0]));
      // Giant curved flukes at base/head
      group.add(makeBox(1.12, 0.2, 0.2, iron, [0, -0.32, 0]));
      group.add(makeBox(0.2, 0.48, 0.18, iron, [-0.52, -0.14, 0], [0, 0, -0.32]));
      group.add(makeBox(0.2, 0.48, 0.18, iron, [0.52, -0.14, 0], [0, 0, 0.32]));
      group.add(makeCone(0.16, 0.36, 4, teal, [-0.62, 0.18, 0], [0, 0, -0.35]));
      group.add(makeCone(0.16, 0.36, 4, teal, [0.62, 0.18, 0], [0, 0, 0.35]));
      group.add(makeGem(0.15, teal, [0, 0.48, 0.12]));
      animators.push((t) => { topRing.rotation.y = t * 2.2; });
      break;
    }

    case 'sand': {
      // Golden Pharaoh Ankh & Lapis Staff
      addWrappedHilt(group, { length: 0.96, yOffset: -0.26, gripColor: 0x1e40af, wrapColor: 0xf5c242, metalColor: 0xf5c242, gemColor: 0x38bdf8 });
      const gold = flatMat(0xf5c242, { metalness: 0.65, roughness: 0.25, emissive: 0xd99b00, emissiveIntensity: 0.35 });
      const lapis = flatMat(0x1d4ed8, { metalness: 0.4, emissive: 0x2563eb, emissiveIntensity: 0.65 });
      const sandGlow = flatMat(0xffe794, { emissive: 0xffd166, emissiveIntensity: 1.2 });

      // Royal Ankh head
      group.add(makeBox(0.68, 0.14, 0.14, gold, [0, 0.34, 0]));
      const loop = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.08, 6, 12), gold);
      loop.position.y = 0.72;
      loop.scale.set(0.85, 1.25, 1);
      group.add(loop);
      group.add(makeGem(0.14, lapis, [0, 0.34, 0.1]));

      const swirl = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.035, 4, 14), sandGlow);
      swirl.rotation.x = Math.PI / 2;
      swirl.position.y = 0.34;
      group.add(swirl);
      animators.push((t) => {
        swirl.rotation.z = t * 3.5;
        swirl.position.y = 0.34 + Math.sin(t * 4) * 0.14;
      });
      break;
    }

    case 'magnet': {
      // Dual-Pole Red/Blue Electromagnetic Hammer
      addWrappedHilt(group, { length: 0.85, yOffset: -0.26, gripColor: 0x262c3a, metalColor: 0x9aa5b8, gemColor: 0x3792ff });
      const steel = flatMat(0x3a4457, { metalness: 0.65, roughness: 0.3 });
      const red = flatMat(0xff4757, { emissive: 0xff2e44, emissiveIntensity: 1.2 });
      const blue = flatMat(0x3792ff, { emissive: 0x1e78ff, emissiveIntensity: 1.2 });

      group.add(makeBox(0.32, 0.46, 0.46, steel, [0, 0.44, 0]));
      group.add(makeBox(0.36, 0.44, 0.44, red, [-0.34, 0.44, 0]));
      group.add(makeBox(0.36, 0.44, 0.44, blue, [0.34, 0.44, 0]));

      const field = new THREE.Group();
      field.position.y = 0.44;
      const r1 = new THREE.Mesh(new THREE.TorusGeometry(0.58, 0.03, 5, 14), red);
      const r2 = new THREE.Mesh(new THREE.TorusGeometry(0.58, 0.03, 5, 14), blue);
      r2.rotation.y = Math.PI / 2;
      field.add(r1, r2);
      group.add(field);
      animators.push((t) => {
        field.rotation.y = t * 3.4;
        field.rotation.x = t * 2.1;
      });
      break;
    }

    case 'samurai': {
      // Imperial Sakura Razor Katana with Orbiting Petals
      addWrappedHilt(group, { length: 0.48, yOffset: -0.46, gripColor: 0x7c1528, wrapColor: 0x1b1520, metalColor: 0xffd43b, gemColor: 0xff6b9d });
      const steel = flatMat(0xeef5ff, { metalness: 0.78, roughness: 0.16 });
      const edge = flatMat(0xff99c8, { emissive: 0xff5c9e, emissiveIntensity: 1.2 });
      const gold = flatMat(0xffd43b, { metalness: 0.6 });

      // Circular golden Tsuba guard
      group.add(makeCyl(0.24, 0.24, 0.07, 10, gold, [0, -0.2, 0]));
      // Sleek tapered katana blade
      group.add(makeBox(0.11, 1.24, 0.035, steel, [-0.015, 0.46, 0]));
      group.add(makeBox(0.04, 1.26, 0.045, edge, [0.045, 0.47, 0]));
      group.add(makeCone(0.075, 0.28, 4, steel, [0, 1.2, 0], [0, 0, -0.14]));

      const petals = new THREE.Group();
      petals.position.y = 0.45;
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2;
        petals.add(makeBox(0.11, 0.06, 0.03, edge, [Math.cos(a) * 0.42, (i - 2) * 0.18, Math.sin(a) * 0.42], [0.5, a, 0.3]));
      }
      group.add(petals);
      animators.push((t) => { petals.rotation.y = t * 2.8; });
      break;
    }

    default: {
      group.add(makeGem(0.4, flatMat(0xffffff)));
    }
  }

  group.userData.animate = (t) => {
    for (const fn of animators) fn(t);
  };
  return group;
}

/**
 * Draws 6 crisp cartoon Roblox/Cubex-inspired faces!
 */
function createCartoonFaceTexture(skinColor = '#f2c96b', style = 0) {
  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 128;
  const ctx = c.getContext('2d');

  ctx.fillStyle = skinColor;
  ctx.fillRect(0, 0, 128, 128);

  if (style === 2) {
    // Cool dark sunglasses
    ctx.fillStyle = '#111622';
    ctx.fillRect(14, 38, 44, 28);
    ctx.fillRect(70, 38, 44, 28);
    ctx.fillRect(54, 46, 20, 8);
    ctx.fillStyle = 'rgba(255,255,255,0.45)';
    ctx.fillRect(20, 42, 16, 6);
    ctx.fillRect(76, 42, 16, 6);
    ctx.strokeStyle = '#181c26';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(64, 78, 16, 0.1 * Math.PI, 0.85 * Math.PI);
    ctx.stroke();
  } else if (style === 5) {
    // Neon Cyber Visor
    ctx.fillStyle = '#0c1829';
    ctx.fillRect(10, 36, 108, 32);
    ctx.fillStyle = '#29f0ff';
    ctx.fillRect(16, 44, 96, 14);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(22, 47, 30, 5);
    ctx.strokeStyle = '#181c26';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(46, 88); ctx.lineTo(82, 86);
    ctx.stroke();
  } else {
    // Rosy cheeks
    ctx.fillStyle = 'rgba(255, 115, 115, 0.28)';
    ctx.beginPath();
    ctx.arc(28, 74, 10, 0, Math.PI * 2);
    ctx.arc(100, 74, 10, 0, Math.PI * 2);
    ctx.fill();

    // Eyes
    ctx.fillStyle = '#161b26';
    ctx.beginPath();
    ctx.ellipse(42, 52, 8, style === 3 ? 13 : 10, 0, 0, Math.PI * 2);
    ctx.ellipse(86, 52, 8, style === 3 ? 13 : 10, 0, 0, Math.PI * 2);
    ctx.fill();

    // Sparkles
    ctx.fillStyle = style === 3 ? '#74e8ff' : '#ffffff';
    ctx.beginPath();
    ctx.arc(44, 47, style === 3 ? 4.5 : 3, 0, Math.PI * 2);
    ctx.arc(88, 47, style === 3 ? 4.5 : 3, 0, Math.PI * 2);
    ctx.fill();

    if (style === 1 || style === 4) {
      // Determined brows
      ctx.strokeStyle = '#241a14';
      ctx.lineWidth = 5;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(28, 32); ctx.lineTo(54, 40);
      ctx.moveTo(100, 32); ctx.lineTo(74, 40);
      ctx.stroke();
    }

    if (style === 4) {
      // Warrior scar across right cheek
      ctx.strokeStyle = '#b53a3a';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(76, 36); ctx.lineTo(98, 78);
      ctx.stroke();
    }

    // Smile
    ctx.strokeStyle = '#161b26';
    ctx.lineWidth = 5;
    ctx.lineCap = 'round';
    ctx.beginPath();
    if (style === 1 || style === 4) {
      ctx.moveTo(46, 82);
      ctx.quadraticCurveTo(64, 94, 84, 78);
    } else {
      ctx.arc(64, 70, 19, 0.15 * Math.PI, 0.85 * Math.PI);
    }
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function buildHatGroup(hatStyle, hairMat) {
  const g = new THREE.Group();
  switch (hatStyle) {
    case 0: // Classic spiky hair
      g.add(makeBox(0.7, 0.2, 0.7, hairMat, [0, 0.33, 0.02]));
      g.add(makeBox(0.68, 0.24, 0.2, hairMat, [0, 0.16, 0.28]));
      for (let i = -1; i <= 1; i++) {
        g.add(makeBox(0.18, 0.2, 0.24, hairMat, [i * 0.2, 0.45, -0.06], [0.25, 0, 0]));
      }
      break;
    case 1: // Ninja headband + spiky hair
      g.add(makeBox(0.7, 0.15, 0.7, flatMat(0xe63946), [0, 0.18, 0]));
      g.add(makeBox(0.24, 0.11, 0.08, flatMat(0xb8c5d6, { metalness: 0.6 }), [0, 0.18, -0.35]));
      g.add(makeBox(0.66, 0.22, 0.66, hairMat, [0, 0.36, 0]));
      break;
    case 2: // Street Cap
      g.add(makeBox(0.7, 0.22, 0.7, hairMat, [0, 0.32, 0]));
      g.add(makeBox(0.66, 0.07, 0.36, hairMat, [0, 0.22, -0.42]));
      break;
    case 3: { // Royal Gold Crown
      const gold = flatMat(0xffd43b, { metalness: 0.6, emissive: 0xffaa00, emissiveIntensity: 0.25 });
      g.add(makeBox(0.68, 0.15, 0.68, gold, [0, 0.36, 0]));
      for (let i = -1; i <= 1; i++) {
        g.add(makeCone(0.1, 0.24, 4, gold, [i * 0.22, 0.54, -0.26]));
        g.add(makeCone(0.1, 0.24, 4, gold, [i * 0.22, 0.54, 0.26]));
      }
      g.add(makeGem(0.08, flatMat(0xe63946, { emissive: 0xe63946, emissiveIntensity: 0.9 }), [0, 0.38, -0.35]));
      break;
    }
    case 4: { // Wizard Hat
      const wiz = flatMat(0x3a246b, { roughness: 0.75 });
      const band = flatMat(0xffd43b);
      g.add(makeCyl(0.62, 0.65, 0.08, 8, wiz, [0, 0.34, 0]));
      g.add(makeCyl(0.36, 0.38, 0.12, 8, band, [0, 0.42, 0]));
      g.add(makeCone(0.36, 0.72, 7, wiz, [0, 0.78, 0.06], [0.18, 0, 0]));
      break;
    }
    case 5: { // Viking Horned Helmet
      const iron = flatMat(0x525e70, { metalness: 0.55 });
      const horn = flatMat(0xf5ebd6);
      g.add(makeBox(0.7, 0.26, 0.7, iron, [0, 0.3, 0]));
      g.add(makeCone(0.1, 0.44, 5, horn, [-0.46, 0.46, 0], [0, 0, 0.85]));
      g.add(makeCone(0.1, 0.44, 5, horn, [0.46, 0.46, 0], [0, 0, -0.85]));
      break;
    }
    case 6: { // Cyber Helmet
      const tech = flatMat(0x1f2b40, { metalness: 0.65 });
      const neon = flatMat(0x29f0ff, { emissive: 0x00e5ff, emissiveIntensity: 1.3 });
      g.add(makeBox(0.72, 0.26, 0.72, tech, [0, 0.32, 0]));
      g.add(makeBox(0.76, 0.08, 0.2, neon, [0, 0.34, -0.28]));
      g.add(makeBox(0.08, 0.32, 0.08, neon, [0.36, 0.52, 0.1]));
      break;
    }
    case 7: { // Assassin Hood
      const hood = flatMat(0x1f222e, { roughness: 0.85 });
      g.add(makeBox(0.74, 0.24, 0.76, hood, [0, 0.32, 0.04]));
      g.add(makeBox(0.74, 0.56, 0.18, hood, [0, 0.04, 0.34]));
      g.add(makeBox(0.14, 0.42, 0.68, hood, [-0.34, 0.08, 0.04]));
      g.add(makeBox(0.14, 0.42, 0.68, hood, [0.34, 0.08, 0.04]));
      break;
    }
    case 8: { // Angelic Golden Halo
      g.add(makeBox(0.68, 0.2, 0.68, hairMat, [0, 0.33, 0]));
      const halo = new THREE.Mesh(
        new THREE.TorusGeometry(0.36, 0.045, 6, 16),
        flatMat(0xffe066, { emissive: 0xffd43b, emissiveIntensity: 1.4 })
      );
      halo.rotation.x = Math.PI / 2;
      halo.position.y = 0.66;
      g.add(halo);
      break;
    }
    case 9: { // Demon Horns
      const demon = flatMat(0xb81d33, { emissive: 0x700c1b, emissiveIntensity: 0.5 });
      g.add(makeBox(0.68, 0.2, 0.68, hairMat, [0, 0.33, 0]));
      g.add(makeCone(0.09, 0.42, 5, demon, [-0.24, 0.56, -0.06], [-0.2, 0, 0.38]));
      g.add(makeCone(0.09, 0.42, 5, demon, [0.24, 0.56, -0.06], [-0.2, 0, -0.38]));
      break;
    }
  }
  return g;
}

function buildBackGroup(backStyle, shirtHex) {
  const g = new THREE.Group();
  if (!backStyle) return g;
  if (backStyle === 1) {
    // Hero Cape
    const capeMat = flatMat(shirtHex === 0xe63946 ? 0xffd43b : 0xe63946, { side: THREE.DoubleSide });
    g.add(makeBox(0.8, 1.05, 0.06, capeMat, [0, 1.15, 0.3], [0.18, 0, 0]));
  } else if (backStyle === 2) {
    // Dragon Wings
    const wingMat = flatMat(0x2a1b3d);
    const edgeMat = flatMat(0xff6b2b, { emissive: 0xff4500, emissiveIntensity: 0.7 });
    for (const s of [-1, 1]) {
      g.add(makeBox(0.78, 0.48, 0.06, wingMat, [s * 0.58, 1.55, 0.34], [0.1, s * -0.35, s * 0.28]));
      g.add(makeBox(0.84, 0.1, 0.08, edgeMat, [s * 0.58, 1.8, 0.34], [0.1, s * -0.35, s * 0.28]));
    }
  } else if (backStyle === 3) {
    // Angel Wings
    const feather = flatMat(0xf7fbff, { emissive: 0xcceeff, emissiveIntensity: 0.4 });
    for (const s of [-1, 1]) {
      g.add(makeBox(0.75, 0.42, 0.06, feather, [s * 0.56, 1.56, 0.32], [0.05, s * -0.32, s * 0.24]));
      g.add(makeBox(0.55, 0.34, 0.05, feather, [s * 0.45, 1.24, 0.34], [0.08, s * -0.25, s * 0.1]));
    }
  } else if (backStyle === 4) {
    // Cyber Jetpack
    const metal = flatMat(0x2d3b52, { metalness: 0.6 });
    const glow = flatMat(0x29f0ff, { emissive: 0x00e5ff, emissiveIntensity: 1.4 });
    g.add(makeBox(0.56, 0.64, 0.26, metal, [0, 1.38, 0.34]));
    g.add(makeCyl(0.11, 0.14, 0.48, 8, metal, [-0.2, 1.28, 0.4]));
    g.add(makeCyl(0.11, 0.14, 0.48, 8, metal, [0.2, 1.28, 0.4]));
    g.add(makeCone(0.11, 0.26, 6, glow, [-0.2, 0.94, 0.4], [Math.PI, 0, 0]));
    g.add(makeCone(0.11, 0.26, 6, glow, [0.2, 0.94, 0.4], [Math.PI, 0, 0]));
  } else if (backStyle === 5) {
    // Katana on Back
    const scabbard = flatMat(0x1b2130);
    const gold = flatMat(0xffd43b, { metalness: 0.5 });
    const k = new THREE.Group();
    k.position.set(0, 1.4, 0.3);
    k.rotation.z = -0.65;
    k.add(makeBox(0.1, 1.35, 0.08, scabbard));
    k.add(makeBox(0.24, 0.08, 0.12, gold, [0, 0.52, 0]));
    k.add(makeBox(0.08, 0.34, 0.08, flatMat(0xe63946), [0, 0.72, 0]));
    g.add(k);
  }
  return g;
}

/**
 * Builds a fully customizable articulated cartoon character rig!
 */
export function createCharacterRig(initialAppearance = {}) {
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);

  const skinMat = flatMat(0xf2c96b, { roughness: 0.68 });
  const shirtMat = flatMat(0x2b7de9, { roughness: 0.65 });
  const pantsMat = flatMat(0x2a3b4f, { roughness: 0.78 });
  const hairMat = flatMat(0x5c361a, { roughness: 0.75 });
  const shoeMat = flatMat(0x202633, { roughness: 0.85 });

  // Legs
  const leftLegPivot = new THREE.Group();
  leftLegPivot.position.set(-0.22, 0.82, 0);
  leftLegPivot.add(makeBox(0.36, 0.72, 0.38, pantsMat, [0, -0.36, 0]));
  leftLegPivot.add(makeBox(0.38, 0.16, 0.44, shoeMat, [0, -0.74, -0.03]));
  body.add(leftLegPivot);

  const rightLegPivot = new THREE.Group();
  rightLegPivot.position.set(0.22, 0.82, 0);
  rightLegPivot.add(makeBox(0.36, 0.72, 0.38, pantsMat, [0, -0.36, 0]));
  rightLegPivot.add(makeBox(0.38, 0.16, 0.44, shoeMat, [0, -0.74, -0.03]));
  body.add(rightLegPivot);

  // Torso + belt + chest emblem
  body.add(makeBox(0.84, 0.92, 0.46, shirtMat, [0, 1.28, 0]));
  body.add(makeBox(0.87, 0.12, 0.49, flatMat(0x1f2636), [0, 0.88, 0]));
  body.add(makeBox(0.18, 0.14, 0.51, flatMat(0xffd43b, { metalness: 0.5 }), [0, 0.88, 0]));

  // Head
  const headGroup = new THREE.Group();
  headGroup.position.set(0, 2.04, 0);
  const faceMat = new THREE.MeshStandardMaterial({ roughness: 0.65 });
  const headMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.64, 0.62, 0.64),
    [skinMat, skinMat, skinMat, skinMat, skinMat, faceMat]
  );
  headMesh.castShadow = true;
  headMesh.receiveShadow = true;
  headGroup.add(headMesh);

  const hatMount = new THREE.Group();
  headGroup.add(hatMount);
  body.add(headGroup);

  const backMount = new THREE.Group();
  body.add(backMount);

  // Arms
  const leftArmPivot = new THREE.Group();
  leftArmPivot.position.set(-0.62, 1.66, 0);
  leftArmPivot.add(makeBox(0.32, 0.34, 0.34, shirtMat, [0, -0.15, 0]));
  leftArmPivot.add(makeBox(0.3, 0.56, 0.32, skinMat, [0, -0.57, 0]));
  body.add(leftArmPivot);

  const rightArmPivot = new THREE.Group();
  rightArmPivot.position.set(0.62, 1.66, 0);
  rightArmPivot.add(makeBox(0.32, 0.34, 0.34, shirtMat, [0, -0.15, 0]));
  rightArmPivot.add(makeBox(0.3, 0.56, 0.32, skinMat, [0, -0.57, 0]));

  // Right Hand Weapon Mount — properly angled forward!
  const handMount = new THREE.Group();
  handMount.position.set(0, -0.82, -0.26);
  handMount.rotation.set(-0.55, 0, 0);
  handMount.scale.setScalar(0.88);
  rightArmPivot.add(handMount);
  body.add(rightArmPivot);

  // Ice Block overlay
  const iceBlock = new THREE.Mesh(
    new THREE.BoxGeometry(1.38, 2.58, 1.28),
    flatMat(0x88f0ff, { transparent: true, opacity: 0.52, emissive: 0x38d9ff, emissiveIntensity: 0.35 })
  );
  iceBlock.position.y = 1.28;
  iceBlock.visible = false;
  root.add(iceBlock);

  // Power Aura Ring
  const auraRing = new THREE.Mesh(
    new THREE.RingGeometry(0.64, 0.86, 18),
    new THREE.MeshBasicMaterial({ color: 0x38d9ff, side: THREE.DoubleSide, transparent: true, opacity: 0.45 })
  );
  auraRing.rotation.x = -Math.PI / 2;
  auraRing.position.y = 0.05;
  root.add(auraRing);

  // Battle Royale 3D Glider attached above character (hidden unless gliding!)
  const gliderMesh = createGliderModel(0x38d9ff, 0xffd43b);
  gliderMesh.visible = false;
  root.add(gliderMesh);

  // Shield Sphere visual (shown when fighter has active tactical shield!)
  const shieldBubble = new THREE.Mesh(
    new THREE.IcosahedronGeometry(1.55, 1),
    flatMat(0x38d9ff, { emissive: 0x22d0ff, emissiveIntensity: 0.5, transparent: true, opacity: 0.22, side: THREE.DoubleSide })
  );
  shieldBubble.position.y = 1.3;
  shieldBubble.visible = false;
  root.add(shieldBubble);

  const rig = {
    root,
    body,
    headGroup,
    leftArmPivot,
    rightArmPivot,
    leftLegPivot,
    rightLegPivot,
    handMount,
    iceBlock,
    auraRing,
    gliderMesh,
    shieldBubble,
    powerMesh: null,
    applyAppearance(app = {}) {
      const skinHex = app.skinHex ?? 0xf2c96b;
      const shirtHex = app.shirtHex ?? 0x2b7de9;
      const pantsHex = app.pantsHex ?? 0x2a3b4f;
      const hairHex = app.hairHex ?? 0x5c361a;
      const hatStyle = app.hatStyle ?? 0;
      const faceStyle = app.faceStyle ?? 0;
      const backStyle = app.backStyle ?? 0;

      skinMat.color.setHex(skinHex);
      shirtMat.color.setHex(shirtHex);
      pantsMat.color.setHex(pantsHex);
      hairMat.color.setHex(hairHex);

      if (faceMat.map) faceMat.map.dispose();
      faceMat.map = createCartoonFaceTexture('#' + skinHex.toString(16).padStart(6, '0'), faceStyle);
      faceMat.needsUpdate = true;

      while (hatMount.children.length > 0) hatMount.remove(hatMount.children[0]);
      hatMount.add(buildHatGroup(hatStyle, hairMat));

      while (backMount.children.length > 0) backMount.remove(backMount.children[0]);
      backMount.add(buildBackGroup(backStyle, shirtHex));
    },
    setPowerModel(powerId, colorHex) {
      while (handMount.children.length > 0) handMount.remove(handMount.children[0]);
      if (!powerId) {
        this.powerMesh = null;
        auraRing.visible = false;
        return;
      }
      auraRing.visible = true;
      const model = createPowerModel(powerId);
      handMount.add(model);
      this.powerMesh = model;
      auraRing.material.color.setHex(colorHex);
    },
    setGunModel(weaponId) {
      while (handMount.children.length > 0) handMount.remove(handMount.children[0]);
      if (!weaponId) return;
      const gun = createGunModel(weaponId);
      gun.rotation.set(0.55, 0, 0);
      gun.scale.setScalar(1.05);
      handMount.add(gun);
      this.powerMesh = null;
    },
  };

  rig.applyAppearance(initialAppearance);
  return rig;
}

/**
 * Upgraded First-Person Blocky Cartoon Arms Rig!
 * Cleanly matches Screenshots 1 & 3 (chunky arms nicely framed bottom-left & bottom-right),
 * updates live with your custom skin & shirt sleeve colors, and holds your 3D power weapon
 * naturally forward-upward so it looks badass without obstructing the crosshair!
 */
export function createFirstPersonRig(initialAppearance = {}) {
  const root = new THREE.Group();
  const skinMat = flatMat(initialAppearance.skinHex ?? 0xf2c96b, { roughness: 0.62 });
  const sleeveMat = flatMat(initialAppearance.shirtHex ?? 0x2b7de9, { roughness: 0.68 });
  const trimMat = flatMat(0x1f2838, { roughness: 0.7 });

  const buildArm = (isRight) => {
    const pivot = new THREE.Group();
    const s = isRight ? 1 : -1;
    // Forearm stretching forward-down cleanly into lower-left / lower-right corner
    const forearm = makeBox(0.24, 0.24, 0.82, skinMat, [0, 0, 0]);
    forearm.castShadow = false;
    pivot.add(forearm);

    // Sleeve cuff near camera
    const sleeve = makeBox(0.27, 0.27, 0.34, sleeveMat, [0, 0, 0.32]);
    sleeve.castShadow = false;
    pivot.add(sleeve);

    // Wristband detail
    const band = makeBox(0.255, 0.255, 0.06, trimMat, [0, 0, -0.26]);
    band.castShadow = false;
    pivot.add(band);

    // Thumb detail on inner side of hand
    const thumb = makeBox(0.07, 0.08, 0.14, skinMat, [-s * 0.12, 0.04, -0.34]);
    thumb.castShadow = false;
    pivot.add(thumb);

    return pivot;
  };

  const leftArm = buildArm(false);
  leftArm.position.set(-0.56, -0.44, -0.68);
  leftArm.rotation.set(0.22, -0.24, 0.08);
  root.add(leftArm);

  const rightArm = buildArm(true);
  rightArm.position.set(0.56, -0.44, -0.68);
  rightArm.rotation.set(0.22, 0.24, -0.08);
  root.add(rightArm);

  // Weapon socket perched neatly at the right fist, angled upright-forward like a real FPS tool!
  const handMount = new THREE.Group();
  handMount.position.set(-0.02, 0.12, -0.42);
  handMount.rotation.set(-0.32, -0.35, 0.14);
  handMount.scale.setScalar(0.52);
  rightArm.add(handMount);

  // Gun mount cleanly aligned forward in first-person (supports ADS centering!)
  const gunMount = new THREE.Group();
  gunMount.position.set(0.32, -0.28, -0.58);
  root.add(gunMount);

  // First-person glider canopy frame visible overhead when gliding!
  const fpGlider = createGliderModel(0x38d9ff, 0xffd43b);
  fpGlider.position.set(0, -1.75, -0.45);
  fpGlider.visible = false;
  root.add(fpGlider);

  return {
    root,
    leftArm,
    rightArm,
    handMount,
    gunMount,
    fpGlider,
    powerMesh: null,
    activeGunId: null,
    applyAppearance(app = {}) {
      if (app.skinHex !== undefined) skinMat.color.setHex(app.skinHex);
      if (app.shirtHex !== undefined) sleeveMat.color.setHex(app.shirtHex);
    },
    setPowerModel(powerId) {
      while (handMount.children.length > 0) handMount.remove(handMount.children[0]);
      if (!powerId) {
        this.powerMesh = null;
        return;
      }
      const model = createPowerModel(powerId);
      model.traverse((o) => { o.castShadow = false; });
      handMount.add(model);
      this.powerMesh = model;
    },
    setGunModel(weaponId) {
      while (gunMount.children.length > 0) gunMount.remove(gunMount.children[0]);
      this.activeGunId = weaponId || null;
      if (!weaponId) return;
      const gun = createGunModel(weaponId);
      gun.traverse((o) => { o.castShadow = false; });
      gunMount.add(gun);
    },
  };
}

export function createFloatingLabel(title, subtitle = '', accentColor = '#38d9ff', width = 340, height = 104) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = 'rgba(13, 24, 42, 0.86)';
  ctx.strokeStyle = accentColor;
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.roundRect(6, 6, width - 12, height - 12, 18);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 34px Fredoka, Nunito, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(title, width / 2, subtitle ? height * 0.4 : height * 0.52);

  if (subtitle) {
    ctx.fillStyle = accentColor;
    ctx.font = 'bold 20px Nunito, sans-serif';
    ctx.fillText(subtitle, width / 2, height * 0.74);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  sprite.scale.set(width / 110, height / 110, 1);
  return sprite;
}

export function createBotNameplate(name, powerName, powerColor) {
  const canvas = document.createElement('canvas');
  canvas.width = 272;
  canvas.height = 88;
  const ctx = canvas.getContext('2d');
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;

  const draw = (hpRatio) => {
    ctx.clearRect(0, 0, 272, 88);
    ctx.fillStyle = 'rgba(12, 22, 38, 0.82)';
    ctx.beginPath();
    ctx.roundRect(10, 6, 252, 76, 14);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 23px Nunito, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(name, 136, 30);

    ctx.fillStyle = powerColor;
    ctx.font = 'bold 14px Nunito, sans-serif';
    ctx.fillText(powerName, 136, 50);

    ctx.fillStyle = 'rgba(255,255,255,0.16)';
    ctx.beginPath();
    ctx.roundRect(30, 60, 212, 11, 6);
    ctx.fill();

    ctx.fillStyle = hpRatio > 0.5 ? '#3be384' : hpRatio > 0.25 ? '#ffd43b' : '#ff595e';
    ctx.beginPath();
    ctx.roundRect(30, 60, Math.max(0, 212 * hpRatio), 11, 6);
    ctx.fill();

    tex.needsUpdate = true;
  };

  draw(1);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  sprite.scale.set(2.4, 0.78, 1);
  sprite.userData.updateHP = draw;
  return sprite;
}

export function createPortalMesh(primaryHex = 0x7ceeff, secondaryHex = 0xffffff, labelTitle = 'PORTAIL DE COMBAT', labelSub = 'Traverser pour combattre') {
  const group = new THREE.Group();
  const stoneMat = flatMat(0x2c374b, { roughness: 0.78 });
  const trimMat = flatMat(primaryHex, { emissive: primaryHex, emissiveIntensity: 1.0 });

  const archRing = new THREE.Mesh(new THREE.TorusGeometry(3.0, 0.38, 8, 18), stoneMat);
  archRing.position.y = 3.1;
  archRing.castShadow = true;
  group.add(archRing);

  const glowRing = new THREE.Mesh(new THREE.TorusGeometry(2.72, 0.16, 6, 20), trimMat);
  glowRing.position.y = 3.1;
  group.add(glowRing);

  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d');
  const grad = ctx.createRadialGradient(128, 128, 10, 128, 128, 126);
  grad.addColorStop(0, '#ffffff');
  grad.addColorStop(0.45, '#e8fcff');
  grad.addColorStop(0.8, '#' + primaryHex.toString(16).padStart(6, '0'));
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);

  ctx.strokeStyle = 'rgba(255,255,255,0.7)';
  ctx.lineWidth = 7;
  for (let arm = 0; arm < 5; arm++) {
    ctx.beginPath();
    for (let i = 0; i < 42; i++) {
      const a = (arm * Math.PI * 2) / 5 + i * 0.2;
      const r = i * 2.8;
      const x = 128 + Math.cos(a) * r;
      const y = 128 + Math.sin(a) * r;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  const vortexTex = new THREE.CanvasTexture(c);
  vortexTex.colorSpace = THREE.SRGBColorSpace;

  const vortexMesh = new THREE.Mesh(
    new THREE.CircleGeometry(2.68, 22),
    new THREE.MeshBasicMaterial({ map: vortexTex, transparent: true, side: THREE.DoubleSide })
  );
  vortexMesh.position.y = 3.1;
  group.add(vortexMesh);

  const runes = new THREE.Group();
  runes.position.y = 3.1;
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    const shard = makeGem(0.24, trimMat, [Math.cos(a) * 3.65, Math.sin(a) * 3.65, 0.25]);
    runes.add(shard);
  }
  group.add(runes);

  group.add(makeBox(6.8, 0.35, 2.6, stoneMat, [0, 0.175, 0]));

  const light = new THREE.PointLight(primaryHex, 20, 22, 1.4);
  light.position.set(0, 3.1, 1.6);
  group.add(light);

  const label = createFloatingLabel(labelTitle, labelSub, '#' + primaryHex.toString(16).padStart(6, '0'), 440, 110);
  label.position.set(0, 7.0, 0);
  group.add(label);

  group.userData.animate = (t) => {
    vortexMesh.rotation.z = -t * 2.3;
    const pulse = 1 + Math.sin(t * 3.5) * 0.04;
    vortexMesh.scale.set(pulse, pulse, 1);
    runes.rotation.z = t * 0.9;
    light.intensity = 18 + Math.sin(t * 4) * 3.5;
  };
  return group;
}

export function createPineTree(scale = 1) {
  const tree = new THREE.Group();
  const trunkMat = flatMat(0x5c361e, { roughness: 0.92 });
  const leafPalette = [0x1c5933, 0x226b3d, 0x184c2b, 0x297843];
  const leafMat = flatMat(leafPalette[Math.floor(Math.random() * leafPalette.length)], { roughness: 0.85 });

  tree.add(makeCyl(0.28, 0.44, 2.5, 6, trunkMat, [0, 1.25, 0]));
  tree.add(makeCone(2.2, 4.3, 7, leafMat, [0, 3.9, 0]));
  tree.add(makeCone(1.65, 3.7, 7, leafMat, [0, 6.2, 0]));
  tree.add(makeCone(1.05, 2.8, 7, leafMat, [0, 8.1, 0]));
  tree.scale.setScalar(scale);
  return tree;
}

export function createSakuraTree(scale = 1) {
  const tree = new THREE.Group();
  const trunkMat = flatMat(0x4a2e1d, { roughness: 0.9 });
  const blossomMat = flatMat(0xff99c8, { roughness: 0.78 });
  const lightBlossom = flatMat(0xffc2df, { roughness: 0.75 });

  tree.add(makeCyl(0.26, 0.42, 3.4, 6, trunkMat, [0, 1.7, 0]));
  tree.add(makeBox(0.24, 1.6, 0.24, trunkMat, [0.7, 3.3, 0], [0, 0, -0.7]));
  tree.add(makeBox(0.22, 1.4, 0.22, trunkMat, [-0.65, 3.5, 0.2], [0.2, 0, 0.65]));

  const puffs = [
    [0, 4.8, 0, 2.0, blossomMat],
    [1.4, 4.2, 0.3, 1.4, lightBlossom],
    [-1.3, 4.4, -0.4, 1.45, blossomMat],
    [0.3, 4.5, -1.2, 1.3, lightBlossom],
  ];
  for (const [x, y, z, r, m] of puffs) {
    const p = new THREE.Mesh(new THREE.DodecahedronGeometry(r, 0), m);
    p.position.set(x, y, z);
    p.castShadow = true;
    tree.add(p);
  }
  tree.scale.setScalar(scale);
  return tree;
}

export function createRock(scale = 1) {
  const rock = new THREE.Mesh(
    new THREE.DodecahedronGeometry(1.0, 0),
    flatMat(0x4b5566, { roughness: 0.92 })
  );
  rock.scale.set(scale * 1.25, scale * 0.72, scale * 1.05);
  rock.castShadow = true;
  rock.receiveShadow = true;
  return rock;
}

export function createCrystal(scale = 1, hex = 0x63f0ff) {
  const g = new THREE.Group();
  const mat = flatMat(hex, { emissive: hex, emissiveIntensity: 0.7, roughness: 0.2 });
  g.add(makeCone(0.36, 1.6, 5, mat, [0, 0.72, 0]));
  g.add(makeCone(0.22, 1.0, 5, mat, [0.32, 0.42, 0.12], [0, 0, -0.35]));
  g.add(makeCone(0.18, 0.85, 5, mat, [-0.26, 0.36, -0.16], [0.2, 0, 0.38]));
  g.scale.setScalar(scale);
  return g;
}

export function createBlueMushroom(scale = 1) {
  const g = new THREE.Group();
  g.add(makeCyl(0.14, 0.18, 0.45, 6, flatMat(0xdcebf7), [0, 0.22, 0]));
  g.add(makeCone(0.55, 0.36, 7, flatMat(0x52c7ff, { emissive: 0x2299ee, emissiveIntensity: 0.55 }), [0, 0.5, 0]));
  g.scale.setScalar(scale);
  return g;
}
