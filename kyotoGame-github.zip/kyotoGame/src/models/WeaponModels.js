import * as THREE from 'three';

function flatMat(color, opts = {}) {
  return new THREE.MeshStandardMaterial({
    color,
    flatShading: true,
    roughness: opts.roughness ?? 0.45,
    metalness: opts.metalness ?? 0.35,
    emissive: opts.emissive ?? 0x000000,
    emissiveIntensity: opts.emissiveIntensity ?? 0,
    transparent: opts.transparent ?? false,
    opacity: opts.opacity ?? 1,
    side: opts.side ?? THREE.FrontSide,
  });
}

function box(w, h, d, mat, pos = [0, 0, 0], rot = [0, 0, 0]) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(...pos);
  m.rotation.set(...rot);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}

function cyl(rt, rb, h, seg, mat, pos = [0, 0, 0], rot = [0, 0, 0]) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), mat);
  m.position.set(...pos);
  m.rotation.set(...rot);
  m.castShadow = true;
  return m;
}

/**
 * Detailed 3D Low-Poly / Blockbench-Style Firearms for Battle Royale!
 * Oriented cleanly along -Z (barrel pointing forward toward target!).
 */
export function createGunModel(weaponId) {
  const g = new THREE.Group();
  const darkMetal = flatMat(0x232a36, { metalness: 0.65, roughness: 0.32 });
  const gunMetal = flatMat(0x3f4a5e, { metalness: 0.6, roughness: 0.35 });
  const gripMat = flatMat(0x1b1e26, { roughness: 0.85, metalness: 0.1 });
  const accentBlue = flatMat(0x38d9ff, { emissive: 0x00b4d8, emissiveIntensity: 1.1 });
  const accentGold = flatMat(0xffd43b, { metalness: 0.6, emissive: 0xffaa00, emissiveIntensity: 0.4 });
  const accentRed = flatMat(0xff4d6d, { emissive: 0xff2a55, emissiveIntensity: 1.2 });
  const woodMat = flatMat(0x6e4226, { roughness: 0.8, metalness: 0.05 });

  switch (weaponId) {
    case 'pistol': {
      // Tactical Pistol with illuminated reflex sight & suppressor tip
      g.add(box(0.14, 0.18, 0.62, gunMetal, [0, 0.12, -0.14]));
      g.add(box(0.15, 0.07, 0.54, darkMetal, [0, 0.01, -0.12]));
      g.add(box(0.12, 0.34, 0.16, gripMat, [0, -0.16, 0.08], [0.22, 0, 0]));
      g.add(cyl(0.04, 0.04, 0.24, 8, darkMetal, [0, 0.12, -0.52], [Math.PI / 2, 0, 0]));
      // Glowing iron sight dots
      g.add(box(0.03, 0.04, 0.03, accentBlue, [0, 0.23, -0.4]));
      g.add(box(0.03, 0.04, 0.03, accentBlue, [-0.04, 0.23, 0.12]));
      g.add(box(0.03, 0.04, 0.03, accentBlue, [0.04, 0.23, 0.12]));
      break;
    }

    case 'smg': {
      // Compact Neon Cyber SMG with extended magazine & red-dot optic
      g.add(box(0.16, 0.22, 0.86, darkMetal, [0, 0.1, -0.18]));
      g.add(box(0.18, 0.08, 0.44, accentBlue, [0, 0.12, -0.26]));
      g.add(box(0.12, 0.34, 0.14, gripMat, [0, -0.14, 0.12], [0.2, 0, 0]));
      // Extended magazine
      g.add(box(0.09, 0.42, 0.12, gunMetal, [0, -0.18, -0.26], [-0.15, 0, 0]));
      g.add(cyl(0.045, 0.045, 0.32, 8, gunMetal, [0, 0.12, -0.74], [Math.PI / 2, 0, 0]));
      // Holo optic
      g.add(box(0.12, 0.1, 0.18, darkMetal, [0, 0.26, -0.08]));
      g.add(box(0.04, 0.04, 0.02, accentRed, [0, 0.27, -0.12]));
      break;
    }

    case 'rifle': {
      // Tactical Assault Rifle with rail handguard, stock, curved mag & holographic sight
      g.add(box(0.16, 0.22, 0.85, darkMetal, [0, 0.1, -0.12]));
      g.add(box(0.14, 0.18, 0.56, gunMetal, [0, 0.11, -0.72]));
      g.add(cyl(0.042, 0.042, 0.48, 8, darkMetal, [0, 0.12, -1.16], [Math.PI / 2, 0, 0]));
      g.add(cyl(0.06, 0.05, 0.14, 6, accentGold, [0, 0.12, -1.42], [Math.PI / 2, 0, 0]));
      // Stock
      g.add(box(0.13, 0.22, 0.48, gripMat, [0, 0.06, 0.46]));
      // Grip & Curved Magazine
      g.add(box(0.11, 0.34, 0.14, gripMat, [0, -0.15, 0.12], [0.24, 0, 0]));
      g.add(box(0.1, 0.44, 0.18, gunMetal, [0, -0.2, -0.26], [-0.22, 0, 0]));
      // Holo Sight
      g.add(box(0.13, 0.13, 0.24, darkMetal, [0, 0.27, -0.05]));
      g.add(box(0.09, 0.07, 0.02, accentBlue, [0, 0.28, -0.05]));
      // Purple epic trim stripe
      g.add(box(0.175, 0.04, 0.65, flatMat(0xb15cff, { emissive: 0x9d4edd, emissiveIntensity: 0.9 }), [0, 0.14, -0.35]));
      break;
    }

    case 'shotgun': {
      // Heavy Pump-Action Combat Shotgun
      g.add(box(0.18, 0.22, 0.72, darkMetal, [0, 0.1, -0.12]));
      // Heavy wood stock
      g.add(box(0.15, 0.26, 0.54, woodMat, [0, 0.02, 0.44], [-0.14, 0, 0]));
      // Upper barrel + lower tube
      g.add(cyl(0.06, 0.06, 1.05, 8, gunMetal, [0, 0.16, -0.82], [Math.PI / 2, 0, 0]));
      g.add(cyl(0.05, 0.05, 0.92, 8, darkMetal, [0, 0.05, -0.76], [Math.PI / 2, 0, 0]));
      // Chunky ribbed orange/wood pump forend
      g.add(box(0.19, 0.16, 0.42, flatMat(0xff7b29, { emissive: 0xd9480f, emissiveIntensity: 0.35 }), [0, 0.04, -0.72]));
      // Front glowing bead sight
      g.add(box(0.04, 0.05, 0.04, accentRed, [0, 0.24, -1.3]));
      break;
    }

    case 'sniper': {
      // Legendary Long-Range Heavy Sniper Rifle with Large Precision Scope & Bipod
      g.add(box(0.16, 0.24, 0.96, darkMetal, [0, 0.08, -0.12]));
      g.add(box(0.18, 0.06, 0.85, accentGold, [0, 0.12, -0.25]));
      // Long fluted sniper barrel + heavy muzzle brake
      g.add(cyl(0.045, 0.055, 1.38, 8, gunMetal, [0, 0.13, -1.2], [Math.PI / 2, 0, 0]));
      g.add(box(0.14, 0.12, 0.26, darkMetal, [0, 0.13, -1.92]));
      // Skeleton precision stock & grip
      g.add(box(0.13, 0.24, 0.58, gripMat, [0, 0.04, 0.56]));
      g.add(box(0.11, 0.34, 0.14, gripMat, [0, -0.16, 0.14], [0.22, 0, 0]));
      g.add(box(0.11, 0.26, 0.22, gunMetal, [0, -0.14, -0.24]));
      // Big 3D Tactical Sniper Scope!
      g.add(box(0.07, 0.12, 0.08, darkMetal, [0, 0.24, -0.02]));
      g.add(box(0.07, 0.12, 0.08, darkMetal, [0, 0.24, -0.34]));
      g.add(cyl(0.075, 0.065, 0.72, 10, darkMetal, [0, 0.34, -0.22], [Math.PI / 2, 0, 0]));
      g.add(cyl(0.095, 0.078, 0.22, 10, accentGold, [0, 0.34, -0.62], [Math.PI / 2, 0, 0]));
      g.add(cyl(0.08, 0.08, 0.03, 10, accentBlue, [0, 0.34, -0.73], [Math.PI / 2, 0, 0]));
      break;
    }
  }

  return g;
}

/**
 * 3D Low-Poly Medkit & Shield Potion Pickups!
 */
export function createConsumableModel(kind = 'medkit') {
  const g = new THREE.Group();
  if (kind === 'medkit') {
    const white = flatMat(0xf5f9ff, { roughness: 0.4 });
    const red = flatMat(0xe63946, { emissive: 0xd90429, emissiveIntensity: 0.7 });
    g.add(box(0.95, 0.65, 0.55, white, [0, 0.35, 0]));
    g.add(box(0.36, 0.12, 0.14, flatMat(0x2b3648), [0, 0.72, 0]));
    // Red cross on both faces
    g.add(box(0.42, 0.14, 0.58, red, [0, 0.36, 0]));
    g.add(box(0.14, 0.42, 0.58, red, [0, 0.36, 0]));
  } else {
    // Shield Potion Bottle
    const glass = flatMat(0xd6f4ff, { transparent: true, opacity: 0.55, roughness: 0.1 });
    const shieldBlue = flatMat(0x29c7ff, { emissive: 0x00a8ff, emissiveIntensity: 1.3 });
    g.add(cyl(0.36, 0.42, 0.58, 8, glass, [0, 0.32, 0]));
    g.add(cyl(0.3, 0.35, 0.42, 8, shieldBlue, [0, 0.26, 0]));
    g.add(cyl(0.16, 0.18, 0.26, 8, glass, [0, 0.72, 0]));
    g.add(cyl(0.15, 0.15, 0.14, 8, flatMat(0x9c6644), [0, 0.88, 0]));
  }
  return g;
}

/**
 * Stylized 3D Low-Poly Hang-Glider / Parachute Canopy for Battle Royale Dropping!
 */
export function createGliderModel(primaryHex = 0x38d9ff, accentHex = 0xffd43b) {
  const g = new THREE.Group();
  const fabric = flatMat(primaryHex, { roughness: 0.6, emissive: primaryHex, emissiveIntensity: 0.25, side: THREE.DoubleSide });
  const trim = flatMat(accentHex, { roughness: 0.4, emissive: accentHex, emissiveIntensity: 0.35 });
  const frame = flatMat(0x232d3f, { metalness: 0.6 });

  // Swept wing canopy above character's head
  g.add(box(2.2, 0.12, 1.45, fabric, [0, 3.35, 0]));
  g.add(box(1.65, 0.11, 1.25, fabric, [-1.75, 3.12, 0.14], [0, 0.22, 0.26]));
  g.add(box(1.65, 0.11, 1.25, fabric, [1.75, 3.12, 0.14], [0, -0.22, -0.26]));
  g.add(box(2.26, 0.14, 0.22, trim, [0, 3.36, -0.66]));
  g.add(box(0.24, 0.14, 1.5, trim, [0, 3.36, 0]));

  // Struts + handlebar
  g.add(cyl(0.04, 0.04, 1.3, 6, frame, [-0.55, 2.7, 0], [0, 0, -0.25]));
  g.add(cyl(0.04, 0.04, 1.3, 6, frame, [0.55, 2.7, 0], [0, 0, 0.25]));
  g.add(cyl(0.045, 0.045, 1.35, 6, frame, [0, 2.1, 0], [0, 0, Math.PI / 2]));
  return g;
}

/**
 * Epic 3D Low-Poly Battle Royale Transport Airplane (with spinning propellers & navigation lights)!
 * Flies along -Z across the procedural open-world island!
 */
export function createBattlePlaneModel() {
  const plane = new THREE.Group();
  const bodyMat = flatMat(0x274c77, { roughness: 0.45, metalness: 0.35 });
  const stripeMat = flatMat(0xffd43b, { emissive: 0xffaa00, emissiveIntensity: 0.35, roughness: 0.35 });
  const wingMat = flatMat(0xe7ecef, { roughness: 0.5, metalness: 0.25 });
  const glassMat = flatMat(0x74e8ff, { emissive: 0x38d9ff, emissiveIntensity: 0.9, roughness: 0.1 });
  const darkMat = flatMat(0x1b2432, { metalness: 0.6 });
  const redLight = flatMat(0xff3b3b, { emissive: 0xff2a2a, emissiveIntensity: 1.6 });
  const greenLight = flatMat(0x3be384, { emissive: 0x22e06b, emissiveIntensity: 1.6 });

  // Main Cargo Fuselage
  plane.add(box(4.6, 4.2, 16.5, bodyMat, [0, 0, 0]));
  plane.add(box(4.75, 0.65, 16.6, stripeMat, [0, -0.4, 0]));
  // Tapered Nose & Cockpit
  plane.add(box(3.8, 3.2, 3.6, bodyMat, [0, -0.25, -9.8]));
  plane.add(box(2.6, 2.2, 2.4, darkMat, [0, -0.5, -12.4]));
  plane.add(box(3.5, 1.3, 2.2, glassMat, [0, 1.0, -8.8], [0.28, 0, 0]));
  // Open rear drop ramp!
  plane.add(box(3.6, 0.35, 3.8, darkMat, [0, -1.9, 9.6], [-0.25, 0, 0]));

  // Giant High Cargo Wings
  plane.add(box(26.5, 0.65, 4.6, wingMat, [0, 1.9, -1.2]));
  plane.add(box(26.7, 0.7, 0.85, stripeMat, [0, 1.92, -3.1]));
  plane.add(box(0.55, 0.55, 0.55, redLight, [-13.2, 1.95, -1.2]));
  plane.add(box(0.55, 0.55, 0.55, greenLight, [13.2, 1.95, -1.2]));

  // Tail Fin & Stabilizers
  plane.add(box(10.5, 0.45, 2.8, wingMat, [0, 1.2, 8.2]));
  plane.add(box(0.65, 5.4, 3.6, bodyMat, [0, 4.2, 7.6], [-0.18, 0, 0]));
  plane.add(box(0.75, 1.2, 3.2, stripeMat, [0, 5.6, 7.8]));

  // Twin Wing Engine Pods + Spinning 3D Propellers!
  const propellers = [];
  for (const sx of [-6.8, 6.8]) {
    plane.add(cyl(0.9, 0.78, 3.8, 8, darkMat, [sx, 1.2, -2.6], [Math.PI / 2, 0, 0]));
    const prop = new THREE.Group();
    prop.position.set(sx, 1.2, -4.7);
    prop.add(box(3.8, 0.28, 0.08, stripeMat));
    prop.add(box(0.28, 3.8, 0.08, stripeMat));
    prop.add(cyl(0.32, 0.32, 0.4, 6, redLight, [0, 0, -0.1], [Math.PI / 2, 0, 0]));
    plane.add(prop);
    propellers.push(prop);
  }

  plane.userData.animate = (t) => {
    for (const p of propellers) p.rotation.z = t * 28;
  };
  return plane;
}
