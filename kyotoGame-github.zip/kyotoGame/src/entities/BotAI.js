import * as THREE from 'three';
import { Fighter } from './Fighter.js';
import { POWERS } from '../powers/PowersData.js';
import { ARENA_RADIUS, getArenaTerrainHeight, getArenaWalkableHeight } from '../world/ArenaWorld.js';

const BOT_PROFILES = [
  { name: 'Kubo', powerId: 'pyro', skinHex: 0xf2c96b, shirtHex: 0xe63946, pantsHex: 0x243447, hairHex: 0x5c361a, hatStyle: 0, faceStyle: 0, backStyle: 1 },
  { name: 'Zéphyr', powerId: 'wind', skinHex: 0xffd7b5, shirtHex: 0x22b573, pantsHex: 0x2f4d36, hairHex: 0x1c1c24, hatStyle: 2, faceStyle: 2, backStyle: 0 },
  { name: 'Frosty', powerId: 'cryo', skinHex: 0x9cecff, shirtHex: 0x17c3e6, pantsHex: 0x243447, hairHex: 0xf0f6ff, hatStyle: 1, faceStyle: 1, backStyle: 3 },
  { name: 'Astra', powerId: 'gravity', skinHex: 0xf2c96b, shirtHex: 0x8338ec, pantsHex: 0x2b1e4d, hairHex: 0x9b4dff, hatStyle: 4, faceStyle: 3, backStyle: 1 },
  { name: 'Golem', powerId: 'earth', skinHex: 0xc68642, shirtHex: 0xff7b00, pantsHex: 0x5e1d2c, hairHex: 0x5c361a, hatStyle: 5, faceStyle: 4, backStyle: 0 },
  { name: 'Spectre', powerId: 'shadow', skinHex: 0x5c4b7d, shirtHex: 0x1d222e, pantsHex: 0x1c1f26, hairHex: 0x9b4dff, hatStyle: 7, faceStyle: 1, backStyle: 5 },
  { name: 'Nova', powerId: 'cyber', skinHex: 0xffd7b5, shirtHex: 0xff3b9a, pantsHex: 0x1c1f26, hairHex: 0x22a6ff, hatStyle: 6, faceStyle: 5, backStyle: 4 },
  { name: 'Draco', powerId: 'dragon', skinHex: 0xf1c27d, shirtHex: 0xf5b700, pantsHex: 0x5e1d2c, hairHex: 0xd92b2b, hatStyle: 9, faceStyle: 4, backStyle: 2 },
  { name: 'Poseidon', powerId: 'aqua', skinHex: 0xf2c96b, shirtHex: 0x2b7de9, pantsHex: 0x243447, hairHex: 0x22a6ff, hatStyle: 3, faceStyle: 0, backStyle: 1 },
  { name: 'Chronos', powerId: 'void', skinHex: 0xeef3fa, shirtHex: 0x8338ec, pantsHex: 0x1c1f26, hairHex: 0xf0f6ff, hatStyle: 8, faceStyle: 3, backStyle: 3 },
];

export class BotManager {
  constructor(arenaGroup) {
    this.arenaGroup = arenaGroup;
    this.bots = [];
    this._spawnAll();
  }

  _spawnAll() {
    BOT_PROFILES.forEach((prof, idx) => {
      const bot = new Fighter({
        id: `bot-${idx}`,
        name: prof.name,
        isPlayer: false,
        powerId: prof.powerId,
        appearance: {
          skinHex: prof.skinHex,
          shirtHex: prof.shirtHex,
          pantsHex: prof.pantsHex,
          hairHex: prof.hairHex,
          hatStyle: prof.hatStyle,
          faceStyle: prof.faceStyle,
          backStyle: prof.backStyle,
        },
      });
      bot.ai = {
        target: null,
        retargetTimer: Math.random() * 1.5,
        strafeDir: Math.random() < 0.5 ? 1 : -1,
        strafeTimer: 1 + Math.random() * 2,
        jumpTimer: 1 + Math.random() * 3,
      };
      bot.respawn(this.getRandomSpawnPos(idx));
      this.arenaGroup.add(bot.mesh);
      this.bots.push(bot);
    });
  }

  getRandomPowerId() {
    return POWERS[Math.floor(Math.random() * POWERS.length)].id;
  }

  getRandomSpawnPos(seedIdx = Math.floor(Math.random() * 10)) {
    const angle = (seedIdx / BOT_PROFILES.length) * Math.PI * 2 + Math.random() * 0.6;
    const dist = 16 + Math.random() * 36;
    const x = Math.cos(angle) * dist;
    const z = Math.sin(angle) * dist;
    const y = Math.max(0, getArenaTerrainHeight(x, z)) + 1.2;
    return new THREE.Vector3(x, y, z);
  }

  update(dt, t, allFighters, arenaWorld, powerExecutor, ctx) {
    for (const bot of this.bots) {
      // Bot respawn delay countdown
      if (bot.isDead) {
        bot.respawnTimer -= dt;
        bot._updateLimbAndKnockPose(dt, t);
        if (bot.respawnTimer < 2.8) {
          bot.mesh.visible = false;
        }
        if (bot.respawnTimer <= 0) {
          if (Math.random() < 0.45) bot.setPower(this.getRandomPowerId());
          const spawnPos = this.getRandomSpawnPos();
          bot.respawn(spawnPos);
          if (ctx.vfx) {
            ctx.vfx.spawnRing(spawnPos, bot.power.hex, 4.2, 0.45);
            ctx.vfx.spawnBurst(spawnPos.clone().add(new THREE.Vector3(0, 1.2, 0)), bot.power.hex, 12, 7, 0.2);
          }
        }
        continue;
      }

      bot.updateStatusAndTimers(dt, t, ctx);

      // Bot counter-punch attempt in Mode Combo
      if (bot.canCounterPunch() && Math.random() < dt * 2.5) {
        powerExecutor.castCounterPunch(bot, allFighters, ctx);
        continue;
      }

      if (bot.freezeTimer <= 0 && bot.chargeTimer <= 0 && bot.knockAnim <= 0.15 && bot.knockdownTimer <= 0) {
        bot.ai.retargetTimer -= dt;
        bot.ai.strafeTimer -= dt;
        bot.ai.jumpTimer -= dt;

        if (bot.ai.strafeTimer <= 0) {
          bot.ai.strafeTimer = 1.1 + Math.random() * 1.8;
          bot.ai.strafeDir *= -1;
        }

        if (bot.ai.retargetTimer <= 0 || !bot.ai.target || bot.ai.target.hp <= 0 || bot.ai.target.isDead) {
          bot.ai.retargetTimer = 1.8 + Math.random() * 1.8;
          let nearest = null;
          let bestDist = Infinity;
          for (const other of allFighters) {
            if (other === bot || other.hp <= 0 || other.isDead) continue;
            const d = other.position.distanceTo(bot.position);
            const score = other.isPlayer ? d * 0.72 : d;
            if (score < bestDist) {
              bestDist = score;
              nearest = other;
            }
          }
          bot.ai.target = nearest;
        }

        const moveDir = new THREE.Vector3();
        const distFromCenter = Math.hypot(bot.position.x, bot.position.z);

        if (distFromCenter > ARENA_RADIUS - 14) {
          moveDir.set(-bot.position.x, 0, -bot.position.z).normalize();
        } else if (bot.ai.target) {
          const toTarget = bot.ai.target.position.clone().sub(bot.position);
          const dist = Math.hypot(toTarget.x, toTarget.z);
          bot.yaw = Math.atan2(-toTarget.x, -toTarget.z);
          // Aim accurately at target's torso height so projectiles reliably connect
          bot.pitch = THREE.MathUtils.clamp(Math.atan2(toTarget.y, Math.max(2, dist)), -0.55, 0.5);

          const fwd = dist > 0.01 ? new THREE.Vector3(toTarget.x / dist, 0, toTarget.z / dist) : new THREE.Vector3(0, 0, -1);
          const right = new THREE.Vector3(-fwd.z, 0, fwd.x);

          if (dist > 3.2) moveDir.add(fwd);
          else if (dist < 1.8) moveDir.addScaledVector(fwd, -0.4);
          moveDir.addScaledVector(right, bot.ai.strafeDir * 0.5);

          // Responsive combat casting
          if (dist < bot.power.lmb.range + 0.6 && Math.abs(toTarget.y) < 3.5 && bot.lmbCd <= 0) {
            powerExecutor.castPrimary(bot, allFighters, ctx);
          } else if (dist > 3.5 && dist < 28 && bot.ab1Cd <= 0 && Math.random() < dt * 1.35) {
            powerExecutor.castAbility1(bot, allFighters, ctx);
          } else if (dist < 22 && bot.ab2Cd <= 0 && Math.random() < dt * 0.65) {
            powerExecutor.castAbility2(bot, allFighters, ctx);
          }
        }

        if (moveDir.lengthSq() > 0.01) {
          moveDir.normalize();
          const speed = 9.8 * bot.getSpeedMultiplier();
          bot.velocity.x = THREE.MathUtils.lerp(bot.velocity.x, moveDir.x * speed, Math.min(1, dt * 6.5));
          bot.velocity.z = THREE.MathUtils.lerp(bot.velocity.z, moveDir.z * speed, Math.min(1, dt * 6.5));
          if (distFromCenter > ARENA_RADIUS - 14) {
            bot.yaw = Math.atan2(-moveDir.x, -moveDir.z);
          }
        }

        if (bot.onGround && bot.ai.jumpTimer <= 0) {
          bot.ai.jumpTimer = 1.8 + Math.random() * 3.0;
          bot.velocity.y = 11.8;
          bot.onGround = false;
        }
      }

      bot.velocity.y -= 30 * dt;
      bot.position.addScaledVector(bot.velocity, dt);
      arenaWorld.resolveObstacles(bot.position, 0.7 * bot.currentScale);

      const groundY = getArenaWalkableHeight(bot.position.x, bot.position.z, bot.position.y);
      if (bot.position.y <= groundY && groundY > -20) {
        bot.position.y = groundY;
        bot.velocity.y = 0;
        bot.onGround = true;
      } else if (bot.position.y > groundY + 0.25) {
        bot.onGround = false;
      }

      for (const pad of arenaWorld.jumpPads) {
        if (bot.onGround && bot.position.distanceTo(pad.position) < pad.radius) {
          bot.velocity.y = 24;
          bot.onGround = false;
        }
      }

      if (bot.position.y < -20) {
        ctx.onKO(bot, bot.lastAttacker);
      }
    }
  }
}
