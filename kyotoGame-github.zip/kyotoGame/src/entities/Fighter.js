import * as THREE from 'three';
import { POWER_MAP } from '../powers/PowersData.js';
import { createCharacterRig, createBotNameplate } from '../models/LowPolyModels.js';

export class Fighter {
  constructor({
    id,
    name,
    isPlayer = false,
    isRemotePlayer = false,
    powerId = 'thunder',
    appearance = {},
  }) {
    this.id = id;
    this.name = name;
    this.isPlayer = isPlayer;
    this.isRemotePlayer = isRemotePlayer;
    this.remoteZone = 'dojo';
    this.targetPos = new THREE.Vector3();
    this.targetYaw = 0;
    this.targetPitch = 0;

    this.rig = createCharacterRig(appearance);
    this.mesh = this.rig.root;

    this.position = new THREE.Vector3(0, 0, 0);
    this.velocity = new THREE.Vector3(0, 0, 0);
    this.yaw = 0;
    this.pitch = 0;
    this.onGround = true;

    this.maxHp = 100;
    this.hp = 100;
    this.maxShield = 50;
    this.shield = 0;
    this.hits = 0;
    this.kos = 0;
    this.lastAttacker = null;
    this.lastHitTime = 0;

    // Cooldowns
    this.lmbCd = 0;
    this.ab1Cd = 0;
    this.ab2Cd = 0;
    this.ab3Cd = 0;
    this.dashCd = 0;
    this.hasPower = true;
    this.isGliding = false;
    this.equippedGunId = null;

    // Status timers
    this.burnTimer = 0;
    this.burnTick = 0;
    this.poisonTimer = 0;
    this.poisonTick = 0;
    this.slowTimer = 0;
    this.freezeTimer = 0;
    this.chronoSlowTimer = 0;
    this.titanTimer = 0;
    this.invulnTimer = 0;
    this.zeroGTimer = 0;
    this.chargeTimer = 0;
    this.chargeDir = new THREE.Vector3();
    this.chargeHitIds = new Set();

    // Animation, Knockdown (Mode Combo) & K.O. / Respawn state
    this.walkCycle = 0;
    this.attackAnim = 0;
    this.attackSide = 1;
    this.hurtAnim = 0;
    this.knockAnim = 0;
    this.knockTiltSide = 1;
    this.hitFlashTimer = 0;
    this.knockdownTimer = 0;      // Remaining time on ground (starts at 1.6s)
    this.knockdownElapsed = 0;    // Elapsed time on ground (counter unlocks at 1.1s!)
    this.counterAnim = 0;
    this.comboCount = 0;
    this.comboResetTimer = 0;
    this.isDead = false;
    this.respawnTimer = 0;
    this.footstepTimer = 0;
    this.currentScale = 1;

    // Chrono Rewind history buffer (last 3.5s)
    this.history = [];
    this._historyTick = 0;

    // Bot nameplate
    this.nameplate = null;
    this.setPower(powerId);
  }

  setPower(powerId) {
    if (!powerId) {
      this.hasPower = false;
      this.powerId = null;
      this.power = POWER_MAP.thunder;
      this.rig.setPowerModel(null, 0x38d9ff);
      return;
    }
    this.hasPower = true;
    this.powerId = powerId;
    this.power = POWER_MAP[powerId] || POWER_MAP.thunder;
    if (!this.equippedGunId) {
      this.rig.setPowerModel(this.powerId, this.power.hex);
    }

    if (!this.isPlayer) {
      if (this.nameplate) this.mesh.remove(this.nameplate);
      const labelTitle = this.isRemotePlayer ? `★ ${this.name}` : this.name;
      const subLabel = this.isRemotePlayer ? `JOUEUR • ${this.power.name}` : this.power.name;
      this.nameplate = createBotNameplate(labelTitle, subLabel, this.power.color);
      this.nameplate.position.set(0, 3.05, 0);
      this.mesh.add(this.nameplate);
      this.nameplate.userData.updateHP(this.hp / this.maxHp);
    }
  }

  setEquippedGun(weaponId) {
    this.equippedGunId = weaponId || null;
    if (weaponId) {
      this.rig.setGunModel(weaponId);
    } else if (this.hasPower && this.powerId) {
      this.rig.setPowerModel(this.powerId, this.power.hex);
    } else {
      this.rig.setPowerModel(null, 0x38d9ff);
    }
  }

  applyAppearance(app) {
    this.rig.applyAppearance(app);
  }

  applyRemoteState(s) {
    this.targetPos.set(s.x || 0, s.y || 0, s.z || 0);
    this.velocity.set(s.vx || 0, s.vy || 0, s.vz || 0);
    this.targetYaw = s.yaw || 0;
    this.targetPitch = s.pitch || 0;
    this.remoteZone = s.zone || 'dojo';
    this.hp = typeof s.hp === 'number' ? s.hp : this.hp;
    this.shield = typeof s.shield === 'number' ? s.shield : this.shield;
    this.hits = typeof s.hits === 'number' ? s.hits : this.hits;
    this.kos = typeof s.kos === 'number' ? s.kos : this.kos;
    this.titanTimer = s.titan ? 1 : 0;
    this.freezeTimer = s.frozen ? 1 : 0;
    this.knockdownTimer = s.knockedDown ? 1.0 : 0;
    this.isDead = Boolean(s.isDead);
    this.isGliding = Boolean(s.isGliding);
    if (s.powerId !== this.powerId) {
      this.setPower(s.powerId);
    }
    if ((s.gunId || null) !== this.equippedGunId) {
      this.setEquippedGun(s.gunId || null);
    }
    if (this.rig.gliderMesh) this.rig.gliderMesh.visible = this.isGliding;
    if (this.rig.shieldBubble) this.rig.shieldBubble.visible = this.shield > 0 && !this.isDead;
    if (this.nameplate) {
      this.nameplate.userData.updateHP(Math.max(0, Math.min(1, this.hp / this.maxHp)));
    }
  }

  interpolateRemote(dt, t) {
    const alpha = Math.min(1, dt * 14);
    if (this.position.distanceTo(this.targetPos) > 12) {
      this.position.copy(this.targetPos);
    } else {
      this.position.lerp(this.targetPos, alpha);
    }
    // Shortest-angle yaw lerp
    let dy = this.targetYaw - this.yaw;
    while (dy > Math.PI) dy -= Math.PI * 2;
    while (dy < -Math.PI) dy += Math.PI * 2;
    this.yaw += dy * alpha;
    this.pitch += (this.targetPitch - this.pitch) * alpha;
    this.attackAnim = Math.max(0, this.attackAnim - dt);

    const targetScale = this.titanTimer > 0 ? 1.95 : 1.0;
    this.currentScale = THREE.MathUtils.lerp(this.currentScale, targetScale, Math.min(1, dt * 8));
    this.mesh.scale.setScalar(this.currentScale);
    this.rig.iceBlock.visible = this.freezeTimer > 0;
    this.mesh.position.copy(this.position);
    this.mesh.rotation.y = this.yaw;
    this._updateLimbAndKnockPose(dt, t);
  }

  getForwardDirection(includePitch = false) {
    const dir = new THREE.Vector3(0, 0, -1);
    if (includePitch) {
      const euler = new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ');
      dir.applyEuler(euler);
    } else {
      dir.applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw);
    }
    return dir.normalize();
  }

  getEyePosition() {
    const h = 1.95 * this.currentScale;
    return new THREE.Vector3(this.position.x, this.position.y + h, this.position.z);
  }

  getSpeedMultiplier() {
    if (this.freezeTimer > 0) return 0;
    let m = 1;
    if (this.chronoSlowTimer > 0) m *= 0.24;
    if (this.slowTimer > 0) m *= 0.55;
    if (this.titanTimer > 0) m *= 1.12;
    return m;
  }

  heal(amount) {
    this.hp = Math.min(this.maxHp, this.hp + amount);
    if (this.nameplate) this.nameplate.userData.updateHP(this.hp / this.maxHp);
  }

  triggerAttackAnim() {
    this.attackAnim = 0.28;
    this.attackSide *= -1;
  }

  triggerKnockAnim(strength = 1) {
    this.hurtAnim = 0.36;
    this.hitFlashTimer = 0.2;
    this.knockTiltSide = Math.random() < 0.5 ? 1 : -1;
    if (strength >= 12) {
      this.knockAnim = Math.min(0.85, 0.35 + strength * 0.02);
    }
  }

  triggerKnockdown(vfx, sound) {
    if (this.isDead) return;
    const wasDown = this.knockdownTimer > 0;
    if (!wasDown) {
      this.knockdownTimer = 1.6;
      this.knockdownElapsed = 0;
      if (sound && this.isPlayer) sound.playKnockdown();
      if (vfx) {
        vfx.spawnRing(this.position, 0xffd43b, 3.4, 0.35);
        vfx.spawnBurst(this.position.clone().add(new THREE.Vector3(0, 0.35, 0)), 0xe8d5b7, 8, 6, 0.18);
      }
    } else {
      // Follow-up combo hit keeps them grounded slightly longer, while never resetting knockdownElapsed so 1.1s counter stays fair
      this.knockdownTimer = Math.max(this.knockdownTimer, 0.72);
    }
  }

  canCounterPunch() {
    return !this.isDead && this.knockdownTimer > 0 && this.knockdownElapsed >= 1.1;
  }

  enterKOState(respawnDelay = 3.0) {
    this.isDead = true;
    this.respawnTimer = respawnDelay;
    this.hp = 0;
    this.burnTimer = 0;
    this.poisonTimer = 0;
    this.freezeTimer = 0;
    this.zeroGTimer = 0;
    this.chargeTimer = 0;
    this.knockdownTimer = 0;
    this.knockdownElapsed = 0;
    this.comboCount = 0;
    if (this.nameplate) this.nameplate.userData.updateHP(0);
  }

  takeDamage(amount, knockbackVec, attacker, { vfx, sound, camera, onKO, onHitConfirm, onRemoteHit, status, visualOnly, comboMode, isDoT } = {}) {
    if (visualOnly || this.isDead || this.invulnTimer > 0 || amount <= 0) return false;

    const dmg = Math.round(this.titanTimer > 0 ? amount * 0.6 : amount);
    const kbMag = knockbackVec ? knockbackVec.length() : 0;

    // Remote human players receive authoritative damage over WebSocket + instant visual knock recoil
    if (this.isRemotePlayer) {
      if (attacker && attacker.isPlayer) {
        attacker.hits += 1;
        if (comboMode && !isDoT) {
          attacker.comboCount += 1;
          attacker.comboResetTimer = 2.6;
        }
        this.triggerKnockAnim(Math.max(12, kbMag));
        const sendStatus = { ...(status || {}) };
        if (comboMode && !isDoT) sendStatus.knockdown = true;
        if (onHitConfirm) onHitConfirm(attacker, this, dmg);
        if (onRemoteHit) onRemoteHit(this, dmg, knockbackVec, sendStatus);
        if (vfx && camera) {
          const textPos = this.position.clone().add(new THREE.Vector3(0, 2.3 * this.currentScale, 0));
          vfx.spawnFloatingText(textPos, `-${dmg}`, dmg >= 20 ? '#ff6b6b' : '#ffe066', camera);
        }
      }
      return false;
    }

    // Shield absorbs damage before HP
    let remDmg = dmg;
    if (this.shield > 0) {
      const absorbed = Math.min(this.shield, remDmg);
      this.shield -= absorbed;
      remDmg -= absorbed;
    }
    this.hp = Math.max(0, this.hp - remDmg);
    this.triggerKnockAnim(Math.max(10, kbMag));
    if (comboMode && !isDoT && this.hp > 0) {
      this.triggerKnockdown(vfx, sound);
    }
    if (attacker && attacker !== this && comboMode && !isDoT) {
      attacker.comboCount += 1;
      attacker.comboResetTimer = 2.6;
    }
    if (this.nameplate) this.nameplate.userData.updateHP(this.hp / this.maxHp);

    if (knockbackVec) {
      const resist = this.titanTimer > 0 ? 0.45 : 1.0;
      this.velocity.addScaledVector(knockbackVec, resist);
      if (knockbackVec.y > 2) this.onGround = false;
    }

    if (attacker && attacker !== this) {
      this.lastAttacker = attacker;
      this.lastHitTime = performance.now();
      attacker.hits += 1;
      if (onHitConfirm) onHitConfirm(attacker, this, dmg);
    } else if (this.isPlayer && onHitConfirm) {
      onHitConfirm(attacker || this, this, dmg);
    }

    if (this.isPlayer && sound) {
      sound.playPlayerHurt();
    }

    if (vfx && camera) {
      const textPos = this.position.clone().add(new THREE.Vector3(0, 2.3 * this.currentScale, 0));
      vfx.spawnFloatingText(textPos, `-${dmg}`, this.isPlayer ? '#ff4d6d' : dmg >= 20 ? '#ff6b6b' : '#ffe066', camera);
    }

    if (this.hp <= 0) {
      if (onKO) onKO(this, attacker || this.lastAttacker);
      return true;
    }
    return false;
  }

  respawn(pos) {
    this.isDead = false;
    this.respawnTimer = 0;
    this.position.copy(pos);
    this.velocity.set(0, 0, 0);
    this.hp = this.maxHp;
    this.burnTimer = 0;
    this.poisonTimer = 0;
    this.slowTimer = 0;
    this.freezeTimer = 0;
    this.chronoSlowTimer = 0;
    this.zeroGTimer = 0;
    this.chargeTimer = 0;
    this.hurtAnim = 0;
    this.knockAnim = 0;
    this.hitFlashTimer = 0;
    this.knockdownTimer = 0;
    this.knockdownElapsed = 0;
    this.counterAnim = 0;
    this.comboCount = 0;
    this.comboResetTimer = 0;
    this.invulnTimer = 1.2;
    this.lastAttacker = null;
    this.history = [];
    this.rig.body.rotation.set(0, 0, 0);
    this.rig.body.position.set(0, 0, 0);
    this.mesh.visible = true;
    if (this.nameplate) this.nameplate.userData.updateHP(1);
  }

  _applyHitFlash() {
    const flashing = this.hitFlashTimer > 0;
    this.rig.body.traverse((obj) => {
      if (obj.isMesh && obj.material && !Array.isArray(obj.material) && obj.material.emissive && !obj.userData.isGlowPart) {
        if (flashing) {
          if (obj.userData.origEmissive === undefined) {
            obj.userData.origEmissive = obj.material.emissive.getHex();
            obj.userData.origEmissiveInt = obj.material.emissiveIntensity;
          }
          obj.material.emissive.setHex(0xff3344);
          obj.material.emissiveIntensity = 0.85;
        } else if (obj.userData.origEmissive !== undefined) {
          obj.material.emissive.setHex(obj.userData.origEmissive);
          obj.material.emissiveIntensity = obj.userData.origEmissiveInt;
          delete obj.userData.origEmissive;
          delete obj.userData.origEmissiveInt;
        }
      }
    });
  }

  _updateLimbAndKnockPose(dt, t) {
    this.hurtAnim = Math.max(0, this.hurtAnim - dt);
    this.knockAnim = Math.max(0, this.knockAnim - dt);
    this.counterAnim = Math.max(0, this.counterAnim - dt);
    if (this.hitFlashTimer > 0) {
      this.hitFlashTimer = Math.max(0, this.hitFlashTimer - dt);
      this._applyHitFlash();
    }

    // Collapsed K.O. pose when dead
    if (this.isDead) {
      this.rig.body.rotation.x = THREE.MathUtils.lerp(this.rig.body.rotation.x, -Math.PI * 0.48, Math.min(1, dt * 10));
      this.rig.body.position.y = THREE.MathUtils.lerp(this.rig.body.position.y, 0.35, Math.min(1, dt * 10));
      this.rig.leftArmPivot.rotation.x = -1.4;
      this.rig.rightArmPivot.rotation.x = -1.3;
      this.rig.leftArmPivot.rotation.z = 0.7;
      this.rig.rightArmPivot.rotation.z = -0.7;
      return;
    }

    // Mode Combo Ground Knockdown Animation (falls flat -> recovers cleanly in last 0.28s)
    if (this.knockdownTimer > 0) {
      const standRatio = this.knockdownTimer < 0.28 ? 1 - this.knockdownTimer / 0.28 : 0;
      const flatAmt = 1 - standRatio;
      this.rig.body.rotation.x = THREE.MathUtils.lerp(this.rig.body.rotation.x, -Math.PI * 0.47 * flatAmt, Math.min(1, dt * 14));
      this.rig.body.rotation.z = THREE.MathUtils.lerp(this.rig.body.rotation.z, 0.16 * this.knockTiltSide * flatAmt, Math.min(1, dt * 12));
      this.rig.body.position.y = THREE.MathUtils.lerp(this.rig.body.position.y, 0.28 * flatAmt, Math.min(1, dt * 14));
      this.rig.leftArmPivot.rotation.x = -1.55 * flatAmt;
      this.rig.rightArmPivot.rotation.x = -1.45 * flatAmt;
      this.rig.leftArmPivot.rotation.z = 0.65 * flatAmt;
      this.rig.rightArmPivot.rotation.z = -0.65 * flatAmt;
      this.rig.leftLegPivot.rotation.x = 0.35 * flatAmt;
      this.rig.rightLegPivot.rotation.x = -0.22 * flatAmt;

      // Golden shimmer pulse on aura ring when 1.1s Counter-Punch window is OPEN
      if (this.knockdownElapsed >= 1.1) {
        this.rig.auraRing.material.color.setHex(0xffd43b);
        this.rig.auraRing.material.opacity = 0.85 + Math.sin(t * 22) * 0.15;
      }
      if (this.rig.powerMesh && this.rig.powerMesh.userData.animate) {
        this.rig.powerMesh.userData.animate(t);
      }
      return;
    } else {
      this.rig.auraRing.material.color.setHex(this.power.hex);
      this.rig.auraRing.material.opacity = 0.45;
    }

    if (this.counterAnim > 0) {
      const p = Math.sin((this.counterAnim / 0.35) * Math.PI);
      this.rig.body.rotation.x = 0.32 * p;
      this.rig.body.rotation.z = 0;
      this.rig.body.position.y = 0.2 * p;
      this.rig.rightArmPivot.rotation.x = -2.4 * p;
      this.rig.leftArmPivot.rotation.x = 0.6 * p;
      return;
    }

    const horizSpeed = Math.hypot(this.velocity.x, this.velocity.z);
    if (this.knockAnim > 0) {
      // Dramatic cartoon knockback tumble/flail animation
      const k = Math.min(1, this.knockAnim / 0.45);
      this.rig.body.rotation.x = THREE.MathUtils.lerp(this.rig.body.rotation.x, -0.75 * k, Math.min(1, dt * 16));
      this.rig.body.rotation.z = THREE.MathUtils.lerp(this.rig.body.rotation.z, 0.42 * k * this.knockTiltSide, Math.min(1, dt * 16));
      this.rig.body.position.y = THREE.MathUtils.lerp(this.rig.body.position.y, 0.15 * k, Math.min(1, dt * 12));
      this.rig.leftArmPivot.rotation.x = -1.85 * k;
      this.rig.rightArmPivot.rotation.x = -1.75 * k;
      this.rig.leftArmPivot.rotation.z = 0.75 * k;
      this.rig.rightArmPivot.rotation.z = -0.75 * k;
      this.rig.leftLegPivot.rotation.x = 0.65 * k;
      this.rig.rightLegPivot.rotation.x = -0.45 * k;
    } else if (this.hurtAnim > 0) {
      // Snappy hit-stagger recoil
      const p = Math.sin((this.hurtAnim / 0.36) * Math.PI);
      this.rig.body.rotation.x = -0.42 * p;
      this.rig.body.rotation.z = 0.24 * p * this.knockTiltSide;
      this.rig.body.position.y = 0;
      this.rig.leftArmPivot.rotation.x = -1.1 * p;
      this.rig.rightArmPivot.rotation.x = -1.0 * p;
      this.rig.leftArmPivot.rotation.z = 0.4 * p;
      this.rig.rightArmPivot.rotation.z = -0.4 * p;
    } else {
      this.rig.body.rotation.x *= 0.82;
      this.rig.body.rotation.z *= 0.82;
      this.rig.body.position.y *= 0.82;
      this.rig.leftArmPivot.rotation.z *= 0.82;

      if (horizSpeed > 0.6 && this.onGround && this.freezeTimer <= 0) {
        this.walkCycle += dt * horizSpeed * 1.15;
        const swing = Math.sin(this.walkCycle) * 0.72;
        this.rig.leftLegPivot.rotation.x = swing;
        this.rig.rightLegPivot.rotation.x = -swing;
        this.rig.leftArmPivot.rotation.x = -swing * 0.75;
        if (this.attackAnim <= 0) this.rig.rightArmPivot.rotation.x = swing * 0.75;
      } else {
        this.rig.leftLegPivot.rotation.x *= 0.85;
        this.rig.rightLegPivot.rotation.x *= 0.85;
        this.rig.leftArmPivot.rotation.x *= 0.85;
        if (this.attackAnim <= 0) this.rig.rightArmPivot.rotation.x *= 0.85;
      }

      if (this.attackAnim > 0) {
        const p = 1 - this.attackAnim / 0.28;
        const punchAngle = Math.sin(p * Math.PI) * 1.65;
        this.rig.rightArmPivot.rotation.x = -punchAngle;
        this.rig.rightArmPivot.rotation.z = -Math.sin(p * Math.PI) * 0.35;
      } else {
        this.rig.rightArmPivot.rotation.z *= 0.82;
      }
    }

    if (this.rig.powerMesh && this.rig.powerMesh.userData.animate) {
      this.rig.powerMesh.userData.animate(t);
    }
  }

  updateStatusAndTimers(dt, t, { vfx, sound, camera, onKO } = {}) {
    this.lmbCd = Math.max(0, this.lmbCd - dt);
    this.ab1Cd = Math.max(0, this.ab1Cd - dt);
    this.ab2Cd = Math.max(0, this.ab2Cd - dt);
    this.ab3Cd = Math.max(0, this.ab3Cd - dt);
    this.dashCd = Math.max(0, this.dashCd - dt);
    if (this.rig.gliderMesh) this.rig.gliderMesh.visible = this.isGliding;
    if (this.rig.shieldBubble) this.rig.shieldBubble.visible = this.shield > 0 && !this.isDead;
    this.invulnTimer = Math.max(0, this.invulnTimer - dt);
    this.slowTimer = Math.max(0, this.slowTimer - dt);
    this.freezeTimer = Math.max(0, this.freezeTimer - dt);
    this.chronoSlowTimer = Math.max(0, this.chronoSlowTimer - dt);
    this.titanTimer = Math.max(0, this.titanTimer - dt);
    this.attackAnim = Math.max(0, this.attackAnim - dt);

    // Mode Combo Knockdown timer (1.6s total, 1.1s counter window)
    if (this.knockdownTimer > 0) {
      this.knockdownElapsed += dt;
      this.knockdownTimer = Math.max(0, this.knockdownTimer - dt);
      if (this.knockdownTimer <= 0) {
        this.knockdownElapsed = 0;
        this.invulnTimer = Math.max(this.invulnTimer, 0.35);
      }
    }

    // Combo streak timeout
    if (this.comboResetTimer > 0) {
      this.comboResetTimer -= dt;
      if (this.comboResetTimer <= 0) {
        this.comboCount = 0;
      }
    }

    // Passive gentle HP regen if out of combat for 6s
    if (this.hp < this.maxHp && performance.now() - this.lastHitTime > 6000) {
      this.heal(dt * 3.5);
    }

    // Burn DoT
    if (this.burnTimer > 0) {
      this.burnTimer -= dt;
      this.burnTick -= dt;
      if (this.burnTick <= 0) {
        this.burnTick = 0.6;
        this.takeDamage(4, null, this.lastAttacker, { vfx, sound, camera, onKO, isDoT: true });
        if (vfx) vfx.spawnBurst(this.position.clone().add(new THREE.Vector3(0, 1.3, 0)), 0xff6b2b, 4, 3, 0.16, 2, 0.35);
      }
    }

    // Poison DoT
    if (this.poisonTimer > 0) {
      this.poisonTimer -= dt;
      this.poisonTick -= dt;
      if (this.poisonTick <= 0) {
        this.poisonTick = 0.65;
        this.takeDamage(4, null, this.lastAttacker, { vfx, sound, camera, onKO, isDoT: true });
        if (vfx) vfx.spawnBurst(this.position.clone().add(new THREE.Vector3(0, 1.2, 0)), 0x5df249, 4, 2.5, 0.15, -2, 0.4);
      }
    }

    // Zero-G suspension
    if (this.zeroGTimer > 0) {
      this.zeroGTimer -= dt;
      this.velocity.y = THREE.MathUtils.lerp(this.velocity.y, 1.5, dt * 4);
      if (this.zeroGTimer <= 0) {
        // Slam downward
        this.velocity.y = -28;
        if (vfx) vfx.spawnRing(this.position, 0xb15cff, 3.5, 0.35, 0.5);
      }
    }

    // Titan smooth scale
    const targetScale = this.titanTimer > 0 ? 1.95 : 1.0;
    this.currentScale = THREE.MathUtils.lerp(this.currentScale, targetScale, Math.min(1, dt * 6));
    this.mesh.scale.setScalar(this.currentScale);

    // Record Chrono Rewind history
    this._historyTick += dt;
    if (this._historyTick >= 0.1) {
      this._historyTick = 0;
      this.history.push({ pos: this.position.clone(), hp: this.hp });
      if (this.history.length > 35) this.history.shift();
    }

    // Frozen block visibility
    this.rig.iceBlock.visible = this.freezeTimer > 0;

    // Update 3D mesh transform & limb/knock animation
    this.mesh.position.copy(this.position);
    this.mesh.rotation.y = this.yaw;
    this._updateLimbAndKnockPose(dt, t);
  }
}
