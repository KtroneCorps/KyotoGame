/**
 * 100% Procedural Web Audio Engine
 * - STRICTLY ZERO MUSIC (no melodies, no musical loops)
 * - Rich atmospheric background soundscapes (Dojo wooden warmth + fire crackle + portal hum; Arena wind + leaves + distant nature birds)
 * - Bespoke SFX for footsteps, jumps, UI, impacts, and all 12 powers
 */
export class SoundEngine {
  constructor() {
    this.ctx = null;
    this.initialized = false;
    this.sfxVolume = 0.8;
    this.ambienceVolume = 0.7;
    this.ambienceEnabled = true;
    this.currentZone = 'dojo';

    this.sfxGain = null;
    this.ambienceMaster = null;
    this.dojoGain = null;
    this.arenaGain = null;
    this.portalGain = null;
    this.noiseBuffer = null;

    this._ambientTimer = 0;
    this._windLfoPhase = 0;
  }

  init() {
    if (this.initialized) {
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      return;
    }

    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;

    this.ctx = new AudioCtx();
    this.initialized = true;

    this.sfxGain = this.ctx.createGain();
    this.sfxGain.gain.value = this.sfxVolume;
    this.sfxGain.connect(this.ctx.destination);

    this.ambienceMaster = this.ctx.createGain();
    this.ambienceMaster.gain.value = this.ambienceEnabled ? this.ambienceVolume : 0;
    this.ambienceMaster.connect(this.ctx.destination);

    this.noiseBuffer = this._createPinkNoiseBuffer(4);
    this._setupAmbienceLayers();
    this.setZone(this.currentZone);
  }

  _createPinkNoiseBuffer(seconds) {
    const sampleRate = this.ctx.sampleRate;
    const length = sampleRate * seconds;
    const buffer = this.ctx.createBuffer(1, length, sampleRate);
    const data = buffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < length; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.045;
      b6 = white * 0.115926;
    }
    return buffer;
  }

  _setupAmbienceLayers() {
    // --- DOJO AMBIENCE (warm indoor wooden room tone + lantern air) ---
    this.dojoGain = this.ctx.createGain();
    this.dojoGain.gain.value = 1;
    this.dojoGain.connect(this.ambienceMaster);

    const dojoNoise = this.ctx.createBufferSource();
    dojoNoise.buffer = this.noiseBuffer;
    dojoNoise.loop = true;

    const dojoFilter = this.ctx.createBiquadFilter();
    dojoFilter.type = 'lowpass';
    dojoFilter.frequency.value = 210;

    const dojoBedGain = this.ctx.createGain();
    dojoBedGain.gain.value = 0.45;
    dojoNoise.connect(dojoFilter).connect(dojoBedGain).connect(this.dojoGain);
    dojoNoise.start();

    // Spatialized Portal Energy Hum (non-musical swirling air resonance)
    this.portalGain = this.ctx.createGain();
    this.portalGain.gain.value = 0.05;
    this.portalGain.connect(this.dojoGain);

    const portalNoise = this.ctx.createBufferSource();
    portalNoise.buffer = this.noiseBuffer;
    portalNoise.loop = true;

    this.portalFilter = this.ctx.createBiquadFilter();
    this.portalFilter.type = 'bandpass';
    this.portalFilter.frequency.value = 340;
    this.portalFilter.Q.value = 5.5;

    portalNoise.connect(this.portalFilter).connect(this.portalGain);
    portalNoise.start();

    // --- ARENA AMBIENCE (outdoor meadow wind + pine tree rustle) ---
    this.arenaGain = this.ctx.createGain();
    this.arenaGain.gain.value = 0;
    this.arenaGain.connect(this.ambienceMaster);

    // Low rolling meadow wind
    const windLow = this.ctx.createBufferSource();
    windLow.buffer = this.noiseBuffer;
    windLow.loop = true;

    this.windFilterLow = this.ctx.createBiquadFilter();
    this.windFilterLow.type = 'bandpass';
    this.windFilterLow.frequency.value = 320;
    this.windFilterLow.Q.value = 1.4;

    const windLowGain = this.ctx.createGain();
    windLowGain.gain.value = 0.55;
    windLow.connect(this.windFilterLow).connect(windLowGain).connect(this.arenaGain);
    windLow.start();

    // High pine needles rustle
    const windHigh = this.ctx.createBufferSource();
    windHigh.buffer = this.noiseBuffer;
    windHigh.loop = true;

    this.windFilterHigh = this.ctx.createBiquadFilter();
    this.windFilterHigh.type = 'highpass';
    this.windFilterHigh.frequency.value = 1600;

    this.windHighGain = this.ctx.createGain();
    this.windHighGain.gain.value = 0.14;
    windHigh.connect(this.windFilterHigh).connect(this.windHighGain).connect(this.arenaGain);
    windHigh.start();
  }

  setZone(zone) {
    this.currentZone = zone;
    if (!this.initialized) return;
    const now = this.ctx.currentTime;
    const isDojo = zone === 'dojo';
    this.dojoGain.gain.setTargetAtTime(isDojo ? 1.0 : 0.0, now, 0.35);
    this.arenaGain.gain.setTargetAtTime(isDojo ? 0.0 : 1.0, now, 0.35);
  }

  setSfxVolume(val) {
    this.sfxVolume = val;
    if (this.sfxGain) this.sfxGain.gain.setTargetAtTime(val, this.ctx.currentTime, 0.05);
  }

  setAmbienceVolume(val) {
    this.ambienceVolume = val;
    this._syncAmbienceMaster();
  }

  setAmbienceEnabled(enabled) {
    this.ambienceEnabled = enabled;
    this._syncAmbienceMaster();
  }

  _syncAmbienceMaster() {
    if (!this.ambienceMaster) return;
    const target = this.ambienceEnabled ? this.ambienceVolume : 0;
    this.ambienceMaster.gain.setTargetAtTime(target, this.ctx.currentTime, 0.12);
  }

  updateAmbience(dt, portalDistance = 30) {
    if (!this.initialized || !this.ambienceEnabled) return;
    const now = this.ctx.currentTime;
    this._windLfoPhase += dt;

    if (this.currentZone === 'dojo') {
      // Spatial portal swirl volume based on distance
      const prox = Math.max(0, 1 - portalDistance / 20);
      this.portalGain.gain.setTargetAtTime(0.03 + prox * prox * 0.55, now, 0.1);
      this.portalFilter.frequency.setTargetAtTime(280 + Math.sin(this._windLfoPhase * 2.4) * 90 + prox * 160, now, 0.1);

      // Subtle random lantern ember crackle / wood settle
      this._ambientTimer -= dt;
      if (this._ambientTimer <= 0) {
        this._ambientTimer = 0.6 + Math.random() * 1.9;
        this._playLanternCrackle();
      }
    } else {
      // Natural wind gusts modulating filter cutoff
      const gust = Math.sin(this._windLfoPhase * 0.35) * 0.5 + Math.sin(this._windLfoPhase * 0.87) * 0.3 + 0.5;
      this.windFilterLow.frequency.setTargetAtTime(220 + gust * 290, now, 0.25);
      this.windHighGain.gain.setTargetAtTime(0.08 + gust * 0.16, now, 0.25);

      // Occasional distant naturalistic bird chirp / rustle
      this._ambientTimer -= dt;
      if (this._ambientTimer <= 0) {
        this._ambientTimer = 2.8 + Math.random() * 4.5;
        this._playDistantNatureSound();
      }
    }
  }

  _playLanternCrackle() {
    if (!this.initialized || !this.ambienceEnabled) return;
    const now = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 1800 + Math.random() * 2400;
    filter.Q.value = 4;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(0.08 + Math.random() * 0.06, now + 0.005);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.045);

    src.connect(filter).connect(gain).connect(this.dojoGain);
    src.start(now, Math.random() * 2, 0.06);
  }

  _playDistantNatureSound() {
    if (!this.initialized || !this.ambienceEnabled) return;
    const now = this.ctx.currentTime;
    // Naturalistic short distant bird chirp (2 quick organic pitch sweeps)
    const chirps = Math.random() < 0.5 ? 1 : 2;
    const baseFreq = 2300 + Math.random() * 1400;
    for (let i = 0; i < chirps; i++) {
      const t = now + i * (0.11 + Math.random() * 0.06);
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreq, t);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * (1.2 + Math.random() * 0.25), t + 0.045);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 0.92, t + 0.09);

      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.018 + Math.random() * 0.014, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.095);

      osc.connect(g).connect(this.arenaGain);
      osc.start(t);
      osc.stop(t + 0.1);
    }
  }

  // --- HELPER SYNTHS ---
  _tone(type, startFreq, endFreq, dur, vol = 0.2, delay = 0) {
    if (!this.initialized) return;
    const t = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(20, startFreq), t);
    if (endFreq !== startFreq) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), t + dur);
    }
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + Math.min(0.015, dur * 0.2));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g).connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }

  _noise(filterType, freqStart, freqEnd, dur, vol = 0.25, q = 1, delay = 0) {
    if (!this.initialized) return;
    const t = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = filterType;
    filter.Q.value = q;
    filter.frequency.setValueAtTime(Math.max(40, freqStart), t);
    if (freqEnd !== freqStart) {
      filter.frequency.exponentialRampToValueAtTime(Math.max(40, freqEnd), t + dur);
    }
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + Math.min(0.015, dur * 0.2));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(filter).connect(g).connect(this.sfxGain);
    src.start(t, Math.random() * 2, dur + 0.03);
  }

  // --- MOVEMENT & CORE SFX ---
  playFootstep(surface = 'grass', isTitan = false) {
    if (!this.initialized) return;
    if (isTitan) {
      this._tone('sine', 95, 34, 0.22, 0.35);
      this._noise('lowpass', 300, 90, 0.18, 0.3);
      return;
    }
    if (surface === 'wood') {
      const pitch = 115 + Math.random() * 30;
      this._tone('triangle', pitch, pitch * 0.55, 0.08, 0.14);
      this._noise('bandpass', 650 + Math.random() * 200, 350, 0.06, 0.11, 2.2);
    } else {
      this._noise('bandpass', 1400 + Math.random() * 600, 700, 0.075, 0.12, 1.5);
      this._tone('sine', 80 + Math.random() * 18, 45, 0.055, 0.08);
    }
  }

  playJump(isTitan = false) {
    this._noise('bandpass', 500, 1400, 0.15, 0.14, 1.5);
    this._tone('sine', isTitan ? 90 : 190, isTitan ? 160 : 380, 0.14, 0.12);
  }

  playLand(intensity = 1, isTitan = false) {
    const v = Math.min(1, intensity);
    this._tone('sine', isTitan ? 90 : 130, 38, isTitan ? 0.28 : 0.13, 0.2 * v);
    this._noise('lowpass', 500, 120, 0.12, 0.16 * v);
  }

  playDash() {
    this._noise('bandpass', 1800, 420, 0.22, 0.28, 1.8);
    this._tone('sine', 340, 140, 0.16, 0.12);
  }

  playEquip() {
    this._tone('triangle', 420, 660, 0.12, 0.18, 0);
    this._tone('triangle', 660, 940, 0.16, 0.16, 0.07);
    this._noise('highpass', 2400, 4500, 0.14, 0.08, 1, 0.03);
  }

  playPortalWarp() {
    this._noise('bandpass', 250, 2600, 0.65, 0.35, 3.0);
    this._tone('sine', 120, 720, 0.55, 0.22);
    this._tone('triangle', 240, 1200, 0.45, 0.14, 0.1);
  }

  playSwing(pitch = 1) {
    this._noise('bandpass', 1400 * pitch, 380 * pitch, 0.14, 0.22, 2.0);
  }

  playHit(heavy = false) {
    this._tone('triangle', heavy ? 170 : 240, 48, heavy ? 0.2 : 0.12, heavy ? 0.38 : 0.26);
    this._noise('bandpass', heavy ? 900 : 1600, 280, 0.1, heavy ? 0.36 : 0.25, 1.2);
  }

  playPlayerHurt() {
    this._tone('sawtooth', 160, 62, 0.18, 0.28);
    this._noise('lowpass', 950, 220, 0.14, 0.28);
  }

  playKnockdown() {
    this._tone('sine', 135, 36, 0.28, 0.36);
    this._noise('lowpass', 720, 120, 0.24, 0.32);
  }

  playCounterBreak() {
    this._tone('triangle', 320, 880, 0.16, 0.3);
    this._tone('sawtooth', 190, 60, 0.24, 0.26, 0.02);
    this._noise('bandpass', 1800, 420, 0.22, 0.34, 1.5);
  }

  playGunshot(weaponId = 'rifle') {
    if (!this.initialized) return;
    if (weaponId === 'sniper') {
      this._noise('lowpass', 2400, 180, 0.35, 0.48);
      this._tone('sawtooth', 220, 40, 0.3, 0.34);
    } else if (weaponId === 'shotgun') {
      this._noise('lowpass', 1800, 160, 0.28, 0.46);
      this._tone('triangle', 160, 38, 0.22, 0.35);
    } else if (weaponId === 'smg') {
      this._noise('bandpass', 2200, 500, 0.08, 0.25, 1.2);
      this._tone('square', 380, 95, 0.06, 0.16);
    } else if (weaponId === 'pistol') {
      this._noise('bandpass', 2000, 420, 0.12, 0.3, 1.3);
      this._tone('triangle', 340, 80, 0.1, 0.2);
    } else {
      this._noise('bandpass', 1800, 360, 0.13, 0.34, 1.1);
      this._tone('sawtooth', 260, 65, 0.11, 0.22);
    }
  }

  playReload() {
    this._tone('square', 680, 520, 0.05, 0.12, 0);
    this._tone('square', 540, 860, 0.06, 0.14, 0.18);
  }

  playGliderOpen() {
    this._noise('bandpass', 480, 1600, 0.38, 0.3, 1.6);
    this._tone('sine', 160, 320, 0.22, 0.14);
  }

  playHookPull() {
    this._tone('sawtooth', 420, 180, 0.22, 0.24);
    this._noise('highpass', 2200, 900, 0.24, 0.26);
  }

  playKO() {
    this._tone('sine', 520, 95, 0.45, 0.24);
    this._noise('bandpass', 2200, 250, 0.42, 0.28, 2.2);
  }

  // --- ALL 12 POWERS BESPOKE SFX ---
  playPower(powerId, slot = 1) {
    if (!this.initialized) return;
    switch (powerId) {
      case 'thunder':
        if (slot === 1) {
          this._noise('highpass', 3200, 400, 0.45, 0.45);
          this._tone('sawtooth', 900, 90, 0.22, 0.22);
          this._tone('sine', 120, 36, 0.55, 0.38, 0.04);
        } else {
          this._noise('bandpass', 2400, 300, 0.65, 0.4, 2.5);
          this._tone('sawtooth', 620, 140, 0.4, 0.22);
          this._tone('sine', 110, 34, 0.7, 0.38, 0.08);
        }
        break;
      case 'pyro':
        if (slot === 1) {
          this._noise('bandpass', 900, 220, 0.38, 0.38, 1.3);
          this._tone('sawtooth', 260, 75, 0.28, 0.2);
        } else {
          this._noise('lowpass', 1500, 140, 0.85, 0.48);
          this._tone('sine', 160, 32, 0.75, 0.42);
        }
        break;
      case 'cryo':
        this._tone('triangle', 1400, 2400, 0.18, 0.18);
        this._tone('sine', 1900, 980, 0.24, 0.15, 0.05);
        this._noise('highpass', 2800, 1200, slot === 2 ? 0.6 : 0.3, 0.28);
        break;
      case 'gravity':
        this._tone('sine', slot === 1 ? 260 : 90, slot === 1 ? 45 : 320, 0.55, 0.34);
        this._noise('bandpass', 480, 140, 0.55, 0.26, 4.5);
        break;
      case 'wind':
        this._noise('bandpass', 400, 2200, slot === 2 ? 0.5 : 0.6, 0.38, 2.6);
        this._noise('bandpass', 1800, 500, 0.45, 0.24, 2.2, 0.12);
        break;
      case 'earth':
        this._tone('sine', 120, 30, 0.45, 0.45);
        this._noise('lowpass', 720, 110, slot === 2 ? 0.7 : 0.4, 0.44);
        break;
      case 'shadow':
        this._noise('bandpass', 1800, 260, 0.36, 0.3, 3.2);
        this._tone('sine', 340, 95, 0.32, 0.18);
        break;
      case 'light':
        this._tone('sine', 780, 1560, 0.32, 0.22);
        this._tone('triangle', 390, 780, 0.42, 0.18, 0.04);
        this._noise('highpass', 2200, 5200, 0.38, 0.22);
        break;
      case 'poison':
        this._noise('bandpass', 1200, 2800, 0.4, 0.28, 3.5);
        for (let i = 0; i < 4; i++) {
          this._tone('sine', 260 + Math.random() * 340, 520 + Math.random() * 240, 0.07, 0.12, i * 0.07);
        }
        break;
      case 'chrono':
        if (slot === 1) {
          this._tone('square', 920, 880, 0.04, 0.1, 0);
          this._tone('square', 720, 680, 0.04, 0.1, 0.12);
          this._tone('sine', 520, 180, 0.45, 0.24, 0.05);
        } else {
          // Reverse rewind sweep
          this._noise('bandpass', 300, 3200, 0.45, 0.32, 3.5);
          this._tone('triangle', 180, 1280, 0.42, 0.25);
        }
        break;
      case 'cyber':
        if (slot === 1) {
          this._tone('sawtooth', 1250, 260, 0.12, 0.2);
          this._tone('square', 840, 180, 0.1, 0.12, 0.02);
        } else {
          this._tone('sine', 160, 920, 0.55, 0.24);
          this._noise('lowpass', 1800, 160, 0.85, 0.48, 1.5, 0.5);
          this._tone('sawtooth', 180, 36, 0.75, 0.36, 0.5);
        }
        break;
      case 'titan':
        this._tone('sawtooth', 135, 42, 0.55, 0.34);
        this._tone('sine', 95, 32, 0.65, 0.42);
        this._noise('lowpass', 600, 110, 0.5, 0.38);
        break;
      case 'aqua':
        this._noise('bandpass', 420, 1800, 0.55, 0.36, 1.6);
        this._tone('sine', 180, 420, 0.35, 0.18);
        break;
      case 'nature':
        this._noise('bandpass', 1600, 680, 0.35, 0.26, 2.2);
        this._tone('triangle', 360, 720, 0.25, 0.16);
        break;
      case 'magma':
        this._tone('sine', 140, 32, 0.65, 0.44);
        this._noise('lowpass', 1100, 130, 0.65, 0.44);
        break;
      case 'blood':
        this._tone('sawtooth', 320, 90, 0.32, 0.22);
        this._noise('bandpass', 1400, 320, 0.35, 0.28, 3.0);
        break;
      case 'sonic':
        this._noise('highpass', 1800, 5200, 0.24, 0.34);
        this._tone('sawtooth', 1400, 240, 0.2, 0.22);
        break;
      case 'crystal':
        this._tone('triangle', 1650, 2900, 0.18, 0.2);
        this._tone('sine', 2200, 1100, 0.24, 0.16, 0.06);
        this._noise('highpass', 3200, 1600, 0.28, 0.22);
        break;
      case 'dragon':
        this._tone('sawtooth', 185, 58, 0.6, 0.32);
        this._noise('bandpass', 850, 200, 0.65, 0.42, 1.4);
        break;
      case 'void':
        this._tone('sine', 220, 40, 0.65, 0.36);
        this._tone('sawtooth', 110, 280, 0.45, 0.18, 0.08);
        this._noise('bandpass', 600, 120, 0.55, 0.3, 4.0);
        break;
      case 'star':
        this._tone('triangle', 920, 1840, 0.25, 0.2);
        this._tone('sine', 1380, 690, 0.35, 0.16, 0.06);
        this._noise('highpass', 2600, 4800, 0.28, 0.16);
        break;
      case 'prism':
        this._tone('sine', 640, 1480, 0.28, 0.2);
        this._tone('triangle', 980, 1960, 0.32, 0.16, 0.05);
        this._noise('bandpass', 2400, 4200, 0.34, 0.2, 2.0);
        break;
      case 'mecha':
        this._noise('lowpass', 1400, 220, 0.42, 0.38);
        this._tone('sawtooth', 260, 72, 0.34, 0.24);
        break;
      case 'phoenix':
        this._noise('bandpass', 720, 2400, 0.55, 0.36, 1.8);
        this._tone('triangle', 520, 1180, 0.42, 0.2);
        break;
      case 'abyss':
        this._tone('sine', 130, 34, 0.55, 0.42);
        this._noise('bandpass', 520, 160, 0.5, 0.34, 2.2);
        break;
      case 'sand':
        this._noise('bandpass', 1200, 480, 0.65, 0.36, 1.2);
        this._tone('triangle', 220, 95, 0.4, 0.2);
        break;
      case 'magnet':
        this._tone('sawtooth', slot === 1 ? 160 : 620, slot === 1 ? 680 : 120, 0.38, 0.24);
        this._noise('bandpass', 1400, 450, 0.32, 0.24, 3.0);
        break;
      case 'samurai':
        this._noise('highpass', 2800, 900, 0.18, 0.32);
        this._tone('triangle', 1200, 320, 0.14, 0.2);
        break;
    }
  }

  playExplosion(scale = 1) {
    this._tone('sine', 130, 28, 0.45 * scale, 0.42);
    this._noise('lowpass', 1200, 130, 0.5 * scale, 0.44);
  }
}
