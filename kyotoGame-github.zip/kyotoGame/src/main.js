import './style.css';
import { GameEngine } from './game/GameEngine.js';

const container = document.getElementById('game-container');
window.__kyotoGame = new GameEngine(container);
