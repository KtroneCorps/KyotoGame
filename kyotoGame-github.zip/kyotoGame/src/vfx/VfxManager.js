import * as THREE from 'three';

const sharedBoxGeo = new THREE.BoxGeometry(1, 1, 1);
const sharedOctaGeo = new THREE.OctahedronGeometry(0.65, 0);
const sharedRingGeo = new THREE.RingGeometry(0.75, 1.0, 20);
const sharedSphereGeo = new THREE.IcosahedronGeometry(1, 1);

export class VfxManager {
  constructor(scene) {
    this.scene = scene;
    this.particles = [];
    this.effects = [];
    this.shakeAmount = 0;
    this.floatingContainer = document.getElementById('floating-numbers');
  }

  addShake(amount) {
    this.shakeAmount = Math.min(1.1, Math.max(this.shakeAmount, amount));
  }

  getShakeOffset(dt) {
    if (this.shakeAmount <= 0.001) return { x: 0, y: 0 };
    const s = this.shakeAmount;
    this.shakeAmount = Math.max(0, this.shakeAmount - dt * 2.8);
    return {
      x: (Math.random() - 0.5) * s * 0.45,
      y: (Math.random() - 0.5) * s * 0.45,
    };
  }

  spawnBurst(pos, colorHex, count = 12, speed = 8, size = 0.22, gravity = 16, life = 0.55) {
    const mat = new THREE.MeshBasicMaterial({ color: colorHex });
    for (let i = 0; i < count; i++) {
      const mesh = new THREE.Mesh(i % 2 === 0 ? sharedBoxGeo : sharedOctaGeo, mat);
      mesh.position.copy(pos);
      const s = size * (0.65 + Math.random() * 0.7);
      mesh.scale.setScalar(s);

      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI * 0.75;
      const spd = speed * (0.45 + Math.random() * 0.85);
      const vel = new THREE.Vector3(
        Math.sin(phi) * Math.cos(theta) * spd,
        Math.cos(phi) * spd + speed * 0.35,
        Math.sin(phi) * Math.sin(theta) * spd
      );

      this.scene.add(mesh);
      this.particles.push({
        mesh,
        vel,
        gravity,
        age: 0,
        life: life * (0.7 + Math.random() * 0.5),
        baseScale: s,
        rotSpeed: (Math.random() - 0.5) * 10,
      });
    }
  }

  spawnRing(pos, colorHex, maxRadius = 6, duration = 0.42, yOffset = 0.12) {
    const mat = new THREE.MeshBasicMaterial({
      color: colorHex,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.9,
    });
    const mesh = new THREE.Mesh(sharedRingGeo, mat);
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.set(pos.x, pos.y + yOffset, pos.z);
    mesh.scale.setScalar(0.3);
    this.scene.add(mesh);

    this.effects.push({
      mesh,
      age: 0,
      life: duration,
      update: (e, p) => {
        const s = 0.3 + (maxRadius - 0.3) * (1 - (1 - p) ** 2);
        e.mesh.scale.setScalar(s);
        e.mesh.material.opacity = (1 - p) * 0.9;
      },
    });
  }

  spawnSphereFlash(pos, colorHex, maxRadius = 4, duration = 0.35, opacity = 0.55) {
    const mat = new THREE.MeshBasicMaterial({
      color: colorHex,
      transparent: true,
      opacity,
      wireframe: false,
    });
    const mesh = new THREE.Mesh(sharedSphereGeo, mat);
    mesh.position.copy(pos);
    mesh.scale.setScalar(0.2);
    this.scene.add(mesh);

    this.effects.push({
      mesh,
      age: 0,
      life: duration,
      update: (e, p) => {
        const s = 0.2 + (maxRadius - 0.2) * (1 - (1 - p) ** 3);
        e.mesh.scale.setScalar(s);
        e.mesh.material.opacity = (1 - p) * opacity;
      },
    });
  }

  spawnLightningBolt(startPos, endPos, colorHex = 0x5ceeff, duration = 0.32, segments = 8) {
    const group = new THREE.Group();
    const matCore = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 1 });
    const matGlow = new THREE.MeshBasicMaterial({ color: colorHex, transparent: true, opacity: 0.7 });

    const points = [startPos.clone()];
    for (let i = 1; i < segments; i++) {
      const t = i / segments;
      const pt = new THREE.Vector3().lerpVectors(startPos, endPos, t);
      pt.x += (Math.random() - 0.5) * 2.1;
      pt.z += (Math.random() - 0.5) * 2.1;
      points.push(pt);
    }
    points.push(endPos.clone());

    const up = new THREE.Vector3(0, 1, 0);
    for (let i = 0; i < points.length - 1; i++) {
      const a = points[i];
      const b = points[i + 1];
      const dir = new THREE.Vector3().subVectors(b, a);
      const len = dir.length();
      const mid = new THREE.Vector3().addVectors(a, b).multiplyScalar(0.5);

      const segGeo = new THREE.CylinderGeometry(0.14, 0.14, len, 5);
      const seg = new THREE.Mesh(segGeo, matCore);
      seg.position.copy(mid);
      seg.quaternion.setFromUnitVectors(up, dir.clone().normalize());
      group.add(seg);

      const glowGeo = new THREE.CylinderGeometry(0.32, 0.32, len, 5);
      const glow = new THREE.Mesh(glowGeo, matGlow);
      glow.position.copy(mid);
      glow.quaternion.copy(seg.quaternion);
      group.add(glow);
    }

    this.scene.add(group);
    this.effects.push({
      mesh: group,
      age: 0,
      life: duration,
      update: (e, p) => {
        const op = 1 - p;
        matCore.opacity = op;
        matGlow.opacity = op * 0.7;
      },
    });
  }

  spawnBeam(startPos, endPos, colorHex = 0xffe066, radius = 0.45, duration = 0.45) {
    const group = new THREE.Group();
    const dir = new THREE.Vector3().subVectors(endPos, startPos);
    const len = Math.max(0.5, dir.length());
    const mid = new THREE.Vector3().addVectors(startPos, endPos).multiplyScalar(0.5);

    const coreMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.95 });
    const outerMat = new THREE.MeshBasicMaterial({ color: colorHex, transparent: true, opacity: 0.55 });

    const core = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.45, radius * 0.45, len, 8), coreMat);
    const outer = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, len, 8), outerMat);
    group.add(core, outer);
    group.position.copy(mid);
    group.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
    this.scene.add(group);

    this.effects.push({
      mesh: group,
      age: 0,
      life: duration,
      update: (e, p) => {
        const s = 1 - p * 0.6;
        core.scale.set(s, 1, s);
        outer.scale.set(1 + p * 0.5, 1, 1 + p * 0.5);
        coreMat.opacity = (1 - p) * 0.95;
        outerMat.opacity = (1 - p) * 0.55;
      },
    });
  }

  spawnSlashArc(origin, forwardDir, colorHex, scale = 1.4) {
    const mat = new THREE.MeshBasicMaterial({
      color: colorHex,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.85,
    });
    const geo = new THREE.RingGeometry(0.65 * scale, 1.18 * scale, 12, 1, -Math.PI * 0.45, Math.PI * 0.9);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(origin);
    mesh.lookAt(origin.clone().add(forwardDir));
    mesh.rotateX(Math.PI / 2);
    this.scene.add(mesh);

    this.effects.push({
      mesh,
      age: 0,
      life: 0.18,
      update: (e, p) => {
        e.mesh.scale.setScalar(1 + p * 0.45);
        e.mesh.material.opacity = (1 - p) * 0.85;
      },
    });
  }

  /**
   * 3D Linked Energy Chain stretching from startPos to endPos (for Abyss Anchor Hook, Vine Pull, Magnet Tether)
   */
  spawnChain(startPos, endPos, colorHex = 0x00f5c8, duration = 0.45) {
    const group = new THREE.Group();
    const mat = new THREE.MeshBasicMaterial({ color: colorHex, transparent: true, opacity: 0.95 });
    const dir = new THREE.Vector3().subVectors(endPos, startPos);
    const dist = Math.max(0.5, dir.length());
    const linkCount = Math.min(28, Math.max(5, Math.floor(dist / 0.85)));
    const up = new THREE.Vector3(0, 1, 0);
    const norm = dir.clone().normalize();
    const quat = new THREE.Quaternion().setFromUnitVectors(up, norm);

    for (let i = 0; i <= linkCount; i++) {
      const t = i / linkCount;
      const link = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.055, 4, 8), mat);
      link.position.lerpVectors(startPos, endPos, t);
      link.quaternion.copy(quat);
      if (i % 2 === 1) link.rotateY(Math.PI / 2);
      group.add(link);
    }

    this.scene.add(group);
    this.effects.push({
      mesh: group,
      age: 0,
      life: duration,
      update: (e, p) => {
        mat.opacity = (1 - p) * 0.95;
      },
    });
  }

  /**
   * Crisp glowing bullet tracer line for Battle Royale 3D firearms
   */
  spawnTracer(startPos, endPos, colorHex = 0xffe066, duration = 0.11) {
    const dir = new THREE.Vector3().subVectors(endPos, startPos);
    const len = Math.max(0.5, dir.length());
    const mid = new THREE.Vector3().addVectors(startPos, endPos).multiplyScalar(0.5);
    const mat = new THREE.MeshBasicMaterial({ color: colorHex, transparent: true, opacity: 0.92 });
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, len, 4), mat);
    mesh.position.copy(mid);
    mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
    this.scene.add(mesh);

    this.effects.push({
      mesh,
      age: 0,
      life: duration,
      update: (e, p) => {
        mat.opacity = (1 - p) * 0.92;
      },
    });
  }

  spawnMuzzleFlash(pos, colorHex = 0xffe066) {
    const mat = new THREE.MeshBasicMaterial({ color: colorHex, transparent: true, opacity: 0.95 });
    const flash = new THREE.Mesh(sharedOctaGeo, mat);
    flash.position.copy(pos);
    flash.scale.setScalar(0.32);
    this.scene.add(flash);
    this.effects.push({
      mesh: flash,
      age: 0,
      life: 0.07,
      update: (e, p) => {
        e.mesh.scale.setScalar(0.32 * (1 - p * 0.5));
        mat.opacity = 1 - p;
      },
    });
  }

  spawnTemporaryMesh(mesh, duration, customUpdate = null) {
    this.scene.add(mesh);
    this.effects.push({
      mesh,
      age: 0,
      life: duration,
      update: customUpdate || ((e, p) => {
        if (p > 0.75) {
          const fade = 1 - (p - 0.75) / 0.25;
          e.mesh.scale.setScalar(Math.max(0.01, fade));
        }
      }),
    });
  }

  spawnFloatingText(worldPos, text, color = '#ffe066', camera) {
    if (!this.floatingContainer || !camera) return;
    const proj = worldPos.clone().project(camera);
    if (proj.z > 1) return; // behind camera

    const x = (proj.x * 0.5 + 0.5) * window.innerWidth;
    const y = (-proj.y * 0.5 + 0.5) * window.innerHeight;

    const el = document.createElement('div');
    el.className = 'dmg-num';
    el.textContent = text;
    el.style.left = `${x + (Math.random() - 0.5) * 24}px`;
    el.style.top = `${y}px`;
    el.style.color = color;
    this.floatingContainer.appendChild(el);
    setTimeout(() => el.remove(), 860);
  }

  update(dt) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.age += dt;
      if (p.age >= p.life) {
        this.scene.remove(p.mesh);
        this.particles.splice(i, 1);
        continue;
      }
      p.vel.y -= p.gravity * dt;
      p.mesh.position.addScaledVector(p.vel, dt);
      p.mesh.rotation.x += p.rotSpeed * dt;
      p.mesh.rotation.y += p.rotSpeed * dt;
      const ratio = 1 - p.age / p.life;
      p.mesh.scale.setScalar(Math.max(0.01, p.baseScale * ratio));
    }

    for (let i = this.effects.length - 1; i >= 0; i--) {
      const e = this.effects[i];
      e.age += dt;
      if (e.age >= e.life) {
        this.scene.remove(e.mesh);
        this.effects.splice(i, 1);
        continue;
      }
      e.update(e, e.age / e.life);
    }
  }

  clear() {
    for (const p of this.particles) this.scene.remove(p.mesh);
    for (const e of this.effects) this.scene.remove(e.mesh);
    this.particles = [];
    this.effects = [];
    this.shakeAmount = 0;
  }
}
