import * as THREE from 'three';
import { getArenaTerrainHeight } from '../world/ArenaWorld.js';

function flatMat(color, opts = {}) {
  return new THREE.MeshStandardMaterial({
    color,
    flatShading: true,
    emissive: opts.emissive ?? 0x000000,
    emissiveIntensity: opts.emissiveIntensity ?? 0,
    transparent: opts.transparent ?? false,
    opacity: opts.opacity ?? 1,
    roughness: opts.roughness ?? 0.45,
    side: opts.side ?? THREE.FrontSide,
  });
}

/**
 * Executes primary attacks and abilities (E, A/F, R) for all 28 powers.
 * Uses swept segment checks for projectiles and cylinder checks for melee/AoE.
 */
export class PowerExecutor {
  constructor(scene, vfx, sound, getGroundHeight = getArenaTerrainHeight) {
    this.scene = scene;
    this.vfx = vfx;
    this.sound = sound;
    this.getGroundHeight = getGroundHeight;
    this.projectiles = [];
    this.zones = [];
    this.delayedActions = [];
  }

  clear() {
    for (const p of this.projectiles) this.scene.remove(p.mesh);
    for (const z of this.zones) this.scene.remove(z.mesh);
    this.projectiles = [];
    this.zones = [];
    this.delayedActions = [];
  }

  castPrimary(caster, fighters, ctx) {
    if (caster.isDead || caster.knockdownTimer > 0 || caster.lmbCd > 0 || caster.freezeTimer > 0) return false;

    // Empty-handed punch in Battle Royale before finding a weapon or power
    if (!caster.hasPower) {
      caster.lmbCd = 0.38;
      caster.triggerAttackAnim();
      if (caster.isPlayer) this.sound.playSwing(1.15);
      const forward = caster.getForwardDirection(false);
      const origin = caster.position.clone().add(new THREE.Vector3(0, 1.3 * caster.currentScale, 0));
      this.vfx.spawnSlashArc(origin.clone().addScaledVector(forward, 1.2), forward, 0xffffff, 0.9);
      let hitAny = false;
      for (const target of fighters) {
        if (target === caster || target.isDead) continue;
        const dx = target.position.x - caster.position.x;
        const dz = target.position.z - caster.position.z;
        const dy = target.position.y - caster.position.y;
        const horizDist = Math.hypot(dx, dz);
        if (horizDist > 3.2 + target.currentScale * 0.7 || Math.abs(dy) > 3.0) continue;
        const flatDir = horizDist > 0.01 ? new THREE.Vector3(dx / horizDist, 0, dz / horizDist) : forward.clone();
        if (flatDir.dot(forward) < 0.15 && horizDist > 1.8) continue;
        hitAny = true;
        const kb = flatDir.multiplyScalar(11);
        kb.y = 5.5;
        target.takeDamage(10, kb, caster, ctx);
        this.vfx.spawnBurst(target.position.clone().add(new THREE.Vector3(0, 1.4, 0)), 0xffffff, 7, 6, 0.18);
      }
      if (hitAny && caster.isPlayer) this.sound.playHit(false);
      return true;
    }

    const p = caster.power;
    caster.lmbCd = p.lmb.cooldown;
    caster.triggerAttackAnim();
    if (caster.isPlayer) this.sound.playSwing(p.id === 'titan' ? 0.7 : 1.05);

    const forward = caster.getForwardDirection(false);
    const range = p.lmb.range * (caster.titanTimer > 0 ? 1.45 : 1);
    const origin = caster.position.clone().add(new THREE.Vector3(0, 1.3 * caster.currentScale, 0));

    this.vfx.spawnSlashArc(origin.clone().addScaledVector(forward, 1.45 * caster.currentScale), forward, p.hex, 1.25 * caster.currentScale);

    let hitAny = false;
    for (const target of fighters) {
      if (target === caster || target.isDead) continue;
      const dx = target.position.x - caster.position.x;
      const dz = target.position.z - caster.position.z;
      const dy = target.position.y - caster.position.y;
      const horizDist = Math.hypot(dx, dz);

      // Accurate cylinder check: works reliably on hills & during jumps
      if (horizDist > range + target.currentScale * 0.85) continue;
      if (Math.abs(dy) > 3.2 + caster.currentScale) continue;

      const flatDir = horizDist > 0.01 ? new THREE.Vector3(dx / horizDist, 0, dz / horizDist) : forward.clone();
      if (flatDir.dot(forward) < 0.12 && horizDist > 2.0) continue;

      hitAny = true;
      const kbStrength = p.lmb.knockback * (caster.titanTimer > 0 ? 1.45 : 1);
      const kb = flatDir.multiplyScalar(kbStrength);
      kb.y = (p.lmb.lift || 6.5) * (caster.titanTimer > 0 ? 1.2 : 1);

      const status = {};
      if (p.lmb.burn) status.burn = p.lmb.burn;
      if (p.lmb.slow) status.slow = p.lmb.slow;
      if (p.lmb.poison) status.poison = p.lmb.poison;

      target.takeDamage(p.lmb.dmg * (caster.titanTimer > 0 ? 1.3 : 1), kb, caster, { ...ctx, status });

      if (!ctx.visualOnly && !target.isRemotePlayer) {
        if (p.lmb.burn) target.burnTimer = Math.max(target.burnTimer, p.lmb.burn);
        if (p.lmb.slow) target.slowTimer = Math.max(target.slowTimer, p.lmb.slow);
        if (p.lmb.poison) target.poisonTimer = Math.max(target.poisonTimer, p.lmb.poison);
      }
      if (!ctx.visualOnly && p.lmb.lifesteal) caster.heal(p.lmb.lifesteal);
      if (!ctx.visualOnly && p.lmb.echo) {
        this.delayedActions.push({
          timer: 0.42,
          fn: () => {
            if (target.hp > 0) {
              target.takeDamage(7, new THREE.Vector3(0, 4, 0), caster, ctx);
              this.vfx.spawnRing(target.position, 0x34e8d6, 2.2, 0.3, 1.1);
            }
          },
        });
      }

      this.vfx.spawnBurst(target.position.clone().add(new THREE.Vector3(0, 1.4, 0)), p.hex, 10, 8, 0.22);
    }

    if (hitAny && caster.isPlayer) {
      this.sound.playHit(p.id === 'earth' || p.id === 'titan' || caster.titanTimer > 0);
      this.vfx.addShake(caster.titanTimer > 0 ? 0.45 : 0.2);
    }
    return true;
  }

  _getAimTargetPoint(caster, maxDist = 32) {
    const eye = caster.getEyePosition();
    const dir = caster.getForwardDirection(true);
    for (let d = 4; d <= maxDist; d += 1.2) {
      const pt = eye.clone().addScaledVector(dir, d);
      const gh = this.getGroundHeight(pt.x, pt.z);
      if (pt.y <= gh + 0.6) {
        return new THREE.Vector3(pt.x, Math.max(0, gh), pt.z);
      }
    }
    const end = eye.clone().addScaledVector(dir, maxDist);
    return new THREE.Vector3(end.x, Math.max(0, this.getGroundHeight(end.x, end.z)), end.z);
  }

  /**
   * Mode Combo: Counter-Punch Combo Breaker (unlocked after 1.1s on ground during 1.6s knockdown)
   */
  castCounterPunch(caster, fighters, ctx) {
    caster.knockdownTimer = 0;
    caster.knockdownElapsed = 0;
    caster.counterAnim = 0.35;
    caster.triggerAttackAnim();
    if (!ctx.visualOnly) {
      caster.invulnTimer = Math.max(caster.invulnTimer, 0.65);
      caster.velocity.y = Math.max(caster.velocity.y, 7.5);
    }

    this.sound.playCounterBreak();
    this.vfx.spawnRing(caster.position, 0xffd43b, 7.2, 0.4);
    this.vfx.spawnRing(caster.position, 0xff5a36, 5.2, 0.32);
    this.vfx.spawnSphereFlash(caster.position.clone().add(new THREE.Vector3(0, 1.2, 0)), 0xffd43b, 4.8, 0.3, 0.45);
    this.vfx.spawnBurst(caster.position.clone().add(new THREE.Vector3(0, 1.2, 0)), 0xffd43b, 22, 14, 0.25);
    if (caster.isPlayer) this.vfx.addShake(0.45);

    let brokeAny = false;
    if (!ctx.visualOnly) {
      for (const target of fighters) {
        if (target === caster || target.isDead) continue;
        const dx = target.position.x - caster.position.x;
        const dz = target.position.z - caster.position.z;
        const dist = Math.hypot(dx, dz);
        if (dist <= 6.2 && Math.abs(target.position.y - caster.position.y) <= 4.0) {
          brokeAny = true;
          target.comboCount = 0;
          const push = dist > 0.01 ? new THREE.Vector3(dx / dist, 0, dz / dist) : caster.getForwardDirection(false);
          push.multiplyScalar(26);
          push.y = 11;
          target.takeDamage(12, push, caster, { ...ctx, comboMode: false });
          this.vfx.spawnBurst(target.position.clone().add(new THREE.Vector3(0, 1.4, 0)), 0xff5a36, 14, 11, 0.24);
        }
      }
    }
    return brokeAny;
  }

  /**
   * Ability 1 (E / Right Click)
   */
  castAbility1(caster, fighters, ctx) {
    if (!caster.hasPower || caster.isDead || caster.knockdownTimer > 0 || caster.ab1Cd > 0 || caster.freezeTimer > 0) return false;
    const p = caster.power;
    caster.ab1Cd = p.ab1.cooldown;
    caster.triggerAttackAnim();
    if (caster.isPlayer || caster.position.distanceTo(ctx.playerPos) < 42) {
      this.sound.playPower(p.id, 1);
    }

    const forward = caster.getForwardDirection(true);
    const flatFwd = caster.getForwardDirection(false);
    const eye = caster.getEyePosition();

    switch (p.id) {
      case 'thunder': {
        const targetPos = this._getAimTargetPoint(caster, 32);
        const skyPos = targetPos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 3, 28, (Math.random() - 0.5) * 3));
        this.vfx.spawnLightningBolt(skyPos, targetPos, 0x38d9ff, 0.4, 10);
        this.vfx.spawnRing(targetPos, 0x38d9ff, 7.5, 0.45);
        this.vfx.spawnRing(targetPos, 0xffe066, 5.2, 0.35);
        this.vfx.spawnBurst(targetPos.clone().add(new THREE.Vector3(0, 0.8, 0)), 0x38d9ff, 18, 12, 0.25);
        if (caster.isPlayer) this.vfx.addShake(0.55);
        this._aoeDamage(targetPos, 7.0, 24, 19, 13, caster, fighters, ctx, (t) => { t.slowTimer = Math.max(t.slowTimer, 1.5); });
        break;
      }

      case 'pyro': {
        const mesh = new THREE.Group();
        mesh.add(new THREE.Mesh(new THREE.IcosahedronGeometry(0.72, 0), flatMat(0xff551a, { emissive: 0xff3b00, emissiveIntensity: 1.5 })));
        mesh.add(new THREE.Mesh(new THREE.OctahedronGeometry(0.95, 0), flatMat(0xffd43b, { transparent: true, opacity: 0.45, emissive: 0xffaa00, emissiveIntensity: 1.1 })));
        mesh.position.copy(eye).addScaledVector(forward, 1.4);
        this.scene.add(mesh);
        this._spawnProj({
          caster, mesh, vel: forward.clone().multiplyScalar(32), gravity: 4.5, radius: 1.25, life: 3.0, trailColor: 0xff6b2b,
          onHit: (pos) => {
            this.sound.playExplosion(0.95);
            this.vfx.spawnSphereFlash(pos, 0xff551a, 5.8, 0.38);
            this.vfx.spawnRing(pos, 0xffd43b, 7.0, 0.4);
            this.vfx.spawnBurst(pos, 0xff6b2b, 20, 12, 0.28);
            if (caster.isPlayer) this.vfx.addShake(0.45);
            this._aoeDamage(pos, 6.5, 22, 20, 11, caster, fighters, ctx, (t) => { t.burnTimer = Math.max(t.burnTimer, 3.5); });
          },
        });
        break;
      }

      case 'cryo': {
        const iceMat = flatMat(0x74e8ff, { emissive: 0x38d9ff, emissiveIntensity: 0.7, roughness: 0.15 });
        for (let i = 1; i <= 7; i++) {
          this.delayedActions.push({
            timer: i * 0.06,
            fn: () => {
              const pt = caster.position.clone().addScaledVector(flatFwd, i * 2.9);
              pt.y = this.getGroundHeight(pt.x, pt.z);
              if (pt.y < -10) return;
              const spike = new THREE.Mesh(new THREE.ConeGeometry(0.9, 3.6 + i * 0.25, 5), iceMat);
              spike.position.set(pt.x, pt.y + 1.5, pt.z);
              spike.castShadow = true;
              this.vfx.spawnTemporaryMesh(spike, 1.35);
              this.vfx.spawnBurst(pt.clone().add(new THREE.Vector3(0, 1, 0)), 0xbdf5ff, 6, 6, 0.18);
              this._aoeDamage(pt, 3.2, 17, 9, 9, caster, fighters, ctx, (t) => { t.freezeTimer = Math.max(t.freezeTimer, 2.2); });
            },
          });
        }
        break;
      }

      case 'gravity': {
        const targetPos = caster.position.clone().addScaledVector(flatFwd, 13);
        targetPos.y = Math.max(1.5, this.getGroundHeight(targetPos.x, targetPos.z) + 2.2);
        const group = new THREE.Group();
        const core = new THREE.Mesh(new THREE.IcosahedronGeometry(1.15, 0), flatMat(0x130521, { emissive: 0x5c18a8, emissiveIntensity: 1.0 }));
        const ring = new THREE.Mesh(new THREE.TorusGeometry(2.3, 0.15, 5, 16), flatMat(0xb15cff, { emissive: 0xb15cff, emissiveIntensity: 1.3 }));
        ring.rotation.x = Math.PI / 2;
        group.add(core, ring);
        group.position.copy(targetPos);
        this.scene.add(group);
        this.zones.push({
          caster, mesh: group, pos: targetPos, radius: 12.0, life: 2.6, age: 0,
          update: (z, dt) => {
            z.mesh.rotation.y += dt * 4.5;
            ring.rotation.z += dt * 6;
            if (ctx.visualOnly) return;
            for (const f of fighters) {
              if (f === caster) continue;
              const diff = z.pos.clone().sub(f.position);
              const d = diff.length();
              if (d < z.radius && d > 0.6) f.velocity.addScaledVector(diff.normalize(), 32 * dt);
            }
          },
          onEnd: (z) => {
            this.sound.playExplosion(0.85);
            this.vfx.spawnSphereFlash(z.pos, 0xb15cff, 9.0, 0.4);
            this.vfx.spawnBurst(z.pos, 0xff87eb, 22, 14, 0.25);
            this._aoeDamage(z.pos, 9.5, 20, 24, 14, caster, fighters, ctx);
          },
        });
        break;
      }

      case 'wind': {
        const group = new THREE.Group();
        const windMat = flatMat(0xc7fff0, { transparent: true, opacity: 0.72, emissive: 0x63f5b8, emissiveIntensity: 0.55 });
        for (let i = 0; i < 6; i++) {
          const ring = new THREE.Mesh(new THREE.TorusGeometry(0.75 + i * 0.5, 0.18, 4, 10), windMat);
          ring.rotation.x = Math.PI / 2;
          ring.position.y = 0.6 + i * 1.15;
          group.add(ring);
        }
        const startPos = caster.position.clone().addScaledVector(flatFwd, 3.0);
        group.position.copy(startPos);
        this.scene.add(group);
        this.zones.push({
          caster, mesh: group, pos: startPos, vel: flatFwd.clone().multiplyScalar(15), radius: 4.8, life: 3.4, age: 0, hitCooldowns: new Map(),
          update: (z, dt) => {
            z.pos.addScaledVector(z.vel, dt);
            z.pos.y = Math.max(0, this.getGroundHeight(z.pos.x, z.pos.z));
            z.mesh.position.copy(z.pos);
            z.mesh.rotation.y += dt * 9;
            if (ctx.visualOnly) return;
            for (const f of fighters) {
              if (f === caster) continue;
              if (Math.hypot(f.position.x - z.pos.x, f.position.z - z.pos.z) < z.radius) {
                f.velocity.y = Math.max(f.velocity.y, 16);
                f.onGround = false;
                const last = z.hitCooldowns.get(f.id) || 0;
                if (z.age - last > 0.55) {
                  z.hitCooldowns.set(f.id, z.age);
                  f.takeDamage(10, new THREE.Vector3((Math.random() - 0.5) * 14, 13, (Math.random() - 0.5) * 14), caster, ctx);
                }
              }
            }
          },
        });
        break;
      }

      case 'earth': {
        const mesh = new THREE.Mesh(new THREE.DodecahedronGeometry(1.5, 0), flatMat(0x73685c, { roughness: 0.95 }));
        mesh.castShadow = true;
        mesh.position.copy(eye).addScaledVector(flatFwd, 2.2);
        this.scene.add(mesh);
        const vel = flatFwd.clone().multiplyScalar(25);
        vel.y = 7;
        this._spawnProj({
          caster, mesh, vel, gravity: 24, radius: 1.85, life: 3.2, bounces: 2, trailColor: 0xd99a4e,
          onHit: (pos) => {
            this.sound.playPower('earth', 1);
            this.vfx.spawnRing(pos, 0xd99a4e, 6.5, 0.4);
            this.vfx.spawnBurst(pos, 0x73685c, 18, 11, 0.34);
            if (caster.isPlayer) this.vfx.addShake(0.5);
            this._aoeDamage(pos, 6.2, 25, 24, 12, caster, fighters, ctx);
          },
        });
        break;
      }

      case 'shadow': {
        this.vfx.spawnBurst(caster.position.clone().add(new THREE.Vector3(0, 1.2, 0)), 0x2b1947, 16, 8, 0.26, 2);
        const dest = caster.position.clone().addScaledVector(flatFwd, 16);
        const gh = this.getGroundHeight(dest.x, dest.z);
        if (!ctx.visualOnly && gh > -10) caster.position.set(dest.x, Math.max(gh + 0.2, caster.position.y), dest.z);
        if (!ctx.visualOnly) caster.invulnTimer = Math.max(caster.invulnTimer, 0.55);
        this.vfx.spawnBurst(dest.clone().add(new THREE.Vector3(0, 1.2, 0)), 0x7c4dff, 18, 10, 0.25, 2);
        this.vfx.spawnRing(dest, 0x7c4dff, 5.0, 0.35);
        this._aoeDamage(dest, 5.2, 17, 15, 9, caster, fighters, ctx);
        break;
      }

      case 'light': {
        const start = eye.clone().addScaledVector(forward, 1.0);
        const end = start.clone().addScaledVector(forward, 42);
        this.vfx.spawnBeam(start, end, 0xffd94a, 0.7, 0.45);
        this.vfx.spawnBurst(end, 0xffd94a, 14, 9, 0.24);
        if (caster.isPlayer) this.vfx.addShake(0.35);
        if (!ctx.visualOnly) {
          const line = new THREE.Line3(start, end);
          const closest = new THREE.Vector3();
          for (const f of fighters) {
            if (f === caster) continue;
            const center = f.position.clone().add(new THREE.Vector3(0, 1.3 * f.currentScale, 0));
            line.closestPointToPoint(center, true, closest);
            if (closest.distanceTo(center) < 2.5 * f.currentScale) {
              const kb = flatFwd.clone().multiplyScalar(20);
              kb.y = 9;
              f.takeDamage(24, kb, caster, ctx);
              this.vfx.spawnBurst(center, 0xfff5a8, 14, 10, 0.22);
            }
          }
        }
        break;
      }

      case 'poison': {
        const flask = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.7, 0.6), flatMat(0x5df249, { emissive: 0x39e622, emissiveIntensity: 1.3 }));
        flask.position.copy(eye).addScaledVector(forward, 1.2);
        this.scene.add(flask);
        const vel = forward.clone().multiplyScalar(23);
        vel.y += 6;
        this._spawnProj({
          caster, mesh: flask, vel, gravity: 20, radius: 1.0, life: 2.6, trailColor: 0x5df249,
          onHit: (pos) => {
            this.sound.playPower('poison', 1);
            this.vfx.spawnBurst(pos, 0x5df249, 16, 8, 0.22);
            const gy = Math.max(0, this.getGroundHeight(pos.x, pos.z));
            const puddle = new THREE.Mesh(
              new THREE.CylinderGeometry(5.6, 5.8, 0.16, 14),
              flatMat(0x5df249, { emissive: 0x35cc20, emissiveIntensity: 0.9, transparent: true, opacity: 0.72 })
            );
            puddle.position.set(pos.x, gy + 0.1, pos.z);
            this.scene.add(puddle);
            this.zones.push({
              caster, mesh: puddle, pos: new THREE.Vector3(pos.x, gy, pos.z), radius: 5.8, life: 5.0, age: 0, tick: 0,
              update: (z, dt) => {
                z.tick -= dt;
                if (z.tick <= 0) {
                  z.tick = 0.55;
                  this.vfx.spawnBurst(z.pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 6, 0.3, (Math.random() - 0.5) * 6)), 0x8dff6b, 2, 3, 0.16, -2, 0.45);
                  if (ctx.visualOnly) return;
                  for (const f of fighters) {
                    if (f === caster) continue;
                    if (Math.hypot(f.position.x - z.pos.x, f.position.z - z.pos.z) < z.radius && Math.abs(f.position.y - z.pos.y) < 3.5) {
                      f.takeDamage(8, null, caster, { ...ctx, status: { poison: 3, slow: 1 } });
                      if (!f.isRemotePlayer) { f.poisonTimer = Math.max(f.poisonTimer, 3.0); f.slowTimer = Math.max(f.slowTimer, 1.0); }
                    }
                  }
                }
              },
            });
          },
        });
        break;
      }

      case 'chrono': {
        const center = caster.position.clone();
        const dome = new THREE.Mesh(
          new THREE.IcosahedronGeometry(9.5, 1),
          flatMat(0x34e8d6, { emissive: 0x34e8d6, emissiveIntensity: 0.55, transparent: true, opacity: 0.25, side: THREE.DoubleSide })
        );
        dome.position.copy(center).add(new THREE.Vector3(0, 1.2, 0));
        this.scene.add(dome);
        this.vfx.spawnRing(center, 0xffd166, 9.6, 0.5);
        this.zones.push({
          caster, mesh: dome, pos: center, radius: 9.6, life: 5.2, age: 0,
          update: (z, dt) => {
            z.mesh.rotation.y += dt * 0.8;
            if (ctx.visualOnly) return;
            for (const f of fighters) {
              if (f !== caster && f.position.distanceTo(z.pos) < z.radius) f.chronoSlowTimer = 0.35;
            }
          },
        });
        break;
      }

      case 'cyber': {
        for (let i = 0; i < 4; i++) {
          this.delayedActions.push({
            timer: i * 0.085,
            fn: () => {
              if (caster.isPlayer) this.sound.playPower('cyber', 1);
              const dir = caster.getForwardDirection(true);
              const col = i % 2 === 0 ? 0xff3b9a : 0x29f0ff;
              const bolt = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.28, 1.3), flatMat(col, { emissive: col, emissiveIntensity: 1.6 }));
              const start = caster.getEyePosition().addScaledVector(dir, 1.3);
              bolt.position.copy(start);
              bolt.lookAt(start.clone().add(dir));
              this.scene.add(bolt);
              this._spawnProj({
                caster, mesh: bolt, vel: dir.clone().multiplyScalar(48), gravity: 0, radius: 1.0, life: 1.6, trailColor: col,
                onHit: (pos) => {
                  this.vfx.spawnBurst(pos, col, 8, 9, 0.18);
                  this._aoeDamage(pos, 3.2, 10, 11, 5, caster, fighters, ctx);
                },
              });
            },
          });
        }
        break;
      }

      case 'titan': {
        if (!ctx.visualOnly) {
          caster.chargeTimer = 0.65;
          caster.chargeDir.copy(flatFwd);
          caster.chargeHitIds.clear();
          caster.invulnTimer = Math.max(caster.invulnTimer, 0.5);
        }
        this.vfx.spawnRing(caster.position, 0xffaa2b, 5.0, 0.35);
        if (caster.isPlayer) this.vfx.addShake(0.35);
        break;
      }

      // Extended power set
      case 'aqua': {
        // Surging Giant Tidal Wave
        const wave = new THREE.Group();
        const waterMat = flatMat(0x1da1ff, { emissive: 0x0d7ce6, emissiveIntensity: 0.85, transparent: true, opacity: 0.82 });
        const foamMat = flatMat(0xb8f8ff, { emissive: 0x88f3ff, emissiveIntensity: 1.1 });
        wave.add(new THREE.Mesh(new THREE.BoxGeometry(7.2, 3.0, 2.2), waterMat));
        const crest = new THREE.Mesh(new THREE.BoxGeometry(7.4, 0.7, 1.4), foamMat);
        crest.position.set(0, 1.6, -0.5);
        wave.add(crest);
        const startPos = caster.position.clone().addScaledVector(flatFwd, 2.8);
        wave.position.copy(startPos).add(new THREE.Vector3(0, 1.4, 0));
        wave.rotation.y = caster.yaw;
        this.scene.add(wave);

        this.zones.push({
          caster, mesh: wave, pos: startPos, vel: flatFwd.clone().multiplyScalar(22), radius: 4.8, life: 2.0, age: 0, hitIds: new Set(),
          update: (z, dt) => {
            z.pos.addScaledVector(z.vel, dt);
            z.pos.y = Math.max(0, this.getGroundHeight(z.pos.x, z.pos.z));
            z.mesh.position.set(z.pos.x, z.pos.y + 1.4, z.pos.z);
            if (Math.random() < 0.5) this.vfx.spawnBurst(z.mesh.position, 0x88f3ff, 2, 6, 0.22);
            if (ctx.visualOnly) return;
            for (const f of fighters) {
              if (f === caster || z.hitIds.has(f.id)) continue;
              if (Math.hypot(f.position.x - z.pos.x, f.position.z - z.pos.z) < z.radius && Math.abs(f.position.y - z.pos.y) < 3.5) {
                z.hitIds.add(f.id);
                const kb = flatFwd.clone().multiplyScalar(28);
                kb.y = 12;
                f.takeDamage(21, kb, caster, ctx);
              }
            }
          },
        });
        break;
      }

      case 'nature': {
        // Ensnaring Thorn Briars at target
        const pt = this._getAimTargetPoint(caster, 26);
        const thornMat = flatMat(0x229954, { emissive: 0x1e8449, emissiveIntensity: 0.45 });
        const roseMat = flatMat(0xff8fab, { emissive: 0xff5c8a, emissiveIntensity: 0.9 });
        const bush = new THREE.Group();
        bush.position.copy(pt);
        for (let i = 0; i < 8; i++) {
          const a = (i / 8) * Math.PI * 2;
          const sp = new THREE.Mesh(new THREE.ConeGeometry(0.45, 2.8, 4), thornMat);
          sp.position.set(Math.cos(a) * 2.2, 1.2, Math.sin(a) * 2.2);
          sp.rotation.z = -Math.cos(a) * 0.4;
          sp.rotation.x = Math.sin(a) * 0.4;
          bush.add(sp);
        }
        bush.add(new THREE.Mesh(new THREE.OctahedronGeometry(0.65, 0), roseMat)).position.set(0, 1.5, 0);
        this.vfx.spawnTemporaryMesh(bush, 2.4);
        this.vfx.spawnRing(pt, 0x38d97c, 6.0, 0.45);
        this._aoeDamage(pt, 5.8, 18, 8, 8, caster, fighters, ctx, (t) => {
          t.freezeTimer = Math.max(t.freezeTimer, 1.8);
          t.poisonTimer = Math.max(t.poisonTimer, 2.5);
        });
        break;
      }

      case 'magma': {
        // Lava Crater Eruption ahead
        const pt = this._getAimTargetPoint(caster, 24);
        const lavaMat = flatMat(0xff4221, { emissive: 0xff2b00, emissiveIntensity: 1.4, transparent: true, opacity: 0.85 });
        const crater = new THREE.Mesh(new THREE.CylinderGeometry(5.5, 6.2, 0.35, 10), lavaMat);
        crater.position.set(pt.x, pt.y + 0.15, pt.z);
        this.scene.add(crater);
        this.vfx.spawnBurst(pt, 0xffae2b, 22, 14, 0.32);
        this.vfx.spawnRing(pt, 0xff4221, 7.2, 0.45);
        this._aoeDamage(pt, 6.2, 20, 18, 14, caster, fighters, ctx, (t) => { t.burnTimer = Math.max(t.burnTimer, 4.0); });

        this.zones.push({
          caster, mesh: crater, pos: pt, radius: 6.0, life: 4.5, age: 0, tick: 0,
          update: (z, dt) => {
            z.tick -= dt;
            if (z.tick <= 0) {
              z.tick = 0.6;
              this.vfx.spawnBurst(z.pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 6, 0.4, (Math.random() - 0.5) * 6)), 0xffae2b, 3, 6, 0.2);
              if (ctx.visualOnly) return;
              for (const f of fighters) {
                if (f !== caster && Math.hypot(f.position.x - z.pos.x, f.position.z - z.pos.z) < z.radius && Math.abs(f.position.y - z.pos.y) < 3.2) {
                  f.takeDamage(9, new THREE.Vector3(0, 6, 0), caster, { ...ctx, status: { burn: 3 } });
                  if (!f.isRemotePlayer) f.burnTimer = Math.max(f.burnTimer, 3.0);
                }
              }
            }
          },
        });
        break;
      }

      case 'blood': {
        // Crimson Draining Lance (heals +14 HP on hit)
        const lance = new THREE.Mesh(new THREE.ConeGeometry(0.45, 2.2, 5), flatMat(0xe62249, { emissive: 0xd90429, emissiveIntensity: 1.5 }));
        lance.position.copy(eye).addScaledVector(forward, 1.4);
        lance.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), forward);
        this.scene.add(lance);
        this._spawnProj({
          caster, mesh: lance, vel: forward.clone().multiplyScalar(42), gravity: 0, radius: 1.1, life: 2.0, trailColor: 0xe62249,
          onHit: (pos) => {
            this.vfx.spawnBurst(pos, 0xe62249, 16, 10, 0.24);
            this.vfx.spawnRing(pos, 0xff809b, 4.5, 0.35);
            const hitCount = this._aoeDamage(pos, 4.2, 22, 16, 9, caster, fighters, ctx);
            if (!ctx.visualOnly && hitCount > 0) {
              caster.heal(14 * hitCount);
              if (caster.isPlayer) this.vfx.spawnFloatingText(caster.position.clone().add(new THREE.Vector3(0, 2.6, 0)), `+${14 * hitCount} PV`, '#52f295', ctx.camera);
            }
          },
        });
        break;
      }

      case 'sonic': {
        // Mach-1 Supersonic Dash + Sonic Boom
        if (!ctx.visualOnly) {
          caster.velocity.x = flatFwd.x * 38;
          caster.velocity.z = flatFwd.z * 38;
          caster.velocity.y = 6;
        }
        this.vfx.spawnRing(caster.position, 0x00f2fe, 8.5, 0.35, 1.1);
        this.vfx.spawnBurst(caster.position.clone().add(new THREE.Vector3(0, 1.2, 0)), 0xffd43b, 20, 14, 0.22);
        const endPt = caster.position.clone().addScaledVector(flatFwd, 8);
        this._aoeDamage(endPt, 6.8, 18, 22, 11, caster, fighters, ctx);
        break;
      }

      case 'crystal': {
        // Prismatic Explosive Crystal Wall
        const right = new THREE.Vector3(-flatFwd.z, 0, flatFwd.x);
        const base = caster.position.clone().addScaledVector(flatFwd, 5.5);
        const mat = flatMat(0x5cf2ff, { emissive: 0x29dfff, emissiveIntensity: 1.2 });
        for (let i = -2; i <= 2; i++) {
          const pt = base.clone().addScaledVector(right, i * 1.9);
          pt.y = Math.max(0, this.getGroundHeight(pt.x, pt.z));
          const pillar = new THREE.Mesh(new THREE.OctahedronGeometry(1.15, 0), mat);
          pillar.scale.set(0.85, 2.2, 0.85);
          pillar.position.set(pt.x, pt.y + 1.8, pt.z);
          this.vfx.spawnTemporaryMesh(pillar, 1.8);
        }
        this.vfx.spawnRing(base, 0xe0aaff, 6.8, 0.45);
        this._aoeDamage(base, 6.5, 21, 20, 12, caster, fighters, ctx);
        break;
      }

      case 'dragon': {
        // 5-Fireball Golden Dragon Breath Fan
        for (let i = -2; i <= 2; i++) {
          const dir = forward.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), i * 0.14).normalize();
          const orb = new THREE.Mesh(new THREE.IcosahedronGeometry(0.55, 0), flatMat(0xff9214, { emissive: 0xff6b00, emissiveIntensity: 1.5 }));
          orb.position.copy(eye).addScaledVector(dir, 1.5);
          this.scene.add(orb);
          this._spawnProj({
            caster, mesh: orb, vel: dir.multiplyScalar(34), gravity: 3, radius: 1.1, life: 1.8, trailColor: 0xffe047,
            onHit: (pos) => {
              this.vfx.spawnBurst(pos, 0xff9214, 10, 10, 0.22);
              this._aoeDamage(pos, 4.0, 14, 16, 8, caster, fighters, ctx, (t) => { t.burnTimer = Math.max(t.burnTimer, 3.0); });
            },
          });
        }
        break;
      }

      case 'void': {
        // Slow Pulling Void Rift Orb that explodes violently
        const orb = new THREE.Group();
        orb.add(new THREE.Mesh(new THREE.IcosahedronGeometry(1.0, 0), flatMat(0x0d031a, { emissive: 0x6b15c9, emissiveIntensity: 1.2 })));
        const ring = new THREE.Mesh(new THREE.TorusGeometry(1.45, 0.12, 5, 14), flatMat(0xc77dff, { emissive: 0x9b30ff, emissiveIntensity: 1.5 }));
        orb.add(ring);
        orb.position.copy(eye).addScaledVector(forward, 1.8);
        this.scene.add(orb);
        this._spawnProj({
          caster, mesh: orb, vel: forward.clone().multiplyScalar(19), gravity: 0, radius: 1.6, life: 2.8, trailColor: 0x9b30ff,
          onHit: (pos) => {
            this.sound.playExplosion(1.0);
            this.vfx.spawnSphereFlash(pos, 0x9b30ff, 8.0, 0.45);
            this.vfx.spawnRing(pos, 0xe7c6ff, 9.0, 0.45);
            this.vfx.spawnBurst(pos, 0x9b30ff, 22, 14, 0.28);
            this._aoeDamage(pos, 8.2, 25, 24, 14, caster, fighters, ctx);
          },
        });
        break;
      }

      // Extended power set
      case 'star': {
        // 5 Curving Golden Shooting Stars
        for (let i = -2; i <= 2; i++) {
          const dir = forward.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), i * 0.13).normalize();
          const star = new THREE.Mesh(new THREE.OctahedronGeometry(0.55, 0), flatMat(0xffe047, { emissive: 0xffd43b, emissiveIntensity: 1.6 }));
          star.position.copy(eye).addScaledVector(dir, 1.5);
          this.scene.add(star);
          this._spawnProj({
            caster, mesh: star, vel: dir.multiplyScalar(38), gravity: 1.5, radius: 1.05, life: 1.8, trailColor: 0x9bf6ff,
            onHit: (pos) => {
              this.vfx.spawnBurst(pos, 0xffe047, 10, 11, 0.22);
              this.vfx.spawnRing(pos, 0x9bf6ff, 3.8, 0.3);
              this._aoeDamage(pos, 4.0, 13, 15, 8, caster, fighters, ctx);
            },
          });
        }
        break;
      }

      case 'prism': {
        // Triple-Layered Rainbow Laser Beam
        const start = eye.clone().addScaledVector(forward, 1.0);
        const end = start.clone().addScaledVector(forward, 42);
        this.vfx.spawnBeam(start, end, 0xff66d9, 0.85, 0.45);
        this.vfx.spawnBeam(start, end, 0x4df3ff, 0.55, 0.4);
        this.vfx.spawnBeam(start, end, 0xffe066, 0.28, 0.35);
        if (caster.isPlayer) this.vfx.addShake(0.38);
        if (!ctx.visualOnly) {
          const line = new THREE.Line3(start, end);
          const closest = new THREE.Vector3();
          for (const f of fighters) {
            if (f === caster || f.isDead) continue;
            const center = f.position.clone().add(new THREE.Vector3(0, 1.3 * f.currentScale, 0));
            line.closestPointToPoint(center, true, closest);
            if (closest.distanceTo(center) < 2.6 * f.currentScale) {
              const kb = flatFwd.clone().multiplyScalar(22);
              kb.y = 9;
              f.takeDamage(23, kb, caster, ctx);
              this.vfx.spawnBurst(center, 0xff66d9, 14, 11, 0.24);
            }
          }
        }
        break;
      }

      case 'mecha': {
        // Homing Guided Rocket Missile
        const rocket = new THREE.Group();
        rocket.add(new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.3, 1.3, 6), flatMat(0xd93838, { metalness: 0.5 })));
        const nose = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.5, 6), flatMat(0xffd43b, { emissive: 0xffaa00, emissiveIntensity: 0.9 }));
        nose.position.y = 0.85;
        rocket.add(nose);
        rocket.position.copy(eye).addScaledVector(forward, 1.5);
        rocket.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), forward);
        this.scene.add(rocket);
        this._spawnProj({
          caster, mesh: rocket, vel: forward.clone().multiplyScalar(28), gravity: 0, radius: 1.2, life: 3.2, homing: true, trailColor: 0xff922b,
          onHit: (pos) => {
            this.sound.playExplosion(1.1);
            this.vfx.spawnSphereFlash(pos, 0xff5252, 6.8, 0.4);
            this.vfx.spawnRing(pos, 0xffd43b, 7.5, 0.42);
            this.vfx.spawnBurst(pos, 0xff6b2b, 22, 14, 0.3);
            if (caster.isPlayer) this.vfx.addShake(0.55);
            this._aoeDamage(pos, 6.8, 25, 24, 13, caster, fighters, ctx);
          },
        });
        break;
      }

      case 'phoenix': {
        // Wide Sweeping Wave of Blazing Phoenix Wings
        const wing = new THREE.Mesh(
          new THREE.BoxGeometry(6.8, 1.6, 1.2),
          flatMat(0xff7b1c, { emissive: 0xff5500, emissiveIntensity: 1.5, transparent: true, opacity: 0.88 })
        );
        wing.position.copy(eye).addScaledVector(flatFwd, 2.2);
        wing.rotation.y = caster.yaw;
        this.scene.add(wing);
        this._spawnProj({
          caster, mesh: wing, vel: flatFwd.clone().multiplyScalar(32), gravity: 0, radius: 2.6, life: 1.4, trailColor: 0xffe866,
          onHit: (pos) => {
            this.vfx.spawnSphereFlash(pos, 0xff7b1c, 5.5, 0.35);
            this.vfx.spawnBurst(pos, 0xffe866, 18, 12, 0.25);
            this._aoeDamage(pos, 5.8, 21, 20, 11, caster, fighters, ctx, (t) => { t.burnTimer = Math.max(t.burnTimer, 3.5); });
          },
        });
        break;
      }

      case 'abyss': {
        // Spectral Anchor HOOK & PULL with live 3D Chain
        const anchor = new THREE.Group();
        const m = flatMat(0x00d2a8, { emissive: 0x00b894, emissiveIntensity: 1.35 });
        const dark = flatMat(0x163240, { metalness: 0.6 });
        anchor.add(new THREE.Mesh(new THREE.BoxGeometry(0.42, 2.1, 0.42), dark));
        anchor.add(new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.42, 0.42), m));
        anchor.add(new THREE.Mesh(new THREE.ConeGeometry(0.32, 0.7, 4), m)).position.set(-0.95, 0.4, 0);
        anchor.position.copy(eye).addScaledVector(forward, 1.8);
        this.scene.add(anchor);

        this._spawnProj({
          caster, mesh: anchor, vel: forward.clone().multiplyScalar(38), gravity: 5, radius: 1.65, life: 1.8, trailColor: 0x00d2a8,
          onHit: (pos) => {
            this.sound.playHookPull();
            // Draw visible 3D spectral chain from caster straight to impact
            this.vfx.spawnChain(caster.getEyePosition(), pos, 0x00f5c8, 0.55);
            this.vfx.spawnRing(pos, 0x00d2a8, 6.2, 0.4);
            this.vfx.spawnBurst(pos, 0x00f5c8, 22, 12, 0.28);
            if (caster.isPlayer) this.vfx.addShake(0.45);

            // HOOK & YANK enemies right toward the caster
            if (!ctx.visualOnly) {
              const pullDest = caster.position.clone().addScaledVector(flatFwd, 2.6);
              for (const f of fighters) {
                if (f === caster || f.isDead) continue;
                const d = Math.hypot(f.position.x - pos.x, f.position.z - pos.z);
                if (d < 6.4 && Math.abs(f.position.y - pos.y) < 4.5) {
                  const pullVec = pullDest.clone().sub(f.position);
                  const pullDist = pullVec.length();
                  pullVec.normalize().multiplyScalar(Math.min(36, Math.max(18, pullDist * 1.65)));
                  pullVec.y = 8.5;
                  f.takeDamage(20, pullVec, caster, { ...ctx, status: { slow: 1.8 } });
                  this.vfx.spawnChain(caster.getEyePosition(), f.position.clone().add(new THREE.Vector3(0, 1.3, 0)), 0x00f5c8, 0.65);
                }
              }
            }
          },
        });
        break;
      }

      case 'sand': {
        // Whirling Golden Sandstorm Wall moving forward
        const wall = new THREE.Group();
        const sandMat = flatMat(0xf5c242, { emissive: 0xd99b00, emissiveIntensity: 0.45, transparent: true, opacity: 0.72 });
        for (let i = -2; i <= 2; i++) {
          const col = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.5, 5.2, 6), sandMat);
          col.position.set(i * 1.8, 2.6, 0);
          wall.add(col);
        }
        const startPos = caster.position.clone().addScaledVector(flatFwd, 3.0);
        wall.position.copy(startPos);
        wall.rotation.y = caster.yaw;
        this.scene.add(wall);
        this.zones.push({
          caster, mesh: wall, pos: startPos, vel: flatFwd.clone().multiplyScalar(17), radius: 5.2, life: 2.2, age: 0, hitIds: new Set(),
          update: (z, dt) => {
            z.pos.addScaledVector(z.vel, dt);
            z.pos.y = Math.max(0, this.getGroundHeight(z.pos.x, z.pos.z));
            z.mesh.position.copy(z.pos);
            if (ctx.visualOnly) return;
            for (const f of fighters) {
              if (f === caster || f.isDead || z.hitIds.has(f.id)) continue;
              if (Math.hypot(f.position.x - z.pos.x, f.position.z - z.pos.z) < z.radius && Math.abs(f.position.y - z.pos.y) < 4.0) {
                z.hitIds.add(f.id);
                const kb = flatFwd.clone().multiplyScalar(24);
                kb.y = 10;
                f.takeDamage(19, kb, caster, { ...ctx, status: { slow: 2.5 } });
                if (!f.isRemotePlayer) f.slowTimer = Math.max(f.slowTimer, 2.5);
              }
            }
          },
        });
        break;
      }

      case 'magnet': {
        // Magnetic Pull — yanks all enemies straight in front of you for an instant combo
        const pullCenter = caster.position.clone().addScaledVector(flatFwd, 3.6);
        this.vfx.spawnRing(caster.position, 0x3792ff, 15.0, 0.45);
        this.vfx.spawnRing(pullCenter, 0xff4757, 5.5, 0.35);
        this.vfx.spawnBurst(pullCenter.clone().add(new THREE.Vector3(0, 1.2, 0)), 0x3792ff, 20, 10, 0.24);
        if (!ctx.visualOnly) {
          for (const f of fighters) {
            if (f === caster || f.isDead) continue;
            const d = f.position.distanceTo(caster.position);
            if (d < 16.5) {
              const pull = pullCenter.clone().sub(f.position).normalize().multiplyScalar(26);
              pull.y = 7.5;
              f.takeDamage(14, pull, caster, ctx);
            }
          }
        }
        break;
      }

      case 'samurai': {
        // Anime Iaijutsu Dash-Through Slash
        const startPos = caster.position.clone();
        const dest = startPos.clone().addScaledVector(flatFwd, 15);
        const gh = this.getGroundHeight(dest.x, dest.z);
        if (!ctx.visualOnly && gh > -10) caster.position.set(dest.x, Math.max(gh + 0.15, caster.position.y), dest.z);
        this.vfx.spawnBeam(startPos.clone().add(new THREE.Vector3(0, 1.3, 0)), dest.clone().add(new THREE.Vector3(0, 1.3, 0)), 0xff6b9d, 0.45, 0.35);
        this.vfx.spawnBurst(dest.clone().add(new THREE.Vector3(0, 1.4, 0)), 0xff99c8, 18, 12, 0.22);
        if (!ctx.visualOnly) {
          const line = new THREE.Line3(startPos, dest);
          const closest = new THREE.Vector3();
          for (const f of fighters) {
            if (f === caster || f.isDead) continue;
            line.closestPointToPoint(f.position, true, closest);
            if (closest.distanceTo(f.position) < 3.4) {
              const kb = flatFwd.clone().multiplyScalar(18);
              kb.y = 9;
              f.takeDamage(21, kb, caster, ctx);
              this.vfx.spawnSlashArc(f.position.clone().add(new THREE.Vector3(0, 1.4, 0)), flatFwd, 0xff6b9d, 1.8);
            }
          }
        }
        break;
      }
    }
    return true;
  }

  /**
   * Ability 2 (A / F) — Ultimates
   */
  castAbility2(caster, fighters, ctx) {
    if (!caster.hasPower || caster.isDead || caster.knockdownTimer > 0 || caster.ab2Cd > 0 || caster.freezeTimer > 0) return false;
    const p = caster.power;
    caster.ab2Cd = p.ab2.cooldown;
    caster.triggerAttackAnim();
    if (caster.isPlayer || caster.position.distanceTo(ctx.playerPos) < 48) {
      this.sound.playPower(p.id, 2);
    }

    const flatFwd = caster.getForwardDirection(false);

    switch (p.id) {
      case 'thunder': {
        const blinkDest = caster.position.clone().addScaledVector(flatFwd, 10);
        const gh = this.getGroundHeight(blinkDest.x, blinkDest.z);
        if (!ctx.visualOnly && gh > -10) caster.position.set(blinkDest.x, Math.max(gh + 0.3, caster.position.y), blinkDest.z);
        this.vfx.spawnSphereFlash(caster.position, 0x38d9ff, 10, 0.5, 0.35);
        this.vfx.spawnRing(caster.position, 0xffe066, 11, 0.5);
        if (caster.isPlayer) this.vfx.addShake(0.65);
        const origin = caster.position.clone();
        for (let i = 0; i < 4; i++) {
          this.delayedActions.push({
            timer: i * 0.2,
            fn: () => {
              const ang = (i / 4) * Math.PI * 2 + Math.random();
              const pt = origin.clone().add(new THREE.Vector3(Math.cos(ang) * 5.8, 0, Math.sin(ang) * 5.8));
              pt.y = Math.max(0, this.getGroundHeight(pt.x, pt.z));
              this.vfx.spawnLightningBolt(pt.clone().add(new THREE.Vector3(0, 26, 0)), pt, 0xffe066, 0.32, 9);
              this.vfx.spawnRing(pt, 0x38d9ff, 5.5, 0.35);
              this._aoeDamage(pt, 6.5, 17, 19, 13, caster, fighters, ctx);
            },
          });
        }
        break;
      }

      case 'pyro': {
        const impact = this._getAimTargetPoint(caster, 32);
        this.vfx.spawnRing(impact, 0xff551a, 10.0, 0.9);
        const meteor = new THREE.Mesh(new THREE.DodecahedronGeometry(2.8, 0), flatMat(0x3b1814, { emissive: 0xff4400, emissiveIntensity: 1.4 }));
        meteor.position.set(impact.x - 10, impact.y + 34, impact.z - 8);
        this.scene.add(meteor);
        const vel = impact.clone().sub(meteor.position).normalize().multiplyScalar(42);
        this._spawnProj({
          caster, mesh: meteor, vel, gravity: 0, radius: 3.0, life: 2.2, trailColor: 0xff6b2b,
          onHit: (pos) => {
            this.sound.playExplosion(1.3);
            this.vfx.spawnSphereFlash(pos, 0xff551a, 11.5, 0.55, 0.6);
            this.vfx.spawnRing(pos, 0xffd43b, 13.0, 0.55);
            this.vfx.spawnBurst(pos, 0xff6b2b, 32, 16, 0.42);
            if (caster.isPlayer) this.vfx.addShake(0.9);
            this._aoeDamage(pos, 12.0, 32, 28, 16, caster, fighters, ctx, (t) => { t.burnTimer = Math.max(t.burnTimer, 4.5); });
          },
        });
        break;
      }

      case 'cryo': {
        const center = caster.position.clone();
        this.vfx.spawnSphereFlash(center, 0x74e8ff, 12.5, 0.6, 0.45);
        this.vfx.spawnRing(center, 0xd8f9ff, 13.5, 0.65);
        this.vfx.spawnBurst(center.clone().add(new THREE.Vector3(0, 1.5, 0)), 0xbdf5ff, 30, 14, 0.3, 6);
        if (caster.isPlayer) this.vfx.addShake(0.5);
        this._aoeDamage(center, 13.0, 22, 14, 10, caster, fighters, ctx, (t) => { t.freezeTimer = Math.max(t.freezeTimer, 3.2); });
        break;
      }

      case 'gravity': {
        const center = caster.position.clone();
        this.vfx.spawnRing(center, 0xb15cff, 14.0, 0.6);
        this.vfx.spawnBurst(center.clone().add(new THREE.Vector3(0, 1.5, 0)), 0xff87eb, 24, 10, 0.26, -8, 0.7);
        if (!ctx.visualOnly) {
          for (const f of fighters) {
            if (f !== caster && f.position.distanceTo(center) < 14.0) {
              f.velocity.y = 14;
              f.onGround = false;
              f.zeroGTimer = 1.35;
              this.delayedActions.push({
                timer: 1.45,
                fn: () => {
                  if (f.hp > 0) {
                    f.takeDamage(26, new THREE.Vector3(0, -18, 0), caster, ctx);
                    this.vfx.spawnRing(f.position, 0xb15cff, 5.5, 0.4);
                    if (caster.isPlayer) this.vfx.addShake(0.6);
                  }
                },
              });
            }
          }
        }
        break;
      }

      case 'wind': {
        if (!ctx.visualOnly) {
          caster.velocity.y = 25;
          caster.velocity.addScaledVector(flatFwd, 15);
          caster.onGround = false;
        }
        this.vfx.spawnRing(caster.position, 0x63f5b8, 12.5, 0.5);
        this.vfx.spawnBurst(caster.position, 0xe6fff5, 24, 15, 0.25, 3);
        this._aoeDamage(caster.position, 12.0, 17, 32, 16, caster, fighters, ctx);
        break;
      }

      case 'earth': {
        const center = caster.position.clone();
        const rockMat = flatMat(0x6c6157, { roughness: 0.95 });
        for (let i = 0; i < 10; i++) {
          const a = (i / 10) * Math.PI * 2;
          const pt = center.clone().add(new THREE.Vector3(Math.cos(a) * 6.8, 0, Math.sin(a) * 6.8));
          pt.y = this.getGroundHeight(pt.x, pt.z);
          if (pt.y < -10) continue;
          const pillar = new THREE.Mesh(new THREE.BoxGeometry(1.8, 4.8, 1.5), rockMat);
          pillar.position.set(pt.x, pt.y + 2.0, pt.z);
          pillar.rotation.set((Math.random() - 0.5) * 0.25, -a, (Math.random() - 0.5) * 0.25);
          this.vfx.spawnTemporaryMesh(pillar, 2.2);
        }
        this.vfx.spawnRing(center, 0xd99a4e, 12.0, 0.5);
        this.vfx.spawnBurst(center, 0xd99a4e, 26, 14, 0.35);
        if (caster.isPlayer) this.vfx.addShake(0.8);
        this._aoeDamage(center, 11.5, 28, 25, 16, caster, fighters, ctx);
        break;
      }

      case 'shadow': {
        const skullMat = flatMat(0x7c4dff, { emissive: 0x7c4dff, emissiveIntensity: 1.4 });
        for (let i = 0; i < 5; i++) {
          const ang = (i / 5) * Math.PI * 2;
          const mesh = new THREE.Mesh(new THREE.OctahedronGeometry(0.55, 0), skullMat);
          mesh.position.copy(caster.position).add(new THREE.Vector3(Math.cos(ang) * 2.2, 2.1, Math.sin(ang) * 2.2));
          this.scene.add(mesh);
          this._spawnProj({
            caster, mesh, vel: new THREE.Vector3(Math.cos(ang) * 8, 5, Math.sin(ang) * 8), gravity: 0, radius: 1.0, life: 4.0, homing: true, trailColor: 0x7c4dff,
            onHit: (pos) => {
              this.vfx.spawnBurst(pos, 0x7c4dff, 10, 9, 0.22);
              this._aoeDamage(pos, 3.6, 12, 12, 7, caster, fighters, ctx);
            },
          });
        }
        break;
      }

      case 'light': {
        if (!ctx.visualOnly) caster.heal(25);
        if (caster.isPlayer) this.vfx.spawnFloatingText(caster.position.clone().add(new THREE.Vector3(0, 2.6, 0)), '+25 PV', '#52f295', ctx.camera);
        this.vfx.spawnSphereFlash(caster.position, 0xfff099, 13.5, 0.65, 0.58);
        this.vfx.spawnRing(caster.position, 0xffd94a, 14.5, 0.6);
        this.vfx.spawnBurst(caster.position.clone().add(new THREE.Vector3(0, 1.5, 0)), 0xffd94a, 28, 16, 0.3);
        if (caster.isPlayer) this.vfx.addShake(0.65);
        this._aoeDamage(caster.position, 13.5, 26, 28, 15, caster, fighters, ctx);
        break;
      }

      case 'poison': {
        const center = caster.position.clone();
        const cloudGroup = new THREE.Group();
        const sporeMat = flatMat(0x5df249, { emissive: 0x32cc1d, emissiveIntensity: 0.7, transparent: true, opacity: 0.42 });
        for (let i = 0; i < 8; i++) {
          const a = (i / 8) * Math.PI * 2;
          const puff = new THREE.Mesh(new THREE.IcosahedronGeometry(2.7, 0), sporeMat);
          puff.position.set(Math.cos(a) * 4.6, 1.8 + (i % 2) * 1.2, Math.sin(a) * 4.6);
          cloudGroup.add(puff);
        }
        cloudGroup.position.copy(center);
        this.scene.add(cloudGroup);
        this.zones.push({
          caster, mesh: cloudGroup, pos: center, radius: 11.0, life: 5.5, age: 0, tick: 0,
          update: (z, dt) => {
            z.mesh.rotation.y += dt * 0.6;
            z.tick -= dt;
            if (z.tick <= 0 && !ctx.visualOnly) {
              z.tick = 0.6;
              for (const f of fighters) {
                if (f !== caster && f.position.distanceTo(z.pos) < z.radius) {
                  f.takeDamage(9, null, caster, { ...ctx, status: { poison: 4 } });
                  if (!f.isRemotePlayer) f.poisonTimer = Math.max(f.poisonTimer, 4.0);
                }
              }
            }
          },
        });
        break;
      }

      case 'chrono': {
        const snap = caster.history.length > 0 ? caster.history[0] : null;
        this.vfx.spawnRing(caster.position, 0x34e8d6, 5.5, 0.45);
        this.vfx.spawnBurst(caster.position.clone().add(new THREE.Vector3(0, 1.4, 0)), 0xffd166, 16, 8, 0.2);
        if (!ctx.visualOnly) {
          if (snap) {
            const gained = Math.max(0, Math.round(snap.hp - caster.hp));
            caster.position.copy(snap.pos);
            caster.velocity.set(0, 0, 0);
            caster.hp = Math.max(caster.hp, snap.hp);
            if (gained > 0 && caster.isPlayer) this.vfx.spawnFloatingText(caster.position.clone().add(new THREE.Vector3(0, 2.5, 0)), `+${gained} PV`, '#34e8d6', ctx.camera);
          } else {
            caster.heal(20);
          }
          caster.invulnTimer = Math.max(caster.invulnTimer, 0.8);
        }
        this.vfx.spawnRing(caster.position, 0xffd166, 6.0, 0.45);
        break;
      }

      case 'cyber': {
        const targetPos = this._getAimTargetPoint(caster, 36);
        const reticle = new THREE.Mesh(
          new THREE.RingGeometry(4.4, 5.2, 16),
          new THREE.MeshBasicMaterial({ color: 0xff3b9a, side: THREE.DoubleSide, transparent: true, opacity: 0.9 })
        );
        reticle.rotation.x = -Math.PI / 2;
        reticle.position.set(targetPos.x, targetPos.y + 0.16, targetPos.z);
        this.vfx.spawnTemporaryMesh(reticle, 0.85, (e, prog) => {
          e.mesh.rotation.z = prog * 6;
          e.mesh.scale.setScalar(1.15 - prog * 0.35);
        });
        this.delayedActions.push({
          timer: 0.78,
          fn: () => {
            const sky = targetPos.clone().add(new THREE.Vector3(0, 48, 0));
            this.vfx.spawnBeam(sky, targetPos, 0x29f0ff, 2.9, 0.75);
            this.vfx.spawnBeam(sky, targetPos, 0xff3b9a, 1.5, 0.65);
            this.vfx.spawnSphereFlash(targetPos, 0x29f0ff, 11.5, 0.55, 0.55);
            this.vfx.spawnRing(targetPos, 0xff3b9a, 13.0, 0.55);
            this.vfx.spawnBurst(targetPos, 0x29f0ff, 30, 16, 0.35);
            if (caster.isPlayer) this.vfx.addShake(0.95);
            this._aoeDamage(targetPos, 11.0, 34, 28, 17, caster, fighters, ctx);
          },
        });
        break;
      }

      case 'titan': {
        if (!ctx.visualOnly) {
          caster.titanTimer = 6.5;
          caster.heal(15);
        }
        this.vfx.spawnSphereFlash(caster.position, 0xffaa2b, 9.0, 0.45, 0.45);
        this.vfx.spawnRing(caster.position, 0xffe066, 11.0, 0.5);
        if (caster.isPlayer) this.vfx.addShake(0.7);
        this._aoeDamage(caster.position, 9.0, 18, 24, 13, caster, fighters, ctx);
        break;
      }

      // Extended power set
      case 'aqua': {
        // Colossal Abyssal Water Geyser at target
        const pt = this._getAimTargetPoint(caster, 30);
        const top = pt.clone().add(new THREE.Vector3(0, 28, 0));
        this.vfx.spawnBeam(pt, top, 0x1da1ff, 3.6, 0.9);
        this.vfx.spawnRing(pt, 0x88f3ff, 12.0, 0.55);
        this.vfx.spawnBurst(pt.clone().add(new THREE.Vector3(0, 2, 0)), 0x88f3ff, 32, 18, 0.35);
        if (caster.isPlayer) this.vfx.addShake(0.75);
        this._aoeDamage(pt, 10.0, 28, 14, 28, caster, fighters, ctx);
        break;
      }

      case 'nature': {
        // Blooming Floral Sanctuary (+32 HP heal + petal shockwave)
        if (!ctx.visualOnly) caster.heal(32);
        if (caster.isPlayer) this.vfx.spawnFloatingText(caster.position.clone().add(new THREE.Vector3(0, 2.6, 0)), '+32 PV', '#38d97c', ctx.camera);
        this.vfx.spawnRing(caster.position, 0x38d97c, 13.0, 0.6);
        this.vfx.spawnRing(caster.position, 0xff8fab, 10.0, 0.5);
        this.vfx.spawnBurst(caster.position.clone().add(new THREE.Vector3(0, 1.4, 0)), 0xff8fab, 30, 14, 0.28, 4);
        this._aoeDamage(caster.position, 11.5, 22, 24, 14, caster, fighters, ctx, (t) => { t.slowTimer = Math.max(t.slowTimer, 2.5); });
        break;
      }

      case 'magma': {
        // Volcanic Rain of 6 Explosive Lava Bombs
        const origin = caster.position.clone().add(new THREE.Vector3(0, 2.4, 0));
        for (let i = 0; i < 6; i++) {
          const ang = (i / 6) * Math.PI * 2;
          const bomb = new THREE.Mesh(new THREE.DodecahedronGeometry(0.95, 0), flatMat(0xff4221, { emissive: 0xff2b00, emissiveIntensity: 1.5 }));
          bomb.position.copy(origin);
          this.scene.add(bomb);
          const vel = new THREE.Vector3(Math.cos(ang) * 14, 15 + Math.random() * 5, Math.sin(ang) * 14);
          this._spawnProj({
            caster, mesh: bomb, vel, gravity: 24, radius: 1.3, life: 2.6, trailColor: 0xffae2b,
            onHit: (pos) => {
              this.sound.playExplosion(0.8);
              this.vfx.spawnSphereFlash(pos, 0xff4221, 6.0, 0.38);
              this.vfx.spawnBurst(pos, 0xffae2b, 16, 12, 0.28);
              this._aoeDamage(pos, 6.0, 20, 20, 12, caster, fighters, ctx, (t) => { t.burnTimer = Math.max(t.burnTimer, 3.5); });
            },
          });
        }
        break;
      }

      case 'blood': {
        // Crimson Vampire Nova — damages everyone around & drains massive HP
        this.vfx.spawnSphereFlash(caster.position, 0xe62249, 13.0, 0.55, 0.52);
        this.vfx.spawnRing(caster.position, 0xff809b, 13.5, 0.55);
        this.vfx.spawnBurst(caster.position.clone().add(new THREE.Vector3(0, 1.4, 0)), 0xe62249, 32, 16, 0.28);
        if (caster.isPlayer) this.vfx.addShake(0.65);
        const hits = this._aoeDamage(caster.position, 13.0, 25, 22, 13, caster, fighters, ctx);
        if (!ctx.visualOnly && hits > 0) {
          const healAmt = Math.min(45, hits * 14);
          caster.heal(healAmt);
          if (caster.isPlayer) this.vfx.spawnFloatingText(caster.position.clone().add(new THREE.Vector3(0, 2.7, 0)), `+${healAmt} PV`, '#ff809b', ctx.camera);
        }
        break;
      }

      case 'sonic': {
        // Rapid 6-Wave Supersonic Barrage
        for (let i = 0; i < 6; i++) {
          this.delayedActions.push({
            timer: i * 0.09,
            fn: () => {
              const dir = caster.getForwardDirection(true);
              const wave = new THREE.Mesh(
                new THREE.TorusGeometry(1.4, 0.16, 5, 14),
                flatMat(i % 2 === 0 ? 0x00f2fe : 0xffd43b, { emissive: i % 2 === 0 ? 0x00d9ff : 0xffaa00, emissiveIntensity: 1.5 })
              );
              const start = caster.getEyePosition().addScaledVector(dir, 1.5);
              wave.position.copy(start);
              wave.lookAt(start.clone().add(dir));
              this.scene.add(wave);
              this._spawnProj({
                caster, mesh: wave, vel: dir.clone().multiplyScalar(52), gravity: 0, radius: 1.6, life: 1.2, trailColor: 0x00f2fe,
                onHit: (pos) => {
                  this.vfx.spawnRing(pos, 0x00f2fe, 4.0, 0.28);
                  this._aoeDamage(pos, 3.8, 10, 16, 7, caster, fighters, ctx);
                },
              });
            },
          });
        }
        break;
      }

      case 'crystal': {
        // Rain of 8 Diamond Spears from the sky
        const center = this._getAimTargetPoint(caster, 28);
        const mat = flatMat(0x5cf2ff, { emissive: 0x29dfff, emissiveIntensity: 1.4 });
        for (let i = 0; i < 8; i++) {
          this.delayedActions.push({
            timer: i * 0.1,
            fn: () => {
              const ang = Math.random() * Math.PI * 2;
              const r = Math.random() * 7.5;
              const pt = new THREE.Vector3(center.x + Math.cos(ang) * r, 0, center.z + Math.sin(ang) * r);
              pt.y = Math.max(0, this.getGroundHeight(pt.x, pt.z));
              const spear = new THREE.Mesh(new THREE.ConeGeometry(0.6, 3.6, 5), mat);
              spear.rotation.x = Math.PI;
              spear.position.set(pt.x, pt.y + 24, pt.z);
              this.scene.add(spear);
              this._spawnProj({
                caster, mesh: spear, vel: new THREE.Vector3(0, -46, 0), gravity: 0, radius: 1.4, life: 1.2, trailColor: 0xe0aaff,
                onHit: (pos) => {
                  this.vfx.spawnBurst(pos, 0x5cf2ff, 12, 10, 0.25);
                  this.vfx.spawnRing(pos, 0xe0aaff, 4.8, 0.32);
                  this._aoeDamage(pos, 4.8, 16, 16, 10, caster, fighters, ctx);
                },
              });
            },
          });
        }
        break;
      }

      case 'dragon': {
        // Draconic Sky Leap -> Blazing Dive Slam
        if (!ctx.visualOnly) {
          caster.velocity.y = 22;
          caster.velocity.addScaledVector(flatFwd, 18);
          caster.onGround = false;
        }
        this.vfx.spawnRing(caster.position, 0xff9214, 9.0, 0.45);
        this.delayedActions.push({
          timer: 0.72,
          fn: () => {
            if (!ctx.visualOnly) caster.velocity.y = -32;
            const landPt = caster.position.clone();
            landPt.y = Math.max(0, this.getGroundHeight(landPt.x, landPt.z));
            this.sound.playExplosion(1.2);
            this.vfx.spawnSphereFlash(landPt, 0xff9214, 13.0, 0.55, 0.55);
            this.vfx.spawnRing(landPt, 0xffe047, 14.5, 0.6);
            this.vfx.spawnBurst(landPt, 0xff9214, 34, 18, 0.36);
            if (caster.isPlayer) this.vfx.addShake(0.9);
            this._aoeDamage(landPt, 13.0, 32, 30, 17, caster, fighters, ctx, (t) => { t.burnTimer = Math.max(t.burnTimer, 4.0); });
          },
        });
        break;
      }

      case 'void': {
        // Double Dimensional Void Cataclysm (pull inward -> massive outward blast)
        const center = caster.position.clone();
        this.vfx.spawnSphereFlash(center, 0x2f0b59, 14.0, 0.7, 0.55);
        this.vfx.spawnRing(center, 0x9b30ff, 15.0, 0.7);
        if (!ctx.visualOnly) {
          for (const f of fighters) {
            if (f !== caster && f.position.distanceTo(center) < 15.0) {
              const pull = center.clone().sub(f.position).normalize().multiplyScalar(22);
              pull.y = 6;
              f.velocity.add(pull);
            }
          }
        }
        this.delayedActions.push({
          timer: 0.55,
          fn: () => {
            this.sound.playExplosion(1.3);
            this.vfx.spawnSphereFlash(center, 0x9b30ff, 14.5, 0.55, 0.6);
            this.vfx.spawnRing(center, 0xe7c6ff, 16.0, 0.6);
            this.vfx.spawnBurst(center, 0xc77dff, 34, 18, 0.35);
            if (caster.isPlayer) this.vfx.addShake(0.95);
            this._aoeDamage(center, 14.5, 34, 32, 18, caster, fighters, ctx);
          },
        });
        break;
      }

      // Extended power set
      case 'star': {
        // Super-Star Nova at aimed point
        const pt = this._getAimTargetPoint(caster, 32);
        const star = new THREE.Mesh(new THREE.OctahedronGeometry(2.8, 0), flatMat(0xffe047, { emissive: 0xffd43b, emissiveIntensity: 1.6 }));
        star.position.set(pt.x, pt.y + 18, pt.z);
        this.scene.add(star);
        this._spawnProj({
          caster, mesh: star, vel: new THREE.Vector3(0, -34, 0), gravity: 0, radius: 3.0, life: 1.5, trailColor: 0x9bf6ff,
          onHit: (pos) => {
            this.sound.playExplosion(1.25);
            this.vfx.spawnSphereFlash(pos, 0xffe047, 13.0, 0.55, 0.58);
            this.vfx.spawnRing(pos, 0x9bf6ff, 14.0, 0.55);
            this.vfx.spawnBurst(pos, 0xffe047, 34, 18, 0.36);
            if (caster.isPlayer) this.vfx.addShake(0.85);
            this._aoeDamage(pos, 13.0, 32, 28, 17, caster, fighters, ctx);
          },
        });
        break;
      }

      case 'prism': {
        // Multi-Ring Rainbow Chromatic Explosion
        const rainbow = [0xff4d6d, 0xff9f1c, 0xffe066, 0x38d97c, 0x29f0ff, 0x9b5de5];
        rainbow.forEach((hex, idx) => {
          this.delayedActions.push({
            timer: idx * 0.06,
            fn: () => this.vfx.spawnRing(caster.position, hex, 8 + idx * 1.4, 0.5),
          });
        });
        this.vfx.spawnSphereFlash(caster.position, 0xff66d9, 13.0, 0.55, 0.45);
        this.vfx.spawnBurst(caster.position.clone().add(new THREE.Vector3(0, 1.5, 0)), 0x4df3ff, 30, 16, 0.3);
        if (caster.isPlayer) this.vfx.addShake(0.65);
        this._aoeDamage(caster.position, 13.0, 27, 28, 15, caster, fighters, ctx);
        break;
      }

      case 'mecha': {
        // Salvo of 6 Homing Shoulder Micro-Missiles
        for (let i = 0; i < 6; i++) {
          this.delayedActions.push({
            timer: i * 0.1,
            fn: () => {
              const ang = (i / 6) * Math.PI * 2;
              const m = new THREE.Mesh(new THREE.ConeGeometry(0.32, 1.1, 5), flatMat(0xff5252, { emissive: 0xff3b3b, emissiveIntensity: 1.3 }));
              m.position.copy(caster.position).add(new THREE.Vector3(Math.cos(ang) * 1.8, 2.6, Math.sin(ang) * 1.8));
              this.scene.add(m);
              this._spawnProj({
                caster, mesh: m, vel: new THREE.Vector3(Math.cos(ang) * 10, 14, Math.sin(ang) * 10), gravity: 0, radius: 1.0, life: 3.4, homing: true, trailColor: 0x40c4ff,
                onHit: (pos) => {
                  this.sound.playExplosion(0.7);
                  this.vfx.spawnSphereFlash(pos, 0xff5252, 4.5, 0.3);
                  this.vfx.spawnBurst(pos, 0xffd43b, 12, 11, 0.24);
                  this._aoeDamage(pos, 4.6, 13, 15, 9, caster, fighters, ctx);
                },
              });
            },
          });
        }
        break;
      }

      case 'phoenix': {
        // Fiery Phoenix Rebirth — Sky leap, +35 HP heal, massive golden fire nova
        if (!ctx.visualOnly) {
          caster.heal(35);
          caster.velocity.y = 18;
          caster.onGround = false;
        }
        if (caster.isPlayer) this.vfx.spawnFloatingText(caster.position.clone().add(new THREE.Vector3(0, 2.6, 0)), '+35 PV', '#ffe866', ctx.camera);
        this.vfx.spawnSphereFlash(caster.position, 0xff7b1c, 13.5, 0.6, 0.55);
        this.vfx.spawnRing(caster.position, 0xffe866, 14.5, 0.6);
        this.vfx.spawnBurst(caster.position.clone().add(new THREE.Vector3(0, 1.5, 0)), 0xff7b1c, 34, 17, 0.32);
        if (caster.isPlayer) this.vfx.addShake(0.75);
        this._aoeDamage(caster.position, 13.5, 28, 28, 16, caster, fighters, ctx, (t) => { t.burnTimer = Math.max(t.burnTimer, 4.5); });
        break;
      }

      case 'abyss': {
        // 6 Giant Spectral Kraken Tentacles erupting around you
        const tentMat = flatMat(0x00d2a8, { emissive: 0x00a884, emissiveIntensity: 0.9 });
        const center = caster.position.clone();
        for (let i = 0; i < 6; i++) {
          const a = (i / 6) * Math.PI * 2;
          const pt = center.clone().add(new THREE.Vector3(Math.cos(a) * 6.0, 0, Math.sin(a) * 6.0));
          pt.y = Math.max(0, this.getGroundHeight(pt.x, pt.z));
          const tent = new THREE.Mesh(new THREE.ConeGeometry(0.95, 7.5, 6), tentMat);
          tent.position.set(pt.x, pt.y + 3.2, pt.z);
          tent.rotation.z = -Math.cos(a) * 0.35;
          tent.rotation.x = Math.sin(a) * 0.35;
          this.vfx.spawnTemporaryMesh(tent, 2.0);
        }
        this.vfx.spawnRing(center, 0x00d2a8, 12.5, 0.55);
        this.vfx.spawnBurst(center, 0x00f5c8, 28, 15, 0.32);
        if (caster.isPlayer) this.vfx.addShake(0.8);
        this._aoeDamage(center, 12.5, 30, 26, 17, caster, fighters, ctx);
        break;
      }

      case 'sand': {
        // Colossal Golden Pharaoh Pyramid crashing onto target
        const pt = this._getAimTargetPoint(caster, 30);
        const pyr = new THREE.Mesh(
          new THREE.ConeGeometry(6.5, 8.5, 4),
          flatMat(0xf5c242, { metalness: 0.45, emissive: 0xc28a00, emissiveIntensity: 0.4 })
        );
        pyr.position.set(pt.x, pt.y + 22, pt.z);
        this.scene.add(pyr);
        this._spawnProj({
          caster, mesh: pyr, vel: new THREE.Vector3(0, -38, 0), gravity: 0, radius: 5.0, life: 1.5, trailColor: 0xffe794,
          onHit: (pos) => {
            this.sound.playExplosion(1.3);
            const landed = new THREE.Mesh(
              new THREE.ConeGeometry(6.2, 8.0, 4),
              flatMat(0xf5c242, { metalness: 0.4, emissive: 0xb07c00, emissiveIntensity: 0.3 })
            );
            landed.position.set(pos.x, Math.max(0, this.getGroundHeight(pos.x, pos.z)) + 3.8, pos.z);
            this.vfx.spawnTemporaryMesh(landed, 2.6);
            this.vfx.spawnRing(pos, 0xf5c242, 13.0, 0.55);
            this.vfx.spawnBurst(pos, 0xffe794, 30, 16, 0.35);
            if (caster.isPlayer) this.vfx.addShake(0.9);
            this._aoeDamage(pos, 11.5, 33, 28, 16, caster, fighters, ctx, (t) => { t.slowTimer = Math.max(t.slowTimer, 2.5); });
          },
        });
        break;
      }

      case 'magnet': {
        // Massive Electromagnetic Repulsion Pulse — launches everyone super far
        this.vfx.spawnRing(caster.position, 0xff4757, 16.0, 0.55);
        this.vfx.spawnRing(caster.position, 0x3792ff, 13.0, 0.45);
        this.vfx.spawnSphereFlash(caster.position, 0xff4757, 12.0, 0.45, 0.4);
        this.vfx.spawnBurst(caster.position.clone().add(new THREE.Vector3(0, 1.4, 0)), 0x3792ff, 30, 18, 0.28);
        if (caster.isPlayer) this.vfx.addShake(0.75);
        this._aoeDamage(caster.position, 15.0, 24, 38, 18, caster, fighters, ctx);
        break;
      }

      case 'samurai': {
        // Dome of 1000 Sakura Sword Slashes
        const center = caster.position.clone().add(new THREE.Vector3(0, 1.5, 0));
        this.vfx.spawnSphereFlash(center, 0xff6b9d, 12.0, 0.65, 0.3);
        this.vfx.spawnRing(caster.position, 0xff99c8, 12.5, 0.65);
        for (let i = 0; i < 8; i++) {
          this.delayedActions.push({
            timer: i * 0.08,
            fn: () => {
              const d = new THREE.Vector3(Math.random() - 0.5, (Math.random() - 0.5) * 0.4, Math.random() - 0.5).normalize();
              this.vfx.spawnSlashArc(center.clone().addScaledVector(d, 2.2), d, i % 2 ? 0xff6b9d : 0xffffff, 2.4);
              this.vfx.spawnBurst(center, 0xffa6d1, 5, 12, 0.2);
            },
          });
        }
        if (caster.isPlayer) this.vfx.addShake(0.65);
        this._aoeDamage(caster.position, 12.0, 31, 24, 15, caster, fighters, ctx);
        break;
      }
    }
    return true;
  }

  /**
   * Ability 3 (R) — Tactical ability grouped by power archetype
   * (grapple chain, shield barrier, sky slam, or auto-firing turret).
   */
  castAbility3(caster, fighters, ctx) {
    if (!caster.hasPower || caster.isDead || caster.knockdownTimer > 0 || caster.ab3Cd > 0 || caster.freezeTimer > 0) return false;
    const p = caster.power;
    caster.ab3Cd = 8.0;
    caster.triggerAttackAnim();
    const flatFwd = caster.getForwardDirection(false);
    const forward = caster.getForwardDirection(true);
    const eye = caster.getEyePosition();

    const hookSet = new Set(['abyss', 'nature', 'magnet', 'void', 'gravity']);
    const shieldSet = new Set(['cryo', 'earth', 'crystal', 'titan', 'light', 'sand']);
    const leapSet = new Set(['thunder', 'wind', 'shadow', 'sonic', 'samurai', 'phoenix', 'dragon', 'chrono']);

    if (hookSet.has(p.id)) {
      // 3D Instant Grapple Chain — grabs target in front and yanks them straight into melee range
      this.sound.playHookPull();
      const end = eye.clone().addScaledVector(forward, 26);
      this.vfx.spawnChain(eye, end, p.hex, 0.55);
      if (!ctx.visualOnly) {
        const line = new THREE.Line3(eye, end);
        const closest = new THREE.Vector3();
        const pullDest = caster.position.clone().addScaledVector(flatFwd, 2.5);
        for (const f of fighters) {
          if (f === caster || f.isDead) continue;
          const center = f.position.clone().add(new THREE.Vector3(0, 1.3, 0));
          line.closestPointToPoint(center, true, closest);
          if (closest.distanceTo(center) < 3.2) {
            const pull = pullDest.clone().sub(f.position).normalize().multiplyScalar(28);
            pull.y = 8;
            f.takeDamage(16, pull, caster, ctx);
            this.vfx.spawnChain(eye, center, p.hex, 0.65);
          }
        }
      }
    } else if (shieldSet.has(p.id)) {
      // 3D Elemental Shield Barrier (+35 Shield + radial pushback)
      this.sound.playEquip();
      if (!ctx.visualOnly) {
        caster.shield = Math.min(caster.maxShield, caster.shield + 35);
      }
      this.vfx.spawnSphereFlash(caster.position.clone().add(new THREE.Vector3(0, 1.3, 0)), p.hex, 4.6, 0.5, 0.45);
      this.vfx.spawnRing(caster.position, p.hex, 8.5, 0.45);
      this._aoeDamage(caster.position, 7.5, 14, 24, 10, caster, fighters, ctx);
    } else if (leapSet.has(p.id)) {
      // Elemental Sky Leap + Slam
      this.sound.playPower(p.id, 1);
      if (!ctx.visualOnly) {
        caster.velocity.y = 19;
        caster.velocity.addScaledVector(flatFwd, 20);
        caster.onGround = false;
      }
      this.vfx.spawnRing(caster.position, p.hex, 6.5, 0.4);
      this.delayedActions.push({
        timer: 0.62,
        fn: () => {
          if (caster.isDead) return;
          const pt = caster.position.clone();
          pt.y = Math.max(0, this.getGroundHeight(pt.x, pt.z));
          this.sound.playExplosion(0.95);
          this.vfx.spawnRing(pt, p.hex, 10.5, 0.45);
          this.vfx.spawnBurst(pt, p.hex, 24, 14, 0.28);
          if (caster.isPlayer) this.vfx.addShake(0.6);
          this._aoeDamage(pt, 9.5, 22, 24, 14, caster, fighters, ctx);
        },
      });
    } else {
      // 3D Rotating Elemental Turret Crystal that auto-zaps nearby enemies for 6s
      this.sound.playPower(p.id, 1);
      const pt = caster.position.clone().addScaledVector(flatFwd, 3.2);
      pt.y = Math.max(0, this.getGroundHeight(pt.x, pt.z));
      const turret = new THREE.Group();
      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.95, 0.4, 8), flatMat(0x223047));
      base.position.y = 0.2;
      turret.add(base);
      const crys = new THREE.Mesh(new THREE.OctahedronGeometry(0.65, 0), flatMat(p.hex, { emissive: p.hex, emissiveIntensity: 1.4 }));
      crys.position.y = 1.45;
      turret.add(crys);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.95, 0.06, 4, 12), new THREE.MeshBasicMaterial({ color: p.hex }));
      ring.rotation.x = Math.PI / 2;
      ring.position.y = 1.45;
      turret.add(ring);
      turret.position.copy(pt);
      this.scene.add(turret);

      this.zones.push({
        caster, mesh: turret, pos: pt, radius: 15.0, life: 6.2, age: 0, tick: 0.25,
        update: (z, dt) => {
          crys.rotation.y += dt * 4;
          ring.rotation.z -= dt * 3;
          z.tick -= dt;
          if (z.tick <= 0) {
            z.tick = 0.85;
            let nearest = null;
            let bestD = z.radius;
            for (const f of fighters) {
              if (f === caster || f.isDead) continue;
              const d = f.position.distanceTo(z.pos);
              if (d < bestD) { bestD = d; nearest = f; }
            }
            if (nearest) {
              const start = z.pos.clone().add(new THREE.Vector3(0, 1.5, 0));
              const end = nearest.position.clone().add(new THREE.Vector3(0, 1.3, 0));
              this.vfx.spawnBeam(start, end, p.hex, 0.22, 0.22);
              this.vfx.spawnBurst(end, p.hex, 8, 8, 0.18);
              if (!ctx.visualOnly) {
                const push = end.clone().sub(start).setY(0).normalize().multiplyScalar(12);
                push.y = 5;
                nearest.takeDamage(11, push, caster, ctx);
              }
            }
          }
        },
      });
    }
    return true;
  }

  _spawnProj(spec) {
    this.projectiles.push({
      ...spec,
      prevPos: spec.mesh.position.clone(),
    });
  }

  _aoeDamage(center, radius, dmg, kbHoriz, kbUp, caster, fighters, ctx, onEach = null) {
    if (ctx.visualOnly) return 0;
    let count = 0;
    for (const f of fighters) {
      if (f === caster || f.isDead) continue;
      const dx = f.position.x - center.x;
      const dz = f.position.z - center.z;
      const dy = f.position.y - center.y;
      const horizDist = Math.hypot(dx, dz);
      // Accurate cylinder AoE check so elevation/slopes never drop hits
      if (horizDist <= radius + f.currentScale * 0.8 && Math.abs(dy) <= radius + 3.2) {
        count++;
        const push = new THREE.Vector3(dx, 0, dz);
        if (push.lengthSq() < 0.01) push.set(Math.random() - 0.5, 0, Math.random() - 0.5);
        push.normalize().multiplyScalar(kbHoriz);
        push.y = kbUp;
        const status = {};
        if (caster.powerId === 'pyro' || caster.powerId === 'magma' || caster.powerId === 'dragon') status.burn = 3.5;
        if (caster.powerId === 'cryo') status.freeze = 2.4;
        if (caster.powerId === 'poison' || caster.powerId === 'nature') status.poison = 3.2;
        if (caster.powerId === 'thunder') status.slow = 1.5;
        f.takeDamage(dmg, push, caster, { ...ctx, status });
        if (onEach && !f.isRemotePlayer) onEach(f);
      }
    }
    return count;
  }

  update(dt, fighters, ctx) {
    for (let i = this.delayedActions.length - 1; i >= 0; i--) {
      const d = this.delayedActions[i];
      d.timer -= dt;
      if (d.timer <= 0) {
        this.delayedActions.splice(i, 1);
        d.fn();
      }
    }

    // Active Titan Bull-Rush Charge collisions
    for (const f of fighters) {
      if (f.chargeTimer > 0) {
        f.chargeTimer -= dt;
        f.velocity.x = f.chargeDir.x * 28;
        f.velocity.z = f.chargeDir.z * 28;
        for (const other of fighters) {
          if (other === f || f.chargeHitIds.has(other.id)) continue;
          if (Math.hypot(other.position.x - f.position.x, other.position.z - f.position.z) < 2.8 * f.currentScale && Math.abs(other.position.y - f.position.y) < 3.2) {
            f.chargeHitIds.add(other.id);
            const kb = f.chargeDir.clone().multiplyScalar(28);
            kb.y = 14;
            other.takeDamage(21, kb, f, ctx);
            this.vfx.spawnBurst(other.position.clone().add(new THREE.Vector3(0, 1.4, 0)), 0xffaa2b, 14, 11, 0.25);
            if (f.isPlayer) {
              this.sound.playHit(true);
              this.vfx.addShake(0.45);
            }
          }
        }
      }
    }

    // Swept Anti-Tunneling Projectile Collision
    const seg = new THREE.Line3();
    const closest = new THREE.Vector3();
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const pr = this.projectiles[i];
      pr.life -= dt;
      if (pr.life <= 0) {
        this.scene.remove(pr.mesh);
        this.projectiles.splice(i, 1);
        continue;
      }

      if (pr.homing) {
        let best = null;
        let bestD = 36;
        for (const f of fighters) {
          if (f === pr.caster) continue;
          const d = f.position.distanceTo(pr.mesh.position);
          if (d < bestD) { bestD = d; best = f; }
        }
        if (best) {
          const desired = best.position.clone().add(new THREE.Vector3(0, 1.3, 0)).sub(pr.mesh.position).normalize().multiplyScalar(23);
          pr.vel.lerp(desired, Math.min(1, dt * 5.5));
        }
      }

      pr.prevPos.copy(pr.mesh.position);
      pr.vel.y -= pr.gravity * dt;
      pr.mesh.position.addScaledVector(pr.vel, dt);
      pr.mesh.rotation.x += dt * 4;
      pr.mesh.rotation.y += dt * 5;

      if (Math.random() < 0.45) {
        this.vfx.spawnBurst(pr.mesh.position, pr.trailColor, 1, 1.5, 0.16, 1, 0.22);
      }

      let exploded = false;
      seg.set(pr.prevPos, pr.mesh.position);

      for (const f of fighters) {
        if (f === pr.caster || f.isDead) continue;
        const center = f.position.clone().add(new THREE.Vector3(0, 1.25 * f.currentScale, 0));
        seg.closestPointToPoint(center, true, closest);
        if (closest.distanceTo(center) < pr.radius + 1.05 * f.currentScale) {
          pr.onHit(closest.clone());
          exploded = true;
          break;
        }
      }

      if (!exploded) {
        const gh = this.getGroundHeight(pr.mesh.position.x, pr.mesh.position.z);
        if (pr.mesh.position.y <= gh + pr.radius * 0.45) {
          if (pr.bounces && pr.bounces > 0) {
            pr.bounces -= 1;
            pr.mesh.position.y = gh + pr.radius * 0.5;
            pr.vel.y = Math.abs(pr.vel.y) * 0.58;
            this.vfx.spawnRing(pr.mesh.position, 0xd99a4e, 3.5, 0.3);
            this._aoeDamage(pr.mesh.position, 4.2, 12, 15, 8, pr.caster, fighters, ctx);
          } else {
            pr.onHit(pr.mesh.position.clone());
            exploded = true;
          }
        }
      }

      if (exploded) {
        this.scene.remove(pr.mesh);
        this.projectiles.splice(i, 1);
      }
    }

    for (let i = this.zones.length - 1; i >= 0; i--) {
      const z = this.zones[i];
      z.age += dt;
      if (z.age >= z.life) {
        if (z.onEnd) z.onEnd(z);
        this.scene.remove(z.mesh);
        this.zones.splice(i, 1);
        continue;
      }
      z.update(z, dt);
    }
  }
}
