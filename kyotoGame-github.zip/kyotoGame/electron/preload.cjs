const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('kyotoDesktop', {
  isDesktop: true,
  getLocalServerUrl: () => ipcRenderer.invoke('desktop:get-local-url'),
  hostOnline: (roomCode) => ipcRenderer.invoke('desktop:host-online', roomCode),
  stopHost: () => ipcRenderer.invoke('desktop:stop-host'),
  copyText: (text) => ipcRenderer.invoke('desktop:copy', text),
  toggleFullscreen: () => ipcRenderer.invoke('desktop:toggle-fullscreen'),
  quitApp: () => ipcRenderer.invoke('desktop:quit'),
});
