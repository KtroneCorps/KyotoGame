const { app, BrowserWindow, ipcMain, clipboard, shell } = require('electron');
const path = require('path');
const { createGameServer } = require('../server/server.cjs');
const { TunnelManager } = require('../server/tunnel.cjs');

let mainWindow = null;
let gameServer = null;
let localPort = 3000;
const tunnel = new TunnelManager();

async function ensureLocalServer() {
  if (gameServer) return localPort;

  const distDir = path.join(__dirname, '..', 'dist');
  // Try port 3000 first; fallback to any free OS port so it never fails if 3000 is busy
  try {
    const srv = createGameServer({ port: 3000, distDir });
    const info = await srv.start();
    gameServer = srv;
    localPort = info.port;
  } catch {
    const srv = createGameServer({ port: 0, distDir });
    const info = await srv.start();
    gameServer = srv;
    localPort = info.port;
  }
  return localPort;
}

async function createWindow() {
  const port = await ensureLocalServer();
  const iconPath = path.join(__dirname, '..', 'build', 'icon.png');

  mainWindow = new BrowserWindow({
    width: 1440,
    height: 860,
    minWidth: 1024,
    minHeight: 640,
    title: 'kyotoGame',
    backgroundColor: '#0d1624',
    icon: iconPath,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      backgroundThrottling: false,
    },
  });

  mainWindow.setMenuBarVisibility(false);

  const isDev = process.env.KYOTO_DEV === '1';
  const targetUrl = isDev ? 'http://localhost:5173/' : `http://127.0.0.1:${port}/`;
  await mainWindow.loadURL(targetUrl);

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// --- Desktop IPC Handlers ---
ipcMain.handle('desktop:get-local-url', async () => {
  const port = await ensureLocalServer();
  return `http://127.0.0.1:${port}`;
});

ipcMain.handle('desktop:host-online', async (_event, roomCode) => {
  const port = await ensureLocalServer();
  const publicUrl = await tunnel.start(port);
  const cleanRoom = String(roomCode || 'PUBLIC').toUpperCase().replace(/[^A-Z0-9_-]/g, '') || 'PUBLIC';
  const inviteUrl = `${publicUrl}/?room=${encodeURIComponent(cleanRoom)}`;
  return {
    publicUrl,
    inviteUrl,
    localUrl: `http://127.0.0.1:${port}`,
    room: cleanRoom,
  };
});

ipcMain.handle('desktop:stop-host', async () => {
  tunnel.stop();
  return { ok: true };
});

ipcMain.handle('desktop:copy', (_event, text) => {
  clipboard.writeText(String(text || ''));
  return { ok: true };
});

ipcMain.handle('desktop:toggle-fullscreen', () => {
  if (!mainWindow) return false;
  const next = !mainWindow.isFullScreen();
  mainWindow.setFullScreen(next);
  return next;
});

ipcMain.handle('desktop:quit', () => {
  app.quit();
});

app.whenReady().then(createWindow);

app.on('window-all-closed', async () => {
  tunnel.stop();
  if (gameServer) {
    try { await gameServer.stop(); } catch { /* ignore */ }
    gameServer = null;
  }
  app.quit();
});

app.on('before-quit', () => {
  tunnel.stop();
});
