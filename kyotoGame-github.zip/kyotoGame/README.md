# kyotoGame

Jeu d'action 3D low-poly multijoueur développé avec **Three.js**, **Vite**, **Node.js (WebSocket)** et **Electron**.

Tu commences dans un **Grand Dojo** avec **28 pouvoirs élémentaires**, un vestiaire 3D pour personnaliser ton personnage et **5 portails** vers différents modes de jeu : Combat Classique, Mode Combo, Battle Royale en monde ouvert, Mode Classé et Éditeur de Mondes 3D.

---

## Modes de jeu

- **Grand Dojo** — Hub central avec 28 piédestaux de pouvoirs, miroir de personnalisation 3D (peau, tenue, coiffures, accessoires de dos) et 5 portails.
- **Arène Classique** — Vallée low-poly avec rivière, ponts traversables, tremplins et combat libre.
- **Mode Combo** — Les coups mettent l'adversaire au sol pendant `1.6s`, avec une fenêtre de contre à `1.1s` (`Clic Gauche`) pour casser le combo.
- **Battle Royale (Monde ouvert procédural)** — Départ dans un avion 3D, saut (`Espace`), planeur 3D, île multi-biomes (neige, désert, forêt, bois sakura, rivière et ponts), tempête qui rétrécit, minimap + carte tactique (`TAB`), et loot au sol : 5 armes à feu 3D (pistolet, SMG, fusil d'assaut, pompe, sniper avec lunette), 28 pouvoirs, soins et boucliers.
- **Mode Classé** — File d'attente multijoueur (2 joueurs minimum), matchs en 3 K.O. et système de grades Elo (`Bronze I` à `Légende Kyoto`).
- **kyotoGame Studio** — Éditeur de cartes 3D intégré (blocs, rampes, panneaux de texte modifiables, lave, tremplins, piédestaux) avec sauvegarde locale, import/export JSON et synchro multijoueur.

## Stack technique

- **Rendu 3D** : Three.js (`MeshStandardMaterial` flat shading, ombres dynamiques, VFX procéduraux)
- **Audio** : Web Audio API (sons d'ambiance et SFX 100% procéduraux, sans musique)
- **Réseau** : Serveur WebSocket multi-salons (`ws`) + tunnel Cloudflare intégré pour héberger sans exposer son IP
- **Desktop** : Electron + `electron-builder` (build Windows portable `.exe`)
- **Modèles 3D** : 35 fichiers Blockbench (`.bbmodel`) fournis dans `models/`

## Installation

Prérequis : [Node.js](https://nodejs.org/) 20+

```bash
git clone https://github.com/<ton-pseudo>/kyotoGame.git
cd kyotoGame
npm install
```

Si npm bloque les scripts post-install sur Windows :

```bash
node node_modules/cloudflared/lib/cloudflared.js bin install
node node_modules/electron/install.js
```

## Commandes

| Commande | Action |
|---|---|
| `npm run dev` | Lancer en développement (`http://localhost:5173`) |
| `npm run build` | Compiler le bundle web dans `dist/` |
| `npm run server` | Lancer le serveur multijoueur (`http://localhost:3000`) |
| `npm run desktop` | Lancer la version bureau Electron |
| `npm run build:exe` | Générer l'exécutable portable `release/kyotoGame.exe` |

## Contrôles

- **Déplacement** : `ZQSD` / `WASD`, `Espace` (Saut / Saut d'avion / Planeur), `Shift` (Dash)
- **Pouvoirs** : `Clic Gauche` (Attaque), `E` ou `Clic Droit` (Pouvoir 1), `A` / `F` (Ultime), `R` (Pouvoir 3 tactique)
- **Battle Royale** : `E` (Ramasser), `1` `2` `3` (Armes), `4` (Mains/Pouvoir), `Clic Droit` (Viser / Lunette Sniper), `R` (Recharger), `TAB` (Carte)
- **Interface** : `Molette` ou `V` (Caméra 1P / 3P), `C` (Personnaliser), `B` (Studio 3D), `M` (Multijoueur), `T` (Retour Dojo), `Entrée` (Chat), `Échap` (Paramètres)

## Structure du projet

```text
├── index.html
├── package.json
├── vite.config.js
├── render.yaml
├── electron/
│   ├── main.cjs                # Fenêtre Electron, serveur local & tunnel
│   └── preload.cjs             # API IPC (window.kyotoDesktop)
├── server/
│   ├── server.cjs              # Serveur HTTP + WebSocket (salons, Classé, BR)
│   └── tunnel.cjs              # Gestionnaire cloudflared
├── models/                     # 35 modèles Blockbench (.bbmodel)
├── scripts/
│   ├── generate-icon.cjs       # Génération de build/icon.png et icon.ico
│   └── export-bbmodels.cjs     # Export des .bbmodel
└── src/
    ├── main.js
    ├── style.css
    ├── audio/SoundEngine.js
    ├── entities/
    │   ├── Fighter.js
    │   └── BotAI.js
    ├── game/GameEngine.js
    ├── models/
    │   ├── LowPolyModels.js
    │   └── WeaponModels.js
    ├── net/MultiplayerClient.js
    ├── powers/
    │   ├── PowersData.js
    │   └── PowerExecutor.js
    ├── ui/
    │   ├── HudManager.js
    │   └── StudioUi.js
    ├── vfx/VfxManager.js
    ├── weapons/WeaponsData.js
    └── world/
        ├── DojoWorld.js
        ├── ArenaWorld.js
        ├── BattleRoyaleWorld.js
        └── CustomWorld.js
```

## Licence

MIT — voir [LICENSE](LICENSE).
